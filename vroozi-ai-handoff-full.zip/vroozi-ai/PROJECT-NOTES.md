# Vroozi AI — Project Notes

Living spec + changelog for `vroozi-ai.html`. Keep this file alongside the HTML so any session has full context without rebuilding it. This file is authoritative; the handoff only points here. Update it whenever the app changes. **Current version: v1.40.0.**

---

## Direction (current — read first)

`vroozi-ai.html` is an internal build of an AI-assisted procure-to-pay experience for Vroozi, in active development. It's iterated with design and shown to internal stakeholders. Iteration speed and learning matter more than stage-proof reliability; breakage is acceptable. (It began as a scripted, on-rails presentation build — that framing is retired. See Retired/Kept below.)

### Phased plan

**Phase 1 — free-text in, scripted out.** Replace chip-only input with a working text input. The user types anything; the app matches intent and routes to one of the existing scripted responses. Stays a single self-contained HTML file, no JS/data network calls (one exception: the Google Fonts link — see What this is → Self-contained). Chips remain, but as *suggestions* above a live input, not the only way in.

**Phase 2 — real generation.** Swap the scripted-response layer for live model calls. This ends the single-file constraint (network, server-side key, backend proxy or the Claude.ai artifact sandbox). At Phase 2 the project becomes a real app under version control, not one mutating file.

### The seam (BUILT — Chat + Analytics in v1.27.0; Voice + omnibox in v1.28.0)

A chip is `{label, keys, responses, then}` and `pick(c)` plays `c.responses` directly. As of v1.27.0 there is also a text→response dispatch:

- `getResponse(userText, context)` returns a normalized descriptor: `{ steps: [{type:'typing'|'bot'|'status', html, text, delay}], then, match }` (the same shape `runSequence` consumes), or a no-match descriptor. `context = { chips, screen, engine }`.
- `ConvoEngine.prototype.submitText(userText)` mirrors `pick()` but calls `getResponse` first (and skips the typewriter — the user already typed), then feeds the result to `runSequence`. Guards `busy`; empty text nudges, no bot turn.
- Phase 2 reimplements **only** `getResponse` as an async model call returning the same shape. `submitText`/`runSequence`/the UI never change. Matching is never wired into the input handler.

The matcher is state-scoped and conservative (three tiers, `MATCH_MIN=2`): (1) current branch chips — `engine.currentChips`, always win; (2) broader intent scoped to *this engine's* entry asks (`engine.entryChips` = `CHAT_START_CHIPS`/`AN_START_CHIPS`/`VOICE_START_CHIPS`), no cross-screen jumps in Phase 1; (3) deliberate no-match. Per-chip `keys[]` carry match terms so paraphrases match full-sentence labels; multi-word keys are exact phrases, single-word keys + label tokens match with light stemming (plural-only — `gloves`→`glove`; verb forms like `spiked` are handled by adding keys, not stemming). No global keyword bag.

**Voice (v1.28.0–1.28.1)** has a transcript input (`#voiceInput`) beside the mic — speak or type, both feed `submitText`. The trailing control swaps mic↔send (`#voiceSend`, v1.28.1): mic when the field is empty, send when there's text; `voiceSyncSend()` keeps it in sync (called on `input`, after submit, and on reset, since programmatic `.value` doesn't fire `input`). Typing bootstraps the flow before the mic is tapped (tier-2 over `VOICE_START_CHIPS`); the mic gate no-ops once `voiceThread` is non-empty so the paths don't double-start.

**Universal Search (v1.28.0)** shares the matcher, not the renderer. `#uSoInput` is now a real `<input>`; `getUSearchResponse(text)` uses the same `bestChip`/`MATCH_MIN`, but renders the omnibox's own `uResult` blended card (it has no chat thread / `runSequence`). Catalog = the four `U_SUGG` asks (now keyed) + a small `U_MODES` intent map (speak/snap/video). No-match re-surfaces the catalog with the typed text escaped. Forcing the card UI into the `{steps,then}` shape would be worse — the shared, Phase-2-relevant part is the matcher.

**The catalog search seam (BUILT in v1.32.0)** is the product-search analogue of `getResponse`. `searchCatalog(query, opts)` does a deterministic token/`keys[]` lookup over the embedded `CATALOG` (reusing the matcher's `scoreChip`/`MATCH_MIN`) and returns *ranked `CATALOG` records* (`opts.topN`, `opts.min`). Every product flow calls it and renders through one helper, `productCardHTML(item, opts)` (inline `.product-card` + `.snap-product-card` variants). **Phase 2 reimplements only `searchCatalog`'s body** as a real semantic/vector search over a live catalog (server-side), returning the same record shape — callers (omnibox/Snap/Voice/Chat/browse) and `productCardHTML` never change. `keys[]` is Phase-1 match metadata only; Phase 2 ignores it. Consumers: omnibox `getUSearchResponse` (a product tier between the `U_SUGG` intents and `U_MODES`), Snap (`SNAP_ITEM_ID` resolves the "identified" item), and the Voice/Chat product literals (now `productCardHTML(catGet(id))`).

**Still deferred:** real STT for voice (the mic is a scripted tap, not speech capture) and real model generation (Phase 2, all surfaces, via `getResponse`/`getUSearchResponse`/`searchCatalog`).

### New design surface: the no-match state (BUILT in v1.27.0)

Chips made invalid input impossible; free text reintroduces "I don't understand that." `noMatchResponse(prevChips)` returns a reusable descriptor — a short bot turn ("I didn't quite catch that…") that re-surfaces the current branch's chips as suggestions, so the user is never stuck. Empty input nudges the field (`.nudge` shake) with no bot turn. Phase 2 reuses the same `noMatchResponse` slot for low-confidence model output and (later) loading / error / timeout.

### Retired (no longer rules)

- "On-rails / cannot break or hallucinate on stage" as a value.
- CFO-lens framing as a *constraint* (the procurement domain stays — see Kept).
- Verbal-close discipline, rep-narrated-not-self-service, prospect matrix, depth-on-demand-for-live-pacing.
- The "no feedback / book-a-live-demo cards" rule.
- Companion cheat-sheet and run-sheet (out of scope; they document the old narrative).
- "Demo"/"prototype" as the product's identity — it's just **Vroozi AI** now (title, version stamps, sidebar label all renamed in v1.22.0).

### Kept (domain substance, not presentation veneer)

- Procurement realism: the PR/PO data, the Grainger gloves thread, spend flows, savings-tier modeling — seed content for the build.
- The interaction engine and helpers.
- The iOS rendering fixes.
- Charcoal + gold aesthetic and the embedded logo.

### Scaffolding keep/cut (decided 2026-06-22)

Reframed: the four items aren't one category. **Full-bleed / on-device mode is the product's actual runtime, not scaffolding** — keep it (it's miscategorized as a prop). **Replay was cut in v1.22.1** — a reset affordance contradicts the "it's an app, not a looping demo" repositioning. **Desktop preview shell + iPhone/iPad/orientation toggles: keep through Phase 1 as a dev harness** (fastest way to eyeball the new live-input and no-match UI at both form factors on a laptop), retire at Phase 2 when it moves to a repo with real hosting/device testing. Standing cost of the shell: the `window.__appScale` divide on every in-frame `getBoundingClientRect()` — a permanent footgun, but Phase 1 input sits at the bottom and reuses `syncPad`, so it adds no new rect math.

Open: the shell-keep assumes some review happens on a laptop. If the team only reviews on real devices, cut the shell now and rely on full-bleed mode + hardware.

---

## What this is (current state)

A single HTML file (~301 KB, ~2,535 lines), all CSS/JS/base64 images inline, zero dependencies. It models an AI-assisted procure-to-pay experience: voice/chat/snap ordering, spend analytics, anomaly detection, and PR/PO management with order tracking. Flows accept free text (Phase 1 seam, v1.27.0–v1.28.x) matched to scripted responses; chips remain as suggestions.

- **Identity:** charcoal + gold, infinity-loop motif. The real Vroozi logo is base64-embedded (sidebar header, home hero, iPad-landscape rail with a gold "AI" lockup). Title and version stamps read "Vroozi AI".
- **Self-contained (Phase 1):** no external dependencies, no build step, no JS/data network calls. **One caveat:** DM Sans + JetBrains Mono load from `fonts.googleapis.com` (a `<link>` + preconnect), so the app is not strictly offline/air-gapped today — it renders in fallback fonts without a network. Embedding the fonts (base64) to make the offline claim literally true is deferred (proposal #9); a real concern for air-gapped or residency-restricted gov tenants at Phase 2 hosting. Retired at Phase 2.
- **PWA-capable:** `apple-mobile-web-app-capable`, `mobile-web-app-capable`, `black-translucent` status bar, inline manifest (`display:standalone`).

---

## Design system / style guide

The design language is documented in a **separate asset**, `vroozi-ai-styleguide.html`, with its own spec and changelog — not in this file. See `STYLEGUIDE-NOTES.md` (authoritative) and `STYLEGUIDE-CHANGELOG.md`. The guide is a reference only and does **not** change the app. Reminder: the app's `:root` is canonical; the guide mirrors it (regenerate the guide when tokens change). **Every change to `vroozi-ai.html` must reconcile this guide and both changelogs in the same pass — see Working discipline → Deliver (coupled delivery).** The guide and the app drift apart the moment that step is skipped; that's exactly how the omnibox specimen and the guide's own version stamp went stale for several revs.

---

## Core interaction pattern

Flows run through `ConvoEngine` (drives Voice/Chat/Analytics). Two ways in:

1. Suggestion chips appear above the input. Tapping a chip types its label in, then sends → `pick`.
2. **(v1.27.0, Chat + Analytics)** The user types free text and hits send/Enter → `submitText` → `getResponse` matches it to a chip's scripted response (or no-match).
3. Either way a scripted response plays (typing dots → message/card via `runSequence`).
4. The next chips appear (branching), or no-match re-surfaces the current chips, or the flow ends.

Chips remain as *suggestions* above a live input — both paths converge on `runSequence`. As of v1.28.0 all three engines (Chat, Analytics, Voice) have a live input; Voice's sits beside the mic. The Universal Search omnibox also takes free text (v1.28.0), via its own `getUSearchResponse` sharing the same matcher.

Key helpers:
- `tap(node, fn)` — binds `touchend` + `click`, de-dupes, preserves `this`. Use for every interactive element, never raw `onclick`.
- `$(id)`, `el(tag,cls,html)` — DOM shorthands.
- `showScreen(id)` — switches `.screen-view`; closes the search overlay; calls `resetForScreen(id)`.
- `ConvoEngine.prototype.offerChips(chips)` — chips are `[{label, keys, responses, then}]`; renders them, wires taps to `pick`, and retains them as `this.currentChips` for the matcher.
- `ConvoEngine.prototype.pick(c)` — types `c.label`, posts user msg, runs `c.responses` via `runSequence`, then `c.then`.
- `ConvoEngine.prototype.submitText(text)` / `getResponse(text, ctx)` / `wireLiveInput(engine)` — the free-text seam (see Direction → The seam).
- `ConvoEngine.prototype.runSequence(seq, done)` — plays a step array (`typing`/`bot`/`status`). This is the rendering contract `getResponse` should target.
- `ConvoEngine.prototype.syncPad(scrollAfter)` — recalculates bottom padding so the latest message clears the floating chip tray.

> Internal naming note: per-flow reset functions are still named `resetVoiceDemo` / `resetChatDemo` / `resetAnalyticsDemo` / `resetSnapDemo` / `resetAnomalyDemo`. Left as-is in the v1.22.0 rename (internal identifiers, not user-facing; renaming them is risk with no visible payoff). Clean up opportunistically if touching those functions anyway.

---

## Device / form-factor architecture

> Under "review for removal" per Direction. Accurate as built; keep documented until the keep/cut decision is made.

### Desktop preview shell
Non-touch desktop renders inside a preview shell: dark sidebar (280px, a "Flows" nav label + version footer), center stage with the simulated device frame (bezel, notch, status bar), and a context bar with two toggles — Device (iPhone/iPad) and Orientation (Portrait/Landscape).

Frame dimensions (CSS px, before scale-to-fit): phone portrait 390×844 (default), phone landscape 844×390, tablet portrait 640×860, tablet landscape 860×640 (default for iPad).

`fitFrame()` scales the frame via `transform:scale()`, stored in `window.__appScale`. Any `getBoundingClientRect()` positioning inside the frame must divide offsets by `__appScale`.

### iPad-landscape nav rail
iPad + Landscape shows a persistent 212px left rail replacing the bottom tab bar. Brand header = embedded logo (copied from sidebar at init) + gold "AI". Workspace: Home, Shop, Requests, Orders, Inbox (badge "4"). AI Actions: Voice, Chat, Snap, Analytics, Spend, Anomaly. Account: Profile, Settings (v1.30.0 added Profile under an "Account" label — the rail had none, so Profile was unreachable on iPad landscape once it became a real screen; v1.31.0 added Settings alongside it, gear icon). **Shop** (`#railShop`, v1.30.0) opens the Universal Search overlay, not a screen — so it carries no `data-screen` and is wired with its own handler (route to Home, then `openUSearch('type')`), mirroring bottom-nav `#navShop`. Without it the omnibox was unreachable on iPad landscape except via the home hero search bar. No footer version stamp (removed v1.30.0; version lives in About). Rail items use `data-screen` and are picked up by `navItems` for tap handlers + active highlighting (the bottom-nav Profile is `#navProfile` with its own handler, not `data-screen`).

### On-device full-bleed mode
Real touch devices enter device mode: desktop chrome hidden, active screen fills the viewport. Detection (`isDeviceMode()`): `pointer:coarse` OR `hover:none` OR `maxTouchPoints>0` OR UA contains iPad/iPhone/Android. Pure-CSS `@media (hover:none) and (pointer:coarse)` fallback applies critical rules pre-JS. Device-mode CSS uses `position:fixed !important; inset:0; width:100vw; height:100dvh` (all `!important` to beat orientation-class specificity). Safe-area insets pad for notch/Dynamic Island/home indicator. `syncFromViewport()` auto-rotates (`vw>vh`→landscape; `min(vw,vh)>=600`→tablet); bound to resize/orientationchange/visualViewport/pageshow.

---

## Touch / device requirements

- Touch-first: 44px+ targets, `touch-action:manipulation`, `-webkit-tap-highlight-color:transparent`.
- **iOS scroll fix:** scroll containers need `min-height:0` (flex children default to `min-height:auto` and won't shrink, killing iOS Safari scroll even where desktop Chrome works). Keep it on `.voice-body, .chat-body, .spend-body, .anomaly-body, .requests-body, .inbox-body, .uso-body`.
- Dynamic greeting via `setGreeting()` (device-local time of day).

---

## Feature inventory (screens + detail views + auth flow)

Screen ids: `screen-home, screen-voice, screen-chat, screen-chatanalytics, screen-snap, screen-catalog, screen-spend, screen-anomaly, screen-requests, screen-orders, screen-tracking, screen-inbox, screen-typography, screen-auth, screen-authmfa, screen-authlock, screen-profile, screen-settings`. (`screen-about` was folded into the Settings → About pane in v1.31.0.) Bottom nav (5): Home · Shop (Universal Search) · Requests · Orders · Profile (Profile → `screen-profile` detail form). Settings is its own destination reached via gear cogs (Home + Profile headers) and the rail/sidebar "Settings" nav item.

1. **Universal Search omnibox** — multi-modal front door above AI Actions; command-palette overlay with four modality pills. `#uSoInput` is a real input (v1.28.0): free text → `getUSearchResponse` (shared matcher) → blended result + "Continue in [flow]" route, or no-match re-surfacing the catalog. **v1.32.0** adds a product-lookup tier between the `U_SUGG` intents and `U_MODES`: `searchCatalog` top-4 → `uCatalogResult` renders the hit(s) via `productCardHTML` in the `uso-result` shell (single → "Order in Chat", multiple → "Browse full catalog"). The Type view also leads with a **Browse the full catalog** row → `screen-catalog`. Tapping a suggestion still works. Modality words route to Speak/Snap/Video. Also opened by bottom-nav Shop. Ids: `uSearchBar`, `uSearchOverlay`, `openUSearch()`.

  **5b. Catalog browse (`screen-catalog`, v1.32.0)** — the Shop browse surface. Category filter chips (`CATALOG_CATEGORIES` — All + the 8 product categories) + a product list reading directly from `CATALOG` (`renderCatalog`/`drawCatFilter`/`drawCatList`, `#catFilter`/`#catList`). Reached from the omnibox Type view and **Catalog** nav items in the desktop sidebar + iPad-landscape rail (`data-screen="catalog"`). Not on the 5-item bottom nav; Shop still opens the omnibox.
2. **Voice Ordering** — mic *or* typed transcript (`#voiceInput`, v1.28.0) → "laptop for Marketing" (CDW contract) → cheaper-compliant branch (refurb, −$700) → place order → PR → Approved. Alt: standing desks (`VCTX_DESK`, distinct PR/supplier/conf numbers to avoid collisions with the laptop path). Typing can start the flow without the mic.
3. **Chat Ordering** — "200 boxes safety gloves" happy path, OR "15 laptops" → budget-guardrail branch → split PR (11 now / 4 next qtr) or route exception to Finance.
4. **Chat Analytics** — "why did IT spend jump" (planned vs avoidable) and "where can I save 10%" ($664K identified) → depth chain: identified-vs-realized tiers (Committed $300K / Probable $248K / Aspirational $116K; $548K risk-adjusted) → "Show the Grainger line" trace. Alt: top-suppliers chart; draft renegotiation email.
5. **Snap to Order** — shutter → scan → identify + contract match → submit PR (button turns green + toast). The identified item resolves from `CATALOG` (`SNAP_ITEM_ID` → `productCardHTML(..., {variant:'snap'})` into `#snapProductSlot`), no longer a static card (v1.32.0).
6. **Spend Intelligence** — static dashboard (not chip-driven). KPIs + AI Savings Opportunities.
7. **Anomaly Detection** — duplicate-invoice catch + side-by-side → Reject (or Send to Review) → systemic-pattern card → "Auto-hold any invoice matching a paid PO" standing-control turn (audit-logged). Id: `autoHoldBtn`.
8. **Purchase Requests** (nav "Requests") — list with status filter (All/Draft/Approved/Sourcing Review/Financial Review/Rejected). Card: PR number, name, amount, supplier, date, approver, status pill.
9. **Purchase Orders** (nav "Orders") — same card layout. `2000000XXX` numbering. Status filter (All/Ordered/Received/Invoiced/Cancelled). Card adds associated PR number + right-chevron. Tapping a card opens Track Order.
10. **Track My Order** (`screen-tracking`) — detail screen from a PO card. Header + vertical 8-stage timeline (PR Approved → PO Created → Sent to Supplier → Supplier Confirmed → Shipped → Delivered → Invoice Received → Payment Processed). Dots: green-check done, pulsing-gold current, hollow upcoming, red-× cancelled. Back → Orders. Cancelled POs show a truncated timeline ending in red "Order Cancelled". Each PO has unique tracking data.
11. **Inbox** (home bell, badge, id `homeInbox`) — To Review tasks (Open routes to flow; Snooze decrements badge) + Notifications tabs. Version stamp at bottom.
12. **Typography** — design-system reference (sidebar only).
13. **Authentication** (sidebar "Authentication"; v1.23.0) — front-end mock, three screens. `screen-auth` (welcome/sign-in): logo + spark orb, "Continue with SSO" (primary, generic glyph — no real provider logo), "Sign in with a passkey" (secondary), and an expandable email+password fallback (`authEmailToggle`). SSO → brief redirect spinner → MFA. Passkey → spinner → Home. Email → MFA. `screen-authmfa`: 6 `mfa-box`es + on-screen numeric `mfaKeypad` (tap-to-fill, auto-verify at 6 digits via `verifyMfa`), resend link. `screen-authlock` (returning user): avatar initial + name (read from `state.userName`), Face ID ring with scan→ok animation (`lockRing`/`lockLabel`) → Home, "Use a different account" → welcome (resets name). Reached from sidebar (welcome) and **Profile → Sign out** (v1.30.0; bottom-nav Profile no longer jumps here — it opens `screen-profile`). **Not gated** on load — app still boots on Home (decided v1.30.0: no cold-start gate; a real gated session is a Phase 2 concern). **Mock only:** any input succeeds; no credentials stored, no network, no crypto. Real auth is Phase 2 (server-side session + IdP). Resets: `resetAuth`/`resetAuthMfa`/`resetAuthLock`. Logo copied from sidebar at init (`authLogo`), same pattern as the rail. **v1.30.0 added flows (all mock):** optional **Display name** field on the email path (blank → `Shaz`, captured into `state.userName`); **Forgot password?** → "reset link sent" toast; MFA **wrong-code error** via reserved code `000000` (any other 6 digits succeed); **Sign out** → lock; **Switch account** → welcome (resets the name echo).

14. **Profile (detail form) + Settings (own sub-nav)** (v1.30.0, reworked v1.31.0). Split into two surfaces — Profile = identity, Settings = app behavior.
    - **`screen-profile`** is a detail form (patterned on the production user-profile page): a profile card (avatar initial + `state.userName` + org `ACME-TEST-CO`), then **Contact information** (First/Last name, Contact title, Telephone, Fax, Pin code + Save — `pfContactSave` echoes First Name into `state.userName`), **My System Preferences** (Default Language, readonly), **Change Password** (`pfOldPw`/`pfNewPw`/`pfConfirmPw` + `pfPwSave` — visual mock; only checks new==confirm then clears + toasts; no real credential change), **My Document Defaults** (Company code, Purchasing org, Cost center, Currency, Plant, Shipping address — all readonly synthetic). Account actions (`profileSwitch`, `profileSignout`) at the bottom. A gear cog (`profileSettingsBtn`) in the topbar opens Settings. `resetForScreen('profile')` → `resetProfile()` (refreshIdentity + sets `pfFirst` to the active name). **All values synthetic — never real PII.**
    - **`screen-settings`** has its own left sub-nav (`#settingsNav`, `.settings-navitem[data-pane]`) switching `.settings-pane`s in place (`showSettingsPane`, default `notif`): **Notifications** (mock toggles), **Appearance** (mock theme `#segTheme` + Compact lists / Reduce motion toggles), **Privacy & Security** (MFA shown **Enabled + non-interactive** — never a disable control; active-session row; `signOutAll` → lock, mock), **About** (logo + `APP_NAME`/`APP_VERSION`/`APP_ORG` + environment, injected at init — folded in from the retired `screen-about`).
    - **Entry points:** bottom-nav Profile → `screen-profile`; Settings via gear cogs on the Home header (`homeSettings`, beside the bell) and Profile header (`profileSettingsBtn`), plus the iPad rail Account group and desktop sidebar Account group (`data-screen="settings"`). Don't reintroduce "demo/prototype" labels.

15. **Dynamic account name** (v1.30.0). One in-memory `state.userName` (default `"Shaz"`) feeds every live identity spot (`setGreeting`, lock name/avatar, welcome toast, voice label + voice PR card, snap PR card, chat/analytics greetings, Profile card) via `uName()`/`uInitial()`; `refreshIdentity()` repaints the always-present spots, per-flow greetings read at flow time. Untrusted, runtime-only (no persistence, never sent anywhere), **escaped with `uEscape` before any `innerHTML` write**. Historical `REQ_DATA`/`PO_DATA` names stay static (prior records, not the active user).

---

## Data architecture

Treat this as seed content; keep it internally consistent and obviously synthetic.

- **`REQ_DATA`** — 9 PRs. Fields: `num, date, supplier, name, approver, amt, status`. Numbers `1000000XXX`. Statuses: Draft, Approved, Sourcing Review, Financial Review, Rejected.
- **`PO_DATA`** — 9 POs. Fields: `po, pr, date, supplier, name, amt, status`. Numbers `2000000XXX`. `pr` cross-references REQ_DATA. Statuses: Ordered, Received, Invoiced, Cancelled.
- **`TRACKING`** — keyed by PO number; array of `{label, state, date, desc}`. States: done, current, upcoming, cancelled. Built by `makeSteps(done, dates, descs)` (8-stage) or hand-built for cancelled POs.
- **`CATALOG`** (v1.32.0, expanded to 50 items in v1.32.1) — synthetic product records; the single source of truth for every product flow (the centralization move done for `state.userName`, now for products). Record: `{ id, sku, name, mfr, supplier, contractRef, contract, contractTag, tags[], price, priceTag, uom, category, emoji, detail, keys[] }`. Shape mirrors Vroozi's OCI/punchout upload schema (`NEW_ITEM-*` fields) but **every value is fabricated** — ACME-TEST-* SKUs, emoji (not image URLs, which also keeps Phase 1 network-free), no real part numbers / vendor IDs / ObjectIDs. Categories (`CATALOG_CATEGORIES`, 8): IT / Safety & MRO / Office / Facilities / Medical / Lab & Scientific / Industrial / Energy. Suppliers follow the existing seed convention of public distributor brands (CDW/Grainger/Staples/Cintas FM, plus McKesson/VWR/MSC Direct/Balon for the new verticals) — not the uploaded supplier data. Defined in the seam region (not beside REQ/PO) because the Voice product literals evaluate before the REQ/PO block and `searchCatalog` needs `scoreChip`. Read by `searchCatalog` (the seam), `productCardHTML` (the one render path), `renderCatalog` (the browse screen), and `catGet(id)`.
- **Continuity:** Grainger gloves thread (PO-2000000243 → PR-1000000871, $4,598, $22.99 contracted / $34.99 off-contract) ties Chat → Analytics → Anomaly → Orders. Amazon, CDW, Staples, Grainger recur across PRs/POs. Catalog continuity items hold the same numbers: gloves `CAT-MR-001` $22.99/box; MacBook `CAT-IT-001` $2,499 + refurb `CAT-IT-002` $1,799 (CDW); Uplift desk `CAT-FA-001` $590 (×2 = $1,180); Steelcase chair `CAT-FA-002` $279. Brand names (CDW/Grainger/Steelcase/Cintas) are established in-app seed, not the uploaded supplier data — the sanitize rule applies to provided catalog content, not the seed.

---

## Conventions (current)

- **Grainger continuity thread:** keep the $22.99 / $34.99, 200 boxes = $4,598 numbers consistent across flows; reuse the thread rather than inventing supplier numbers.
- **Generalized names:** account holder = "Shaz"; approvers = "Vroozi Approver." Role titles (VP Operations, Ops Manager) fine. No other personal names.
- **Synthetic data stays obviously synthetic.** Never seed with anything resembling real customer/vendor/spend data. Mock org name = "ACME-TEST-CO" on the lock screen.
- **Auth is a visual mock, not a control.** No real credentials, password storage, network, or crypto in the auth screens. Never prefill a real email/identity. Real authentication (IdP/SSO exchange, server-side session, enforced MFA) is Phase 2, and sending identity/credentials anywhere is a compliance decision, not just engineering.
- Retired conventions are listed under Direction → Retired. Do not reintroduce them.

---

## Working discipline

1. **Phase 1 stays single-file.** No external deps, build step, or network. Phase 2 retires this.
2. **Build behind the seam.** Matching goes through `getResponse`, never wired straight into the UI. Match state-scoped (current chips first).
3. **Read before editing.** The file is large and cross-referenced.
4. **Validate JS:** extract the `<script>`, run `node --check`. Confirm brace/paren balance after big edits.
5. **Verify by rendering — don't assume.** Rendering IS available (confirmed 2026-06-22): serve the folder with `python3 -m http.server 8000` from the project dir, then drive a connected Chrome via the Claude-in-Chrome browser tools to `http://localhost:8000/vroozi-ai.html` and screenshot. Resize the window to phone (~390–430 wide) and tablet widths; the preview shell + device-mode handle the rest. (Note: the agent's Linux sandbox can't render — no GPU/X libs, no root — and can't reach the Mac's localhost; rendering happens through Chrome on the user's machine, not the sandbox.) For a label-only change, `node --check` + a structural parse is still an acceptable fast path, but visual changes should now be screenshotted, not assumed.
6. **Cover the new states:** no-match, empty input, and (Phase 2) loading / error / timeout — not just the happy path.
7. **Scale-aware positioning:** `getBoundingClientRect()` offsets inside the frame divide by `window.__appScale || 1` (see `openReqDropdown`/`openPODropdown`).
8. **Phase 2 only:** no keys in client code; route through a server-side proxy. Sending real spend data to an external model is a compliance decision (data residency, FedRAMP/CMMC), not just engineering.
9. **Deliver — coupled delivery (authoritative).** A change to `vroozi-ai.html` is not done until the guide and **both** changelogs are reconciled in the same pass. The two tracks are no longer delivered independently; the coupling is one-directional (app change ⇒ guide reconcile, never the reverse — pure guide-only work still touches only the guide docs). Every app change, do all of this:
   1. **App:** save the updated HTML; bump the single `APP_VERSION` constant (v1.30.0+ — it drives every in-app version display via the About screen; the three old sidebar/rail/inbox stamps were removed in v1.30.0); add a `CHANGELOG.md` entry.
   2. **Reconcile the guide (required every time, even for pure-logic changes):**
      - Run `node tools/sync-styleguide-tokens.mjs --check`. If `:root` changed, re-sync (run without `--check`) and **recompute the §09 contrast ratios by hand** — the gate checks swatch/dot parity, not ratios.
      - Scan the diff for any surface the guide mirrors: component CSS or markup, a keyframe added/removed, an interaction pattern, a control size, a token. Update the matching guide specimen/section for each. (The component CSS is a hand-maintained mirror the token generator does **not** touch — see Single source of truth.)
      - Add a `STYLEGUIDE-CHANGELOG.md` entry **every time — even when nothing in the guide changed** (record: "app vX reviewed; drift `--check` green; no guide-facing change"). Both changelogs advance together so drift can't accumulate silently.
      - Bump the guide's in-HTML version stamp to match the new `STYLEGUIDE-CHANGELOG` top, in all four places (sidebar `.toc-meta`, header `.sg-badge`, §11 footer, §15 footer), and advance its "synced through app vX" pointer. **The stamp must always equal the top of `STYLEGUIDE-CHANGELOG.md`** — it silently froze at `v1.0.6` for seven revs once; never again.
   3. **Verify both files:** `node --check` the extracted `<script>` + tag balance for each; drift `--check` green; render-check anything visual in Chrome.
   4. Move to a repo once it stops being one file (Phase 2); a git pre-commit hook running `--check` + the reconciliation checklist is the natural enforcement point then.

---

## Changelog

> **Canonical changelog is now `CHANGELOG.md`** (Keep a Changelog format, updated every session). v1.23.0 and v1.22.1 live there in full. The entries below are archival history through the v1.22.0 rename — kept here, not duplicated into `CHANGELOG.md`.

- **Initial:** 6 auto-playing flows. → chip-driven interactive, touch-first, branching + Replay. → presenter run-sheet + cheat-sheet. → removed feedback/book-a-demo cards. → CFO depth (identified-vs-realized; anomaly auto-hold; Grainger thread). → real Vroozi logo; iPad scroll fix. → Universal Search omnibox; Shop nav. → dynamic greeting. → Requests + Inbox; generalized names.
- **v1.20.5** — Snap→Home dead-zone fix; parameterized voice standing-desk context; chip-overlap `syncPad`; rotation support (Portrait/Landscape + iPad rail + auto-fit).
- **v1.20.7** — On-device full-bleed mode; embedded logo + gold "AI" in rail; PWA meta + inline manifest; DevTools iPad detection fallback; safe-area padding.
- **v1.20.8** — Purchase Orders screen; Track My Order timeline; Inbox version stamp.
- **v1.21.1** — Version bump.
- **Direction change (spec)** — pivot from scripted presentation build to internal build in active development. Two-phase plan (free-text→scripted, then real generation); `getResponse` seam defined as the Phase 1→2 boundary; sales conventions retired; companion assets out of scope; presentation scaffolding flagged for review. No code changed in that entry.
- **v1.23.0 — Authentication flow (front-end mock).** Added three screens in the charcoal+gold language: `screen-auth` (SSO-first sign-in with passkey option and an expandable email+password fallback), `screen-authmfa` (6-digit code with an on-screen numeric keypad, auto-verify), `screen-authlock` (returning-user Face ID lock with scan animation + "use a different account"). New sidebar nav entry "Authentication"; bottom-nav Profile routes to the lock screen. SSO→MFA→Home, passkey→Home, email→MFA→Home, lock→Home, sign-out (lock "different account")→welcome. Self-contained auth JS module + `resetAuth`/`resetAuthMfa`/`resetAuthLock` wired into `resetForScreen`; logo copied from sidebar at init. Not gated on load (app still opens on Home). Mock only — any input succeeds, no credentials/network/crypto. Also bumped all three version stamps to v1.23.0 and fixed the stale rail "Vroozi SpendTech®" stamp → "Vroozi AI". Verified: `node --check`, structural parse (all JS id refs resolve, screens registered), div/button tag balance. Pixel render not run — no browser host allowlisted in this environment; needs a first-load visual check at iPhone 390×844 and iPad 1194×834.
- **v1.22.1 — Cut the Replay button.** Removed the floating reset FAB entirely: `.reset-fab` CSS (base + device-mode + `@media (hover:none)` rules), the `#resetFab` button markup, the `showReset` toggle in `showScreen`, and the `tap($('resetFab'), …)` handler. Cleaned two stale comments ("rep can tap Replay"). `resetForScreen` kept (still drives per-screen reset on navigation). Settled the scaffolding question (see Direction → Scaffolding keep/cut): full-bleed mode reclassified as runtime; desktop shell + toggles kept through Phase 1. No other behavior/logic/CSS change. Verified via `node --check` + structural parse + grep for orphaned refs (zero); pixel render not run — no browser host allowlisted in this environment.
- **v1.22.0 — Rename to "Vroozi AI."** Stripped demo/prototype from the product surface: `<title>` → "Vroozi AI"; both sidebar/inbox version stamps → "v1.22.0 · Vroozi AI"; SpendTech footer version bumped; sidebar nav label "Demo Flows" → "Flows"; cleaned two stale code comments (chip comment, engine banner). File renamed `vroozi-ai-demo.html` → `vroozi-ai.html`. Internal `reset*Demo` function names left unchanged (not user-facing). No behavior/logic/CSS changes; verified via `node --check` + structural parse (pixel render not run — browser host not allowlisted in this environment).

---

## Known constraints / open items

- **Scaffolding decided (2026-06-22):** Replay cut (v1.22.1); full-bleed reclassified as runtime; desktop shell + toggles kept through Phase 1, retire at Phase 2. Only open thread: cut the shell sooner if review never happens on a laptop. See Direction → Scaffolding keep/cut.
- Spend Intelligence is static by design; could become chip-driven / generative.
- Requests/Orders text-search fields are display-only; status dropdowns are the working filters.
- The Video modality concept (warehouse walk-through → reorder) is an assumption about "video search" in procurement — confirm with stakeholders; the analyze → result → action plumbing stays if the concept changes.
- **Phase 2 gate:** real generation needs network + server-side key + (for real data) a compliance path. A product/compliance decision, not only engineering.
- **Auth (v1.23.0, extended v1.30.0) is a visual mock**, not gated on load. Real sign-in (IdP/SSO, server-side session, enforced MFA, passkey/WebAuthn) is Phase 2 and crosses the same compliance boundary as generation — don't fake real auth in the single file. **Decided v1.30.0:** load stays ungated (boot on Home); Profile is its own screen, lock is reached via Profile → Sign out and the sidebar. Still by design: passkey skips MFA (passkey → Home); MFA error is a reserved-code mock (`000000`).
- `screen-tracking` back uses `data-nav="orders"`; bottom nav doesn't highlight Orders on the detail sub-screen (acceptable, improvable).
- Optional cleanup: internal `reset*Demo` identifiers still carry the old name.
- Render verification is available via Chrome (Claude-in-Chrome) against a local `python3 -m http.server 8000` → `http://localhost:8000/vroozi-ai.html`. The agent's own sandbox still can't render (no X libs / no root) and can't reach the Mac's localhost — rendering runs through the user's Chrome. `node --check` + structural parse remains the fast path for label-only changes; screenshot anything visual.

- **App-side design-token & accessibility issues — mostly resolved v1.33.0–v1.40.0** (see the arc below; per-version detail in `CHANGELOG.md`). The original list (the `--color-primary`/`--color-warning` `#E8A820` collision, `--color-text-muted` AA failure, no shared button base, two input focus treatments, gold-tint pill collisions, off-scale sizes, two sub-44px targets, missing `:focus-visible`, stale "SpendTech" `:root` comment) was catalogued in `STYLEGUIDE-NOTES.md` → Design-system inconsistencies; the guide's §10 and that list are updated to mark what shipped.

## Design-system & accessibility state (v1.33.0–v1.40.0)

A token-and-accessibility arc landed on top of v1.32.1. Authoritative per-version detail is in `CHANGELOG.md`; this is the orientation a fresh session needs:

- **Token foundation (v1.33.0–v1.33.1, backlog P0-2 + net-new):** surface ramp consolidated — three near-blacks → one `--color-shell` (the elevated steps were already ~1.2:1, left as-is; a recessed well can't reach 1.2:1 below a near-black canvas, so it stays border-carried). 13 gradient literals → `--grad-*`/`--scan-line`/`--sso-glyph`; white overlays → `--state-hover/active/rest/press-fill`; black scrims → `--scrim`/`-soft`/`-strong`; repeated semantic hex → `var(--color-*)`; `color:#fff` split into `--color-text` vs `--color-text-on-accent`; dark-ink-on-gold → `--color-on-primary`. All role-named (hue-free) so a Phase-2 theme can re-skin centrally. `:root` 79 → 97 tokens; **zero visual change**, proven by render compare.
- **Button bases (v1.34.0, P1-4):** the 11 button classes collapsed onto two shared grouped bases (text + circular-icon), each leaf reduced to its modifier props. Pixel-identical (per-selector declaration diff). Cosmetic harmonization (one `:active` scale / glow policy / radii) deliberately deferred.
- **Sizing tokens (v1.35.0, P2-2 + part of P2-1):** added `--text-3xs` (10px, rem-based for text-zoom / WCAG 1.4.4) and `--space-7` (28px). ~34 `10px` → `--text-3xs` (no rendered size change); four `9px` → `--text-2xs`. `:root` 97 → 99. Off-scale *padding* snapping deferred to the harmonization pass.
- **Accessibility / Track B (v1.36.0–v1.40.0):** primary-nav `<div>`s → native `<button>`s inside `<nav>` landmarks with `aria-current` (B1); live regions — toast `role="status"`, transcripts `role="log"`, omnibox `aria-live`, typing `role="status"`, `aria-busy` on the in-flight auth button (B3); the Universal Search overlay is a focus-trapped `role="dialog" aria-modal="true"` with Escape + focus restore, plus the remaining controls (mode pills, inbox tabs, close, omnibox trigger bar, suggestion rows) → buttons and 44px hit-areas on the last sub-44 icon buttons (B2); focus moves into the new screen on navigation (B4). Disabled controls use the native `disabled` attribute. **Keyboard-verified; not yet screen-reader-certified — a manual NVDA/VoiceOver pass is the remaining 508/AA gate.**
- **Still open / Phase 2:** the light + high-contrast themes (Track C — needs the Phase-2 shared-stylesheet move; gold can't be a foreground accent on white, so light is a re-tune, not a token flip — see `THEMING-FEASIBILITY.md`); the cosmetic button harmonization + off-scale padding snapping; RTL; and the manual screen-reader conformance pass.
