# Asset Index — Vroozi AI

Orientation + manifest for this project, written so an **AI assistant** (Claude) and a human can both index it quickly. If you're an assistant picking this up in a new Claude project: **read this file first, then follow the read order below.** App `vroozi-ai.html` is at **v1.40.1**; design guide `vroozi-ai-styleguide.html` at **v1.0.29** (2026-06-23).

## What this project is

An internal, single-file build of an AI-assisted procure-to-pay experience for Vroozi (B2B procure-to-pay — voice/chat/snap ordering, spend analytics, anomaly detection, PR/PO tracking, a mock auth flow). It's in active development, iterated with design. Two tracks, two assets, kept in lockstep: the **app** (`vroozi-ai.html`) and a **design-guide** reference (`vroozi-ai-styleguide.html`) that mirrors the app's tokens but never changes it.

## Read order

1. **`ROADMAP.md`** — where we are, what's next, the asset map. The front door.
2. **`HANDOFF.md`** — thin orientation.
3. **`PROJECT-NOTES.md`** — the authoritative spec (read in full before changing the app).
4. **`project-instructions.md`** — the working rules/config to load into your Claude project.
5. Then the region of `vroozi-ai.html` you're about to touch.

## Asset manifest

| File | Kind | Authority | What it is / when to read |
|---|---|---|---|
| `vroozi-ai.html` | App | **Canonical product** | The single self-contained app (HTML/CSS/JS in one file). Its `:root` is the canonical token source. Open in a browser or serve the folder. |
| `vroozi-ai-styleguide.html` | Design guide | Mirror (app is canonical) | Self-contained reference asset documenting the design language (tokens, type, components, measured contrast). Mirrors the app's `:root`; **never changes the app.** |
| `PROJECT-NOTES.md` | Spec | **Authoritative (app)** | Direction, phased plan, the `getResponse`/`searchCatalog` seam, architecture, conventions, working discipline, and the v1.33–v1.40 design-system/accessibility state. The source of truth. |
| `STYLEGUIDE-NOTES.md` | Spec | **Authoritative (guide)** | Spec for the guide asset + the token sync / drift policy. |
| `CHANGELOG.md` | Log | Per-version history (app) | Keep-a-Changelog; newest on top. Update on every app change. |
| `STYLEGUIDE-CHANGELOG.md` | Log | Per-version history (guide) | Guide change history; advances in lockstep with `CHANGELOG.md`. |
| `tokens.json` | Tokens | Documentation-only | DTCG token source, 99 tokens, regenerated from `:root` at v1.40.0. **The app `:root` is canonical** — regenerate this when `:root` changes; it's outside the drift `--check`. |
| `tools/sync-styleguide-tokens.mjs` | Tool | Drift gate | Node, zero-dep. `node tools/sync-styleguide-tokens.mjs --check` must exit 0 (verifies guide `:root` ↔ app, swatches, §09 dots). Run `without --check` to sync. |
| `ROADMAP.md` | Status | Front door | Current state, prioritized next work, asset map, working discipline. Start here. |
| `HANDOFF.md` | Orientation | Thin pointer | One-screen orientation → points to PROJECT-NOTES. |
| `THEMING-WORKPLAN.md` | Planning | Historical + sequencing | Track A/B/C plan. A (tokens/buttons/sizing) and B (508 semantics) shipped v1.33–v1.40; status-bannered. Track C (themes) is Phase 2. |
| `THEMING-FEASIBILITY.md` | Planning | Reference | Why light ≠ a token flip (gold fails as a foreground accent on white); what each theme costs. |
| `THEMING-HC-SPEC.md` | Planning | **Live next-deliverable** | Concrete, implementable high-contrast ("ADA") theme spec — the first Track C deliverable. Token overrides + `[data-theme]` mechanism + build sequence. |
| `DESIGN-BACKLOG.md` | Planning | Historical | Original P0/P1/P2 punch list; mostly shipped (status-bannered). |
| `project-instructions.md` | Config | Project rules | The Claude-project working rules. Load into your Claude project's custom instructions. |
| `ASSET-INDEX.md` | Index | This file | The manifest you're reading. |

Not in this handoff: an `archive/` of 13 superseded review/handoff docs exists in the source folder (provenance only). A few `CHANGELOG`/`STYLEGUIDE-CHANGELOG` entries name those by filename — historical references, not needed to work.

## Rules an assistant must follow here

- **Phase 1 = one self-contained HTML file.** No dependencies, no build step, no JS/data network calls — the Google Fonts link is the only allowed exception. No `[data-theme]` switch yet; themes are Phase 2 (Track C).
- **Coupled delivery on every app change** (full rule: `PROJECT-NOTES.md` → Working discipline → Deliver): edit `vroozi-ai.html`; bump the `APP_VERSION` constant; run `node tools/sync-styleguide-tokens.mjs` then `--check` (exit 0); recompute the guide's §09 contrast by hand for any changed color token; mirror changed component CSS into the guide; bump the guide's **four** in-HTML stamps + `STYLEGUIDE-CHANGELOG.md`; update `CHANGELOG.md` and `PROJECT-NOTES.md`. The two changelogs always advance together; guide-only edits touch only guide docs.
- **Verify, don't assume.** Extract the `<script>` and `node --check`; check tag balance / structural parse; then render through a real browser (`python3 -m http.server 8000`, then Chrome to `http://localhost:8000/vroozi-ai.html`) and screenshot at phone (~390–430) and tablet widths. Behavioral accessibility needs keyboard testing and a manual screen-reader pass — automated checks don't observe SR output.
- **Synthetic data only.** Generalized names ("Shaz", approver "Vroozi Approver", org "ACME-TEST-CO"), `ACME-TEST-*` SKUs, round/fake prices. Never real customer/vendor/spend data, credentials, or PII anywhere in the file (incl. comments/tests). This is a regulated B2B context — keep it obviously synthetic.
- **The Phase 1→2 seam is one function.** `getResponse(userText, context)` (and `searchCatalog`/`getUSearchResponse`) return fixed shapes the UI already renders; Phase 2 reimplements only those bodies. Build behind the seam, never wire matching into the UI.

## Current state & next (summary — detail in ROADMAP)

Shipped: the Phase-1 seam, a role-named token layer, shared button bases, sizing tokens, and full Track B keyboard/ARIA accessibility (native buttons, `nav` landmarks, `aria-current`, live regions, a focus-trapped search dialog, focus-on-screen-change). **Not yet screen-reader-certified** — a manual NVDA/VoiceOver pass is the open 508/AA gate. Next: that SR pass, a cosmetic button-harmonization pass, then Track C themes (high-contrast spec is ready), then Phase 2 real generation. See `ROADMAP.md` → "What's next."
