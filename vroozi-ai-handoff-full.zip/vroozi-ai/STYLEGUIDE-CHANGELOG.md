# Changelog — Vroozi AI Design Guide

All notable changes to `vroozi-ai-styleguide.html` are recorded here. The authoritative spec for the guide is `STYLEGUIDE-NOTES.md`. This file is scoped to the design-guide asset only; app changes live in `CHANGELOG.md`.

Format follows [Keep a Changelog](https://keepachangelog.com/). Newest on top.

---

## [1.0.29] — 2026-06-23

### Reviewed (app v1.40.1 — nav button-bevel fix)
- **No guide-facing change.** App v1.40.1 added `border:none` to `.nav-item` / `.bottom-nav-item` to suppress a leaked UA button bevel. The guide's nav specimens are `<div>`s (`.nav-item-demo`, `.bottom-nav-item`), so they never rendered the bevel and need no mirror. Drift `--check` green (99 tokens).
- **Stamps** bumped to `guide v1.0.29 · app v1.40.1` (all four), per the always-advance-together rule.

## [1.0.28] — 2026-06-23

### Changed (guide-only — reconcile residual specimen drift)
- **Mirrored the last v1.33.0 token migration into the §06 specimens** (previously deferred, flagged in 1.0.23/1.0.25): `.auth-btn .sso-glyph` now uses `var(--sso-glyph)` + `var(--color-text-on-accent)` (was the literal `linear-gradient(135deg,#5FA8F5,#8B7BF0)` + `#fff`); `.anomaly-btn.reject` and `.mic-btn.active` use `var(--color-text-on-accent)` (was `#fff`); `.mic-btn` and `.snap-result-badge` use `var(--color-on-primary)` (was `var(--vroozi-ink)`). Resolves identically — the aliases point at the same values — so no visual change; this is code-fidelity so the guide's mirrored CSS matches the app's role tokens.
- **Stamps** → `guide v1.0.28 · app v1.40.0` (all four). No app change (guide-only edit); token pointer stays app v1.35.0, "documented through app v1.40.0" unchanged.

### Notes
- Surfaced by the pre-handoff asset audit. No `:root`/token change; drift `--check` green (99 tokens). Media-context whites in the snap/camera specimens stay literal, matching the app.
- Verified: `node --check` on the guide script; tag balance; `--check` green.

## [1.0.27] — 2026-06-23

### Changed (sync to app v1.40.0 — B4 focus management)
- **§09 2.1.1 + 4.1.2** updated: `showScreen()` now moves focus into the new screen on navigation; result-action CTAs confirmed already buttons. The Track-B code work is recorded as essentially complete, with the **manual keyboard + screen-reader conformance pass** called out as the remaining gate.
- **Keyboard/ARIA posture note** updated to reflect B4 shipped and reframed around the SR pass.
- **Stamps** → `guide v1.0.27 · app v1.40.0` (all four); specimens documented through v1.40.0. Token pointer stays **app v1.35.0**.

### Notes
- No `:root`/token/component-CSS change (B4 is a JS focus-management addition); drift `--check` green (99 tokens). No specimen mirror needed.
- Verified: `node --check` on the guide script; tag balance; `--check` green.

## [1.0.26] — 2026-06-23

### Changed (sync to app v1.39.0 — omnibox trigger + suggestion rows)
- **§09 2.1.1 Keyboard** updated: the omnibox trigger bar and the search suggestion rows are now buttons (the trigger gap flagged at v1.38.0 is closed). Remaining open: focus management on screen change; a check of the generated result-action CTAs.
- **Keyboard/ARIA posture note** updated accordingly.
- **Stamps** → `guide v1.0.26 · app v1.39.0` (all four); specimens documented through v1.39.0. Token pointer stays **app v1.35.0**.

### Notes
- No `:root`/token change; drift `--check` green (99 tokens). Appearance unchanged (the conversions are visually inert); no specimen mirror needed.
- Verified: `node --check` on the guide script; tag balance; `--check` green.

## [1.0.25] — 2026-06-23

### Changed (sync to app v1.38.0 — Track B step 2, search dialog + secondary controls)
- **§09 accessibility:** 2.1.1 Keyboard + 4.1.2 ARIA rows updated — the search overlay is now a focus-trapped `role="dialog" aria-modal="true"` (Escape + focus restore), mode pills and inbox tabs are buttons. Remaining open: focus management on screen change; the omnibox search-bar trigger still a non-focusable div.
- **Keyboard/ARIA posture note** updated — dialog/focus-trap, pills/tabs buttons, and the home-settings/topbar 44px hit-areas moved to "shipped."
- **§10 "Sub-44px targets" → resolved:** all circular icon buttons now carry a 44×44 `::before` hit-area (home-settings/topbar added app v1.38.0).
- **Stamps** → `guide v1.0.25 · app v1.38.0` (all four); specimens documented through v1.38.0. Token pointer stays **app v1.35.0** (B2 has no `:root` change).

### Notes
- No `:root`/token change; drift `--check` green (99 tokens), §09 contrast unaffected. The guide's static overlay specimen (§06) is unchanged in appearance — the dialog role + focus trap are behavior, not visual; no specimen mirror needed.
- Verified: `node --check` on the guide script; tag balance; `--check` green.

## [1.0.24] — 2026-06-23

### Changed (sync to app v1.37.0 — Track B step 3, live regions)
- **§09 accessibility, 4.1.2 row** updated: live regions now shipped — toast `role="status"`, transcripts `role="log"`, omnibox `aria-live`, typing-indicator `role="status"`, `aria-busy` on the auth button; disabled controls use native `disabled`. Remaining open: search-overlay `role="dialog"` + focus management.
- **Keyboard/ARIA posture note** updated to move live regions + busy states from "still open" to "shipped (v1.37.0)."
- **Stamps** → `guide v1.0.24 · app v1.37.0` (all four); specimens documented through v1.37.0. Token pointer stays **app v1.35.0** (B3 has no `:root` change).

### Notes
- No `:root`/token change, no component-CSS change (B3 is additive ARIA attributes + small JS in the app); drift `--check` green (99 tokens), §09 contrast unaffected. No guide specimen mirror needed.
- Verified: `node --check` on the guide script; tag balance; `--check` green.

## [1.0.23] — 2026-06-23

### Changed (sync to app v1.36.0 — Track B step 1, keyboard-operable nav)
- **§09 accessibility table:** `2.1.1 Keyboard` and `4.1.2 Name, role, value` moved from "Not evaluated" to **Partially** — primary nav is now native `<button>`s inside `nav` landmarks with `aria-current="page"`; MFA keys/toggles already had names/roles. Remaining gaps (search-overlay dialog, toast/loader live regions, `aria-busy`/`aria-disabled`) listed.
- **Keyboard/ARIA posture note** rewritten from "not yet specified" to "in progress": records what B1 shipped and what B2–B4 still cover (overlay dialog + focus trap, live regions, focus-on-screen-change, the two icon hit-areas, RTL).
- **§10:** marked **"No shared button base" resolved (app v1.34.0)** — catching up the A3 consolidation that this row still described as open.
- **Stamps** → `guide v1.0.23 · app v1.36.0` (all four); specimens documented through v1.36.0. Token pointer stays **app v1.35.0** (B1 has no `:root` change).

### Notes
- **No component-CSS mirror needed.** The guide's nav/card specimens are illustrative `<div>`s (it even uses a `.nav-item-demo` class) documenting appearance, which B1 doesn't change; the button reset is inert on non-button demos. Drift `--check` green (99 tokens, §09 contrast unaffected).
- Verified: `node --check` on the guide script; tag balance; `--check` green; render of §09/§10.

## [1.0.22] — 2026-06-23

### Changed (sync to app v1.35.0 — sizing tokens)
- **`:root` re-synced** (97 → 99 tokens): `--text-3xs` (0.625rem / 10px) and `--space-7` (28px). Drift `--check` green.
- **§03 Typography** — added a `--text-3xs · 0.625rem` row to the scale and rewrote the note below it: 10px is now the rem-based floor (added app v1.35.0 for text-zoom / WCAG 1.4.4); the four old 9px labels were raised to `--text-2xs`.
- **§04 Spacing** — added the `--space-7 · 28px` swatch (scale now continuous 1–8) and updated the anatomy note.
- **Specimen CSS** — migrated the mirrored `font-size:9px`/`10px` literals to `var(--text-2xs)`/`var(--text-3xs)` to match the app.
- **§10** — the "Off-scale values" row is now "Off-scale paddings": text is tokenized and `--space-7` exists; only off-scale paddings remain (deferred to harmonization).
- **Stamps** → `guide v1.0.22 · app v1.35.0` (all four). Token pointer **advances to app v1.35.0** (this is a `:root` change); synced-through / specimens → v1.35.0.

### Notes
- §09 contrast untouched — the change is dimensions, not colours. Specimens render identically except the four raised 9px labels (now 11px, matching the app).
- Verified: `node tools/sync-styleguide-tokens.mjs --check` green (99 tokens); `node --check` on the guide script; tag balance; render of §03/§04 scales.

## [1.0.21] — 2026-06-23

### Changed (sync to app v1.34.0 — button consolidation P1-4)
- **Mirrored the shared text-button base** into the §06 specimen CSS: a grouped base rule over the six buttons the guide documents (`.auth-btn`, `.uso-cta`, `.anomaly-btn`, `.control-btn`, `.snap-order-btn`, `.pf-save`) holding `font-family`/`cursor`/`transition`/tap-highlight/touch-action, with each leaf trimmed to its deltas — matching the app's refactor. (The guide doesn't document the icon buttons or `.inbox-btn`, so no icon base here.)
- **Corrected stale v1.33.0 specimen drift on the touched lines:** `.uso-cta`, `.snap-order-btn`, `.pf-save` now use `var(--color-on-primary)` (were still `var(--vroozi-ink)` — same value, rendered identically).
- **Stamps** → `guide v1.0.21 · app v1.34.0` (all four). Token pointer stays **app v1.33.0** (last `:root` change); synced-through / specimens advance to **v1.34.0**.

### Notes
- App v1.34.0 is a component-CSS-only refactor; **no `:root` change**, drift `--check` green (97 tokens), §09 untouched. The specimens render identically (the base only regularizes invisible foundation props).
- **Known residual specimen drift to reconcile** in a future guide-mirror pass (predates this sync, renders identically via aliases): `.auth-btn .sso-glyph` still uses the literal `linear-gradient(135deg,#5FA8F5,#8B7BF0)` + `#fff` (app: `var(--sso-glyph)` / `var(--color-text-on-accent)`); `.mic-btn` and `.anomaly-btn.reject` still use `var(--vroozi-ink)` / `#fff`.
- Verified: `node tools/sync-styleguide-tokens.mjs --check` green; `node --check` on the guide script; tag balance; render of the §06 button specimens.

## [1.0.20] — 2026-06-23

### Added (sync to app v1.33.1 + new-token documentation)
- **§02 — two new swatch subsections.** "Foreground-on-fill &amp; interaction states" documents `--color-on-primary`, `--color-text-on-accent`, the four `--state-*` fills, and the three `--scrim*` tokens (the on-fill pair shown as Aa-on-fill chips; states/scrims as translucent checker chips). "Gradient roles" documents the nine `--grad-*`/`--scan-line`/`--sso-glyph` tokens as bars (no `.hex` label — multi-stop values live in `:root` and are covered by the parity check). Swatch count 25 → 34.
- The new color/rgba swatches are generator-validated; the gradient bars are intentionally hex-less so the drift check skips them.

### Changed
- **§02 "Current reality (honest)"** rewritten: app v1.33.0 added the first substantial alias tier (surfaces, on-fill, state, scrim, gradients flow through role tokens), so the "mostly flat" framing no longer holds for those families. Brand/semantic primitives and the absent build step are still called out as flat.
- **Stamps** → `guide v1.0.20 · app v1.33.1` (all four). Token pointer stays **app v1.33.0** (last `:root` change); synced-through / specimens-documented advance to **v1.33.1**.

### Notes
- App v1.33.1 is a one-line component-CSS change (`.back-btn:hover` → `--state-active-fill`); **no `:root` change**, so drift `--check` is green (97 tokens) and §09 ratios are untouched. The new swatches reference existing tokens — `--check` validates all 34.
- Verified: `node tools/sync-styleguide-tokens.mjs --check` green; `node --check` on the guide script; tag balance; first-load render of the new §02 subsections.

## [1.0.19] — 2026-06-23

### Changed (sync to app v1.33.0 — token-layer foundation)
- **`:root` re-synced** via the token generator (79 → 97 tokens). Added `--color-shell`, `--color-on-primary`, `--color-text-on-accent`, the `--state-*` fills, the `--scrim*` set, and the `--grad-*`/`--scan-line`/`--sso-glyph` gradient tokens. Drift `--check` green (97 tokens, 25 swatches, contrast dots match).
- **Component-CSS mirror** updated by hand (the generator doesn't touch it): the seven specimen rules that used `--color-surface-pop` (`.product-card`, `.pr-card-header`, `.chat-chart`, `.anomaly-compare`/`-col`, `.specimen.pop`, code chips) now use `--color-shell`.
- **§02 color swatch** — replaced the removed `--color-surface-pop` swatch with `--color-shell`; updated the `--vroozi-ink`/`--vroozi-navy` "use" text to mark them brand primitives behind the new role tokens.
- **§14 elevation** — rewrote the ladder narrative: the upward ramp is monotonic at ~1.2:1/step, the recess sits on `--color-shell` and is carried by its border (1.2:1 below a near-black canvas is unreachable). Corrected pre-existing stale hex labels on the elevation specimen (`#1B2230`→`#1F2735`, `#232C3C`→`#2A3446`, recess → `#0A0C11`).
- **§09** — tidied the 1.4.1 "Use of color" cell: dropped the outdated "until proposal 5B" clause (5B shipped ~app v1.25.0); rating stays **Partially** because gold is still primary + link + Financial-Review status.
- **Stamps** bumped to `guide v1.0.19 · app v1.33.0` (all four) plus the token pointer, which advances off the frozen app v1.29.0 to **v1.33.0** since this is the first `:root` change since the font swap.

### Notes
- §09 contrast ratios unchanged — all text rows are measured on canvas/surface/surface-2, none of which moved; only the redundant near-blacks merged. No hand recompute required this pass (gate confirms dots match).
- Follow-up: dedicated swatches/§ for the 18 new role tokens (state/scrim/gradient) are not yet documented beyond `--color-shell`; add in a guide-enrichment pass.

## [1.0.18] — 2026-06-22

### Reviewed (app v1.32.1 — catalog expanded to 50 items)
- **No guide-facing change.** App v1.32.1 is a data-only `CATALOG` expansion (16→50 items, 4 new categories) — no new component, CSS, token, or interaction. The existing `.catalog-card` / `.cat-chip` specimen (added in 1.0.17) already covers every category; the guide doesn't enumerate catalog items. Drift `--check` green (79 tokens, no `:root` change).
- **Stamps** bumped to `guide v1.0.18 · app v1.32.1` (all four) and "synced through v1.32.1" / "documented through app v1.32.1", per the always-advance-together rule.

## [1.0.17] — 2026-06-22

### Added (sync to app v1.32.0 — product catalog + search seam)
- **§06 specimen — Catalog browse card + filter chips.** New `.catalog-card` (flat browse row: emoji · name/supplier/tags · mono price) and `.cat-chip` / `.cat-chip.active` category filter, mirrored verbatim from app v1.32.0 into the guide `<style>`. Card-idioms anatomy expanded from three to **four** (`.home-card` / `.product-card` / `.catalog-card` / `.pr-card`+`.req-card`).
- **Anatomy — one product render path.** Records that `.product-card` (inline) and `.snap-product-card` (Snap) are now emitted by a single app helper `productCardHTML(item, opts)` from the embedded `CATALOG`; `.catalog-card` is the browse-list variant. The guide mirrors the resulting class CSS, not the helper. Continuity items (gloves $22.99/box, MacBook $2,499 / refurb $1,799) render identically everywhere.

### Changed
- **Stamps** bumped to `guide v1.0.17 · app v1.32.0` (all four: sidebar `.toc-meta`, header `.sg-badge`, §11 sync note, §15 governance note). §11/§15 now read "component specimens documented through app v1.32.0." Token stamp stays app v1.29.0 (still the last `:root` change).

### Notes
- **No `:root`/token change** in app v1.32.0 (new component CSS `.catalog-*` + markup + logic only, using existing tokens) — drift `--check` green (79 tokens); §09 contrast unaffected. `tokens.json` unchanged.
- Verified: `node tools/sync-styleguide-tokens.mjs --check` green; `node --check` on the guide script; tag balance; first-load render of the new §06 catalog specimen.

## [1.0.16] — 2026-06-22

### Added (sync to app v1.31.0 — Profile detail form + Settings sub-nav)
- **§06 specimen — "Profile form & Settings sub-nav."** Shows the `.pf-card`/`.pf-grid` labelled form with a gold `.pf-save`, and the Settings `.settings-sidenav` + swapped `.settings-pane` with the `.seg` theme control and a `.sec-pill` MFA row. New component CSS mirrored verbatim into the guide `<style>` (`.pf-*`, `.settings-layout`, `.settings-sidenav`, `.settings-navitem`, `.settings-panes`, `.settings-pane-title`, `.seg`, `.seg-opt`, `.sec-pill`).
- Anatomy records the security stance: the MFA pill is **Enabled and non-interactive** — never a control that can disable it.

### Changed
- **`.settings-row-main`** mirror updated to `flex:1` + `min-width:0` on its text block (matches the app fix so long titles wrap beside a trailing pill instead of overlapping).
- **Stamps** bumped to `guide v1.0.16 · app v1.31.0` (all four). §11/§15 now read "component specimens documented through app v1.31.0." Token stamp stays app v1.29.0 (still the last `:root` change).

### Notes
- **No `:root`/token change** in app v1.31.0 — drift `--check` green (79 tokens); §09 contrast unaffected. Component-specimen + prose sync only.
- Verified: `node --check` on the guide script; tag balance; drift `--check`; first-load render of the new §06 specimen.
- Follow-up same session: synced the mirror to the app's narrower Settings sub-nav (`.settings-sidenav` 112→88px, gap 14→12, navitem padding) and `.settings-row-title { overflow-wrap:break-word }` — fixes the Privacy pane overflow on phone width. (App also moved the Home gear cog under the bell and hid it in iPad landscape; no guide-facing surface.) Drift `--check` still green.
- Corrected the toc-meta token pointer: it had drifted to "tokens from app v1.30.0/v1.31.0" in 1.0.15–1.0.16, but the last `:root` change was the v1.29.0 Inter/Roboto Mono swap (v1.30/v1.31 added component CSS only). Now reads "tokens from app v1.29.0 · synced through v1.31.0", matching the §11/§15 prose. The token-sync pointer tracks the last `:root` change; the rev stamp (1.0.16) and "synced through" pointer track reconciliation.
- Logged a new **§10 known-inconsistency** row (and matching `STYLEGUIDE-NOTES.md` bullet): the v1.31.0 Profile form's `.pf-input` / `.pf-save` / `.home-settings-btn` / `.topbar-action` duplicate existing input/button/icon-button patterns — extends the "No shared button base" item for the Phase-2 component package.
- **Regenerated `tokens.json` from the current `:root`** (was a v1.23.1 snapshot, drifted on fonts + surfaces + missing the caution family and chart palette). Now mirrors `:root` exactly — verified 79/79 tokens, 0 mismatches/missing/extra via an alias-resolving diff. Added `color.caution.*` and `color.chart.1–6`, re-pointed `color.warning.*` to the caution aliases, updated the surface colors and the Inter/Roboto Mono font stacks, and refreshed the header note. Still documentation-only (not wired to a build; outside the drift `--check` loop). Also corrected a stale §02 prose claim that "warning still resolves to brand gold" — v1.25.0 re-pointed it to the caution amber — and that `tokens.json` was Phase-2-only (it exists today as a seed).

## [1.0.15] — 2026-06-22

### Added (sync to app v1.30.0 — account surfaces: Profile / Settings / About)
- **§06 Component catalog specimen — Account surfaces.** New specimen showing the Profile card (avatar initial + name + org), Settings rows (with the mock on/off **toggle** and a danger Sign-out row), and About rows. The component CSS (`.profile-card`, `.profile-avatar`, `.settings-group`, `.settings-row*`, `.toggle`, `.about-row*`) is mirrored verbatim from app v1.30.0 into the guide `<style>`. The **toggle** is the one genuinely new reusable control: 42×25 pill, off = `--color-surface-2`, on = `--vroozi-gold` with a 19px knob translated 17px.
- Anatomy note records the single-`APP_VERSION` decision: the About screen is now the only place the version appears (the sidebar/rail/inbox stamps were removed in app v1.30.0).

### Changed
- **Stamps** bumped to `guide v1.0.15 · app v1.30.0` (all four: sidebar `.toc-meta`, header `.sg-badge`, §11 sync note, §15 governance note). §11/§15 now read "component specimens documented through app v1.30.0."

### Notes
- **No `:root`/token change** in app v1.30.0 (only new component CSS + markup + logic) — the token-sync stamp stays "tokens from app v1.29.0" (the last `:root` change, the Inter/Roboto Mono swap). Drift `--check` green, 79 tokens. §09 contrast table unaffected (no color moved).
- Verified: `node tools/sync-styleguide-tokens.mjs --check` green; `node --check` on the guide script; tag balance; first-load render of the new §06 specimen.
- Follow-up same session: app added **Profile and Shop entries to the iPad-landscape rail** (both were unreachable there — Profile under a new "Account" label, Shop in Workspace opening the search overlay). No guide-facing change — the §06 `.nav-item` specimen is generic and the §08 device prose doesn't enumerate rail items; drift `--check` still green. Recorded here so both changelogs stay in lockstep.

## [1.0.14] — 2026-06-22

### Changed (sync to app v1.29.0 — Inter + Roboto Mono font swap)
- **`:root` re-synced** via `tools/sync-styleguide-tokens.mjs`: `--font-ui` now `'Inter', …` and `--font-mono` now `'Roboto Mono', …` (drift `--check` green, 79 tokens). All specimens use the `var(--font-*)` tokens, so they re-render in the new faces automatically.
- **Guide `<link>` swapped** to load Inter + Roboto Mono (the generator doesn't touch the link — done by hand, the component-mirror part of reconciliation).
- **Typography §** prose updated: lead now reads "Inter for all UI; Roboto Mono for anything numeric," section headers "Size scale (Inter)" and "When to use mono (Roboto Mono)," the tabular-figures note now references Inter, and the version-stamp specimen reads v1.29.0.
- **Stamps** bumped to `guide v1.0.14 · tokens from app v1.29.0` (all four places).

### Notes
- Font tokens are the only `:root` change; no color moved, so the §09 contrast table is unaffected (contrast is color, not face) — no recompute needed. Verified: `node --check`, tag balance, drift `--check` green, first-load render of the Typography section.

## [1.0.13] — 2026-06-22

### Changed (sync to app v1.26.2–v1.28.2 — Phase 1 free-text seam)
- **Omnibox is now a real input.** App v1.28.0 turned `#uSoInput` from a fake-caret `<div>` into a native `<input>`. Synced the guide's mirrored `.uso-input` CSS (native caret via `caret-color`, `::placeholder`, no fake `.caret` span) and the Universal Search specimen (`<input … readonly>`). Updated the omnibox anatomy: native caret, focus-moves-to-input on open (now implemented), and the free-text path through `getUSearchResponse` (shares the ConvoEngine matcher, renders its own `.uso-result` card; no-match re-surfaces the catalog).
- **Motion §:** swapped the now-removed `usCaret` specimen for **`inputNudge`** (the empty-submit shake added in app v1.27.0). App v1.28.2 deleted the orphaned `usCaret` keyframe + `.uso-input .caret` rule, so the guide no longer documents them.
- **Interaction patterns §:** added two bullets — the free-text→scripted-match seam (shared matcher, current-branch-first, deliberate no-match, empty-input nudge; chips become suggestions over a live input) and Voice speak-or-type with the mic↔send toggle.
- **Target sizes:** voice mic is 52px inline with the transcript input + send (the standalone 64px `.mic-btn` base remains in CSS).
- **Stale self-version stamps fixed.** The guide's in-HTML stamps (sidebar, header badge, §11 + §15 footers) were stuck at `guide v1.0.6 · app v1.23.1` despite the changelog reaching 1.0.13 — they hadn't been bumped since 1.0.6. Updated all four to `guide v1.0.13 · tokens from app v1.26.0` (last `:root` change; component specimens through v1.28.2). Historical "fix landed in app v1.23.1" references left as-is (correct facts, not stamps).

### Notes
- No `:root`/token change across any of these app versions — drift `--check` green (79 tokens). This is a component-specimen + prose sync, not a token sync. App v1.26.2 (screen-transition + typewriter speed) had no guide-facing surface.
- Verified: `node --check` on the guide script, tag balance, drift `--check`, first-load render.

## [1.0.12] — 2026-06-22

### Changed (sync to app v1.26.1 — pill unification)
- Synced the guide's pill specimen CSS to the app's unified status-pill spec (`.req-pill`/`.pr-badge`/`.product-tag`/`.snap-result-badge` → `padding:4px 10px`, `font-size:var(--text-2xs)`, `font-weight:600`, `inline-flex`+`gap:5px`). The guide's copies had drifted to the old per-class sizes. No `:root`/token change — drift `--check` green. (`.nav-badge`/`.nav-tag` unchanged — nav chrome, not status pills.)

## [1.0.11] — 2026-06-22

### Changed (sync to app v1.26.0 — brand chart palette)
- `:root` re-synced: picked up the 6 new `--chart-1..6` tokens (drift `--check` green).
- Charts §: re-colored the bar/donut specimens off the hardcoded Material hexes (`#1565C0/#0097A7/#4CAF50/#7B1FA2/#C62828`) onto the brand `--chart-*` tokens so the guide matches the app; updated the anatomy note to document the palette (gold/info-blue/success-green/caution-amber/slate/bronze, no Material rainbow).

## [1.0.10] — 2026-06-22

### Changed (doc-only, app v1.25.2)
- Buttons §: updated the States line — `:disabled` (≈45% opacity, wired to guard snap-submit and anomaly reject/review against double-fire) and the gated `:hover` are now documented as defined, not gaps; remaining gap narrowed to a general loading/busy state + `aria-disabled`/`aria-busy`. No `:root`/token change — drift `--check` green.

## [1.0.9] — 2026-06-22

### Changed (doc-only, app v1.25.1)
- §accessibility: added a **Reflow / resize (1.4.4)** bullet recording the app's v1.25.1 fix (`.screen-view` overflow safety-net + `justify-content:safe center` on auth/lock so 200% text scrolls instead of clipping), and flagged the open px→rem item (P2-1/P2-2). No `:root`/token change — drift `--check` stays green.

## [1.0.8] — 2026-06-22

### Changed (sync to app v1.25.0 harmony pass — P0-2 surfaces + P0-3 caution)
- **`:root` + swatches re-synced** via `tools/sync-styleguide-tokens.mjs` (73 tokens, drift `--check` green). New surface ramp (`--color-surface` #1F2735, `--color-surface-2` #2A3446, `--color-surface-pop` #0C0F16) and new caution tokens (`--color-caution` #F2994A / `-bright` #F8B06A / `-light`).
- **§09 contrast table recomputed by hand** for the new surfaces (the tool leaves ratios manual): every text row's surface/surface-2 columns updated; added a `--color-caution` row (8.14 / 6.74 / 5.62 — PASS). `--color-text-muted` still clears AA on the lighter surfaces (5.42 / 4.52). bg column unchanged (canvas didn't move).
- **§10 inconsistencies:** "primary == warning" marked **resolved** — warning now resolves to the caution amber, not gold; CTA-vs-caution 1.4.1 ambiguity closed. Noted gold's remaining primary+link+status triple-duty as a separate follow-up.

### Notes
- App is canonical. Verified after edits: drift `--check` green, tag balance holds. The harmony result was render-verified in the app across home/requests/anomaly (steps visible; caution reads distinct from gold and red).

## [1.0.7] — 2026-06-22

### Changed (sync to app v1.24.0 design-backlog pass)
- **Toast section** — added the `.success` (green) and `.info` (blue) dot specimens + CSS; rewrote the States note (the old "no success/info variant" gap is closed). Documents that genuine successes moved off the gold `.review` dot in app v1.24.0.
- **Target sizes & focus** — recorded the v1.24.0 hit-area additions (`.back-btn`, `.chat-send` via `::before`; `.bottom-nav-item`, `.inbox-btn` via `min-height:44px`) against Apple HIG 44pt; noted the still-open packed controls; updated the Motion bullet for the `prefers-reduced-motion` `iteration-count:1` substitution; and recorded the P2-9 focus gap (div controls with `tap()` and no `tabindex` aren't keyboard-focusable).

### Notes
- No `:root` token changed in v1.24.0, so the drift `--check` stays green; this is documentation-only.
- **Owed to the design track:** the hero badge and remaining in-guide references still read "app v1.23.1" — bump to **v1.24.0** and re-render. (Left untouched here to avoid colliding with the active design-chat edits that own that badge.)

## [1.0.6] — 2026-06-22

### Fixed (from the rendered visual review in Chrome)
- **Stale hero badge.** The hero version badge still read `v1.23.0`; corrected to "guide v1.0.6 · app v1.23.1" to match the TOC stamp.
- **Anomaly resolved card overlap.** Removed the `2m ago` timestamp from the resolved specimen card so the absolutely-positioned "REJECTED" stamp no longer overlaps it.

### Notes
- First full **rendered** pass (Claude in Chrome, localhost): all 15 sections, charts/donut, timeline, anomaly, and the Snap + Universal Search containment overrides confirmed visually; skip link, focus-visible ring, and the non-color TOC active cue confirmed working. Not verifiable through the automation: the <820px responsive collapse (viewport wouldn't drop below the breakpoint — media query present and standard) and reduced-motion (needs an OS toggle) — recommend a manual glance.

## [1.0.5] — 2026-06-22

### Added (assessment backlog items 8–10 + tokens.json; drafted in parallel, integrated serially)
- **Component coverage (§06).** New live specimens: bar + donut charts, the 8-stage order-tracking timeline, the anomaly alert + side-by-side compare table, the Snap-to-Order result card, the Universal Search command-palette overlay (shown statically via a specimen-scoped containment override), and explicit empty / loading / error states (the no-match card + skeleton rows are guide-authored Phase-1 concepts, clearly labeled — not yet in the app).
- **New sections:** §12 Iconography (inline-SVG convention, size scale, stroke standard, currentColor, consistency risk), §13 Layout/grid/breakpoints (form-factor frames, home grid, nav chrome, padding patterns), §14 Elevation (the bidirectional surface ladder + shadow scale). Governance renumbered to §15. TOC + section numbers updated.
- **Component doc depth.** A uniform States / Usage / Accessibility / Code block added after each existing §06 component (buttons, chips, cards, pills, inputs, MFA keypad, nav, toast) — honest about which states are undefined and where ARIA isn't implemented.
- **`tokens.json`** (new file, project root): a DTCG-format parallel token source generated from the app `:root`, with semantic→primitive aliases mirroring the app's `var()` references. Documentation-only; not wired to a build. App `:root` stays canonical.

### Changed
- Net-new component CSS copied verbatim from the app (charts, timeline, anomaly, snap, universal search, `.req-empty`); duplicates of already-present rules (`.uso-pill` sub-rules) stripped on integration.
- Fixed a stale §06 Inputs note that described the pre-v1.23.1 chat-input focus (now unified to the gold ring).

### Notes
- Drafted by parallel read-only agents, integrated sequentially into the single file with a verify pass between batches. Verified: `node --check` script, full tag balance (617 div / 15 section / 45 svg / 46 h3 all balanced), all 15 TOC anchors resolve, no duplicate selectors, token gate green. **Pixel render still pending your first-load visual pass** (no browser host here) — the new chart/donut/overlay/timeline specimens are the most worth eyeballing.

## [1.0.4] — 2026-06-22

### Added (assessment backlog items 4–7)
- **§02 Token tiers & naming.** Documents the intended primitive → semantic/alias → component model, the honest current-flat reality (only primary/warning aliased via 5A), the `--category-role` naming convention, and the token types in use.
- **§09 Conformance target & coverage.** States the WCAG 2.2 AA / Section 508 target and a VPAT-style coverage table (Supports / Partially / Not evaluated) — framed as a self-assessment, not a conformance claim. Shows real gaps (1.4.1 partial; keyboard/ARIA/RTL not evaluated). Added a keyboard/ARIA/RTL posture note.
- **§12 Governance & maintenance** (new section + TOC entry). Owner (Rich Chala), the app-track vs design-track ownership split, independent guide versioning, a component-status vocabulary (Stable/Beta/Exploratory/Deprecated — Universal Search *Video* tagged Exploratory), and the regenerate/verify workflow.

### Changed
- **§11 Single source of truth** made tool-aware: references `sync-styleguide-tokens.mjs` + `--check`, the contrast-not-certified caveat, the component-CSS second mirror, and that parallel token tracks are now safe behind the gate. Fixed the stale "derive by hand / v1.23.0" wording.
- Refreshed stale §09 target-size/focus bullets to the v1.23.1 reality (sub-44px remediated; `:focus-visible` shipped).
- TOC version stamp → "Design Guide v1.0.4 · tokens from app v1.23.1".

### Notes
- Docs/markup only — no `:root` or swatch changes; token gate green. Verified: `node --check` script, full tag balance, all TOC anchors resolve. Pixel render still pending a first-load visual check (browser host deps unavailable here).

## [1.0.3] — 2026-06-22

### Fixed (the guide's own accessibility — assessment §7)
- **Decorative icons hidden from AT.** All 22 inline SVGs now carry `aria-hidden="true" focusable="false"`.
- **Table headers scoped.** The 8 `<th>` in the contrast and inconsistencies tables now use `scope="col"`.
- **Keyboard navigation.** Added a skip link to `#main` (off-screen until focused), a global `:focus-visible` ring (the guide had none), and a non-color active cue for the TOC (gold left-border, matching the app's sidebar pattern) so the current section isn't signalled by color alone.

### Notes
- Markup/CSS/JS only — no `:root` or swatch changes, so the token gate stays green. Verified: `node --check` on the script, full tag balance (incl. table elements), `sync-styleguide-tokens.mjs --check` green. Pixel render still pending a first-load visual check (browser host deps not installable here); changes are off-screen/markup with no layout impact.
- Stepped through from `STYLEGUIDE-ASSESSMENT.md` (items 1–3 of the open backlog); §7 and the scorecard updated to match.

## [1.0.2] — 2026-06-22

### Changed
- **Synced to app v1.23.1 design fixes.** Ran `tools/sync-styleguide-tokens.mjs` after the app shipped two token changes; `:root` + swatches now back in sync (`--check` passes: :root, 25 swatches, contrast dots all match).
  - `--color-text-muted` `#6C7686` → `#939CAB` — hand-updated the §09 contrast row (FAIL → PASS, now 6.54 / 5.75 / 5.07), the §09 callout, the §02 swatch use-text, and the §10 row (marked resolved). Contrast dots are the one thing the tool leaves manual.
  - `--color-primary` / `--color-primary-hover` / `--color-warning` decoupled from duplicated literals to `var(--vroozi-gold)` aliases (no value change); §10 "primary == warning" row marked partly resolved (coupling fixed; hue still shared pending design decision #5B).
- Historical `#6C7686` / `3.95:1` kept only as explicit "was/before" references.

### Notes
- App is canonical; mirror update only. Guide re-verified: tag balance holds, drift check green.

## [1.0.1] — 2026-06-22

### Added
- **Token generator + drift check** (`tools/sync-styleguide-tokens.mjs`, Node, zero deps). One-way sync from the canonical app `:root` to the guide: rewrites the guide's `:root` verbatim and corrects color-swatch chips + `.hex` labels. `--check` mode is a CI/pre-commit gate that exits 1 on token drift. Contrast-table ratios are intentionally not auto-fixed — the check fails on a stale §09 dot so they're recomputed by hand. Dev-time only; no runtime dependency, both files stay single-file/offline. Documented in `STYLEGUIDE-NOTES.md` → Token generator + drift check.

### Changed
- Guide `:root` rewritten verbatim from the app (now byte-identical, including the app's inline comments). Token values unchanged; all 70 still match.

### Notes
- Verified: tool passes `node --check`; `--check` reports the real files in sync; a drift test (perturbed token in an isolated copy) confirms check fails, sync repairs `:root` + swatch, and the contrast dot is correctly held back for manual recompute. Guide re-verified after the `:root` rewrite — script `node --check` clean, tags balanced, logo intact.

## [1.0.0] — 2026-06-22

### Added
- **Initial design guide.** Created `vroozi-ai-styleguide.html`, a self-contained reference derived from `vroozi-ai.html` v1.23.0. Eleven sections: brand & identity, color system, typography, spacing/radius/shadow/easing, motion & keyframes, component catalog (live specimens using the app's real classes), interaction patterns, touch & device rules, accessibility (measured contrast), known inconsistencies, and single source of truth.
- Live token swatches and component specimens rendered in the app's charcoal+gold aesthetic. Embedded the app's base64 logo; mirrored the app's Google Fonts link (DM Sans + JetBrains Mono) as the only external resource.
- Measured WCAG contrast ratios for every text/surface pairing; flagged `--color-text-muted` (3.95:1) as the one AA failure at the 10–11px sizes it's used.

### Notes
- **App is canonical; token values are mirrored, not shared** (see `STYLEGUIDE-NOTES.md` → Single source of truth). All 70 `:root` tokens cross-checked against `vroozi-ai.html` — exact match at creation.
- **Verification:** `node --check` on the guide's script (clean), tag balance (div/section/button/table/nav/main/style/script all balanced), anchor integrity, external-resource audit. Pixel render not run — browser host deps not installable in this environment; needs a first-load visual check at desktop width plus a mobile spot-check.
- No change to `vroozi-ai.html`.
