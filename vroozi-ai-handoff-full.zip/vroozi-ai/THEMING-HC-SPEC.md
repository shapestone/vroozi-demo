# Theming — High-Contrast ("ADA") Theme Spec (Track C, Phase 2)

Concrete, implementable spec for the high-contrast theme. **Captured 2026-06-23 against app v1.40.1. Not implemented — Track C is Phase 2** (see `THEMING-WORKPLAN.md` → Track C and `THEMING-FEASIBILITY.md`). This is the recipe a Phase-2 implementer follows; it's the first Track C deliverable and the cheapest of the three themes.

## Origin / intent

A stakeholder noted (correctly) that controls with **visible borders and nav separators read as more accessible**. That observation arrived via an accidental native-button bevel (fixed flat in v1.40.1) — but the underlying instinct is a real WCAG pattern: high-contrast users benefit from explicit non-text boundaries (**1.4.11**, ≥3:1), higher text contrast (toward AAA **1.4.6**, 7:1), and a stronger focus indicator (**2.4.11/2.4.13**). HC is the theme that delivers exactly that. It's the cheapest of the three because it stays on a dark base, so the white-overlay / scrim / gradient machinery keeps working (unlike light, which needs a re-tuned palette and a relocated gold accent — that's the hard one, see feasibility doc).

## Mechanism

`[data-theme]` attribute on the root element overriding the token value-set. Default (no attribute) = today's dark values. Pure CSS, single-file-safe (no network). Persistence (remembering the choice) and the toggle UI are Phase-2 concerns (need storage); the visual layer is just an attribute swap.

```
:root { /* default dark values — unchanged */ }
[data-theme="hc"] { /* the overrides below */ }
```

## Step 1 — add seam tokens to `:root` (zero visual change)

So HC is a value-flip, not a component-CSS rewrite, add these to the default `:root` first. **Their default values are transparent/subtle, so the app looks identical** — this can even land in Phase 1 as prep if desired:

| New token | Default value | Used by |
|---|---|---|
| `--control-border` | `transparent` | a border on `.nav-item`, `.bottom-nav-item`, and the `border:none` buttons (uso-cta, snap-order-btn, anomaly-btn, inbox-btn, pf-save, back-btn, topbar-action) |
| `--nav-separator` | `transparent` | bottom-border between sidebar `.nav-item`s and the bottom-nav items |
| `--focus-ring-color` | `var(--vroozi-gold-bright)` | the global `:focus-visible` outline (already 2px gold) |
| `--focus-ring-width` | `2px` | `:focus-visible` outline-width |

Component CSS then references these (e.g. `.nav-item { border:none; border-bottom:1px solid var(--nav-separator); }`, `:focus-visible { outline:var(--focus-ring-width) solid var(--focus-ring-color); }`). In the default theme everything stays flat/gold exactly as now.

## Step 2 — the `[data-theme="hc"]` value-set

Override targets (tune precisely against the §09 recompute in Step 4):

**Affordances (the "noisier" look, by design):**
- `--control-border: rgba(255,255,255,0.55)` — visible ≥3:1 outline on every control.
- `--nav-separator: rgba(255,255,255,0.22)` — real dividers between nav items.
- `--focus-ring-width: 3px`; `--focus-ring-color: #fff` (or `--color-text`) — thicker, max-contrast ring, with a larger `outline-offset`.
- `--state-hover-fill`/`--state-active-fill`/`--state-rest-fill` bumped (~`.04→.12`, `.08→.18`) so interaction states are unmistakable.

**Contrast (toward AAA):**
- Darken the canvas and lift text: `--color-bg` darker (e.g. `#0B0E14`), `--color-text` → `#FFFFFF` (≥7:1), re-tune `--color-text-secondary`/`--color-text-muted` to clear ≥4.5:1 on the darker canvas (muted is already 6.54:1; re-measure).
- Verify the semantic accents (success/info/destructive/caution) still hit ≥4.5:1 as text on the darker canvas — they read 5–10:1 on the current charcoal, so likely fine, but confirm.
- Strengthen `--color-border`/`--color-border-light` to visible hairlines.

**Gold:** stays a usable foreground accent on the dark HC base (gold passes on charcoal); **no demotion needed.** (Demoting gold to fill-only is the *light* theme's problem, not HC's.)

## What HC keeps from dark (don't re-invent)

Scrims (`--scrim*`), the white-overlay `--state-*` model, gradients (`--grad-*`), and shadows all stay — HC is dark-based, so they still read correctly. Only the affordance + contrast tokens above change. This is why HC is cheap and light is not.

## Build sequence (Phase 2)

1. Add the Step-1 seam tokens to `:root` (transparent/subtle defaults; run the drift `--check` + a render compare to prove zero change).
2. Add the `[data-theme="hc"]` value-set (Step 2). Default stays attribute-less = dark.
3. Point the relevant component rules at the seam tokens (`--control-border`, `--nav-separator`, focus tokens).
4. **Recompute §09 contrast for HC** — a second table (every text/non-text pair against the HC canvas; targets: text ≥7:1, non-text ≥3:1). The drift `--check` only verifies swatch parity, never ratios — this is by hand.
5. **Mirror into the styleguide:** a second §09 table and HC swatches; note the triple-mirror maintenance cost the workplan flags. Bump guide + both changelogs per coupled delivery.
6. Toggle + persistence: the attribute swap is trivial; persisting the choice needs Phase-2 storage. Add a Settings toggle (and optionally honor `prefers-contrast: more`).
7. Keyboard + screen-reader pass **per theme**.

## Verification checklist

- Default theme pixel-identical after Step 1 (render compare + drift `--check` green).
- HC §09: all text ≥7:1 (AAA) where feasible, ≥4.5:1 minimum; all control borders/focus ≥3:1 (1.4.11).
- Focus ring visibly stronger in HC; every interactive element shows it.
- Both themes pass the manual keyboard + SR pass.
- `tokens.json` regenerated; guide stamps + both changelogs reconciled.

## Not in scope here

The **light** theme (a separate, harder Track C job — re-tuned palette, gold-as-fill-only, parallel gradient/overlay/shadow sets; see `THEMING-FEASIBILITY.md`) and any `prefers-color-scheme` wiring. This spec covers high-contrast only.
