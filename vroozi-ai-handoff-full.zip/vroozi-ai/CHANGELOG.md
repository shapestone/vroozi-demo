# Changelog — Vroozi AI

All notable changes to `vroozi-ai.html` are recorded here. This is the canonical changelog going forward; `PROJECT-NOTES.md` remains the authoritative spec and holds the pre-v1.22.1 history. The design guide asset is tracked separately in `STYLEGUIDE-NOTES.md` + `STYLEGUIDE-CHANGELOG.md`.

Format follows [Keep a Changelog](https://keepachangelog.com/). Categories: **Added**, **Changed**, **Removed**, **Fixed**. Newest version on top. Update this file in the same pass as any app change, and bump the single `APP_VERSION` constant (v1.30.0+) — it drives every in-app version display (the About screen). The three scattered stamps (sidebar, landscape rail, inbox) were removed in v1.30.0.

---

## [1.40.1] — 2026-06-23

Fix: native button-bevel leak on the two borderless nav buttons (visual regression from the B1 div→button conversion). Restores the flat look.

### Fixed
- **`.nav-item` and `.bottom-nav-item` showed the UA `2px outset` button border** — `appearance:none` suppresses the button *fill* but not the default *border*, and these two were the only converted buttons without an explicit border (every other button sets one). On the dark sidebar the bevel read as faint separator lines between nav items; on the bottom nav it read as raised/bevelled. Added `border:none` to both (the nav item keeps its `border-left:3px solid transparent` gold active-indicator). Confirmed in Chrome: 0 `outset`-bevel buttons remain (was 31), nav/bottom-nav `border-top` now `0px none`, active indicator intact.
- `APP_VERSION` → `1.40.1`.

### Notes
- Root cause was mine: the v1.36.0 reset relied on `appearance:none` alone for these two; the "pixel-identical" render check passed in Chrome because the bevel is very subtle on the charcoal sidebar. Lesson logged: converted buttons must set `border` explicitly, not lean on `appearance:none`.
- No `:root`/token change → drift `--check` green. Guide specimens for nav are `<div>`s (`.nav-item-demo`, `.bottom-nav-item`), so they never leaked — no guide-CSS change; guide gets a no-op review entry (v1.0.29).
- The "noisier" bordered look is **not** shippable as-is (it's inconsistent UA chrome). A deliberate stronger-affordance treatment belongs in the planned high-contrast theme — see `PROJECT-NOTES.md` → Track C.

## [1.40.0] — 2026-06-23

Accessibility — Track B step 4 (B4): focus management on screen change, plus a clean result-CTA audit. This closes out the Track-B *code* work. Phase 1.

### Changed
- **`showScreen()` now moves focus into the new screen.** After the screen activates, its container gets `tabindex="-1"` and `.focus({preventScroll:true})`, so a keyboard/SR user lands in the new view instead of being stranded on the control they activated (which is now hidden). `preventScroll` keeps the scaled device frame from jumping. A `screenReady` flag suppresses the move on the initial paint (the bootstrap `showScreen('home')`), so the page doesn't steal focus on load.
- `APP_VERSION` → `1.40.0`.

### Notes
- **Result-CTA audit: clean.** The dynamically-generated result actions (`#uResCta`, `#uCatCta`, `#uHandoff`, `#uVcta`) are already `<button class="uso-cta">`, so they're keyboard-operable and inside the dialog's focus trap. No change needed.
- **Verification:** invoked `showScreen('voice')` in Chrome — `document.activeElement` became `#screen-voice` (the container, `tabindex="-1"`); on initial load focus stayed on `BODY` (the `screenReady` guard works). `node --check` OK.
- **Track B code work is essentially complete:** every interactive element is a native button (or has native inner buttons), the search overlay is a focus-trapped modal, live regions announce status/loading, and navigation moves focus. **The remaining gate is a manual keyboard + screen-reader pass** — the automated checks verify markup and keyboard mechanics, not actual SR output. Don't represent this as certified 508/AA until a human runs NVDA/VoiceOver through it. RTL stays out of scope unless localization comes in.
- No `:root` change → drift `--check` green (99 tokens). Guide v1.0.27.

## [1.39.0] — 2026-06-23

Accessibility — Track B (finishing the clickable-`<div>`s): the omnibox trigger and the search suggestion rows are now native buttons. Visually identical. Phase 1.

### Changed
- **Omnibox trigger** (`#uSearchBar`) → `<button type="button" aria-label="Search, ask, or order anything">`. Its `.usearch-mode` mic/snap/video icons are decorative (no handlers), so the whole bar is one button — now keyboard-focusable and Enter/Space-operable (previously a `<div>` reachable only by mouse). Closes the gap flagged in v1.38.0.
- **Suggestion rows** (`.uso-sugg`) → buttons: the `el('div','uso-sugg')` factory calls became `el('button','uso-sugg')` (5 sites), so every generated suggestion in the search overlay is keyboard-operable and joins the dialog's focus trap.
- Button resets (`appearance:none`, `font-family:inherit`, `width:100%`, `text-align:left`) added to `.usearch-bar` and `.uso-sugg` so the tag change is visually inert.
- `APP_VERSION` → `1.39.0`.

### Notes
- **Inbox rows need no change** — `.inbox-item` is a container whose actions are already native `inbox-btn` buttons (Open/Snooze); making the row a button would nest buttons.
- **Verification:** render comparison — the search bar renders identically on home and the overlay (input, pills, suggestion rows) is unchanged; the bar opens the dialog and suggestions display as before. `node --check` OK; tag balance (div 633/633, button 102/102, svg 117/117); trigger is a button, all 5 suggestion factories converted, zero `el('div','uso-sugg')` left. (The first-click-to-open is a pre-existing `tap()` touch/click timing quirk, unchanged by this edit.)
- **Remaining clickable-div audit:** the dynamically-generated result-action CTAs (`#uResCta` / `#uHandoff` / `#uCatCta`, shown after a search) — verify they're buttons in a short follow-up.
- **B4 remaining:** focus management on screen change + the full manual keyboard/SR pass (the real conformance gate).
- No `:root` change → drift `--check` green (99 tokens). Guide v1.0.26 updates §09 + posture note (trigger + suggestion rows now buttons).

## [1.38.0] — 2026-06-23

Accessibility — Track B step 2 (B2): the Universal Search overlay is now a real modal dialog with a focus trap, and the remaining secondary controls became keyboard-operable. Visually identical. Phase 1.

### Added
- **Search overlay = modal dialog.** `#uSearchOverlay` is now `role="dialog" aria-modal="true" aria-label="Search"` (so screen readers ignore the background without manual `aria-hidden`). A JS **focus trap** cycles Tab/Shift+Tab within the overlay, **Escape closes** it, focus moves to the search input on open, and **focus restores** to the trigger on close (`uLastFocus`). The input got `aria-label="Search"`.
- **44px hit-areas** (`::before`) on `.home-settings-btn` (38px) and `.topbar-action` (36px), matching `.back-btn`/`.home-inbox-btn`/`.uso-close`; `topbar-action` got `position:relative` to anchor it. Closes the last sub-44px touch targets.

### Changed
- **Converted the remaining clickable `<div>`s to `<button>`s:** the search close (`.uso-close`), the four mode pills (`.uso-pill` Type/Speak/Snap/Video), and the two inbox tabs (`.inbox-tab`). Each gets the button reset (`appearance:none`, `font-family:inherit`, `border:none` where needed). The pills sit inside the overlay, so they join the focus trap automatically.
- `APP_VERSION` → `1.38.0`.

### Notes
- **Verification:** keyboard test in Chrome — opened the overlay, input focused; Tab moved focus to the close button (gold `:focus-visible` ring) and stayed inside the dialog; Escape closed it. Mode pills render identically (Type active/gold). `node --check` OK; tag balance (div 634/634, button 101/101, svg 117/117); `role="dialog"`/`aria-modal` present. **Focus trap is keyboard-verified; SR announcement of the dialog is not automated.**
- **Known gap (remaining B2):** the omnibox search-*bar* trigger (`#uSearchBar`) is still a non-focusable `<div>` with nested mode icons — a keyboard user opens the dialog via the **Shop** nav button, not the bar. Converting the bar (and its mic/snap/video mini-controls) is the last B2 item. Suggestion-result rows and inbox item rows (JS-generated) also still pending.
- **B4 remaining:** focus management on screen change, plus the full keyboard + manual SR pass.
- No `:root` change → drift `--check` green (99 tokens). Guide v1.0.25 updates §09 2.1.1/4.1.2 + the posture note (dialog/trap shipped) and marks the Sub-44px row resolved.

## [1.37.0] — 2026-06-23

Accessibility — Track B step 3 (B3): live regions + busy states, so screen readers announce status changes and loading that were previously silent. Additive ARIA only — no DOM restructuring, no visual change. Phase 1.

### Added
- **Toast** is now `role="status" aria-live="polite" aria-atomic="true"` — confirmations ("PR submitted", "Profile saved", etc.) announce as they appear.
- **Conversation transcripts** (`#chatBody`, `#analyticsBody`, `#voiceThread`) are `role="log" aria-live="polite"` with `aria-label`s — incoming assistant messages announce.
- **Omnibox results** (`#uSoBody`) are `aria-live="polite"` — the "Thinking…" state and the result announce.
- **Typing indicators** (chat/analytics/voice) get `role="status"` + `aria-label="Assistant is typing"`, so the loading state itself is announced.
- **`aria-busy`** is set on the in-flight auth button in `busyBtn()` and cleared in `restoreBtn()`.

### Notes
- **Disabled buttons need no `aria-disabled`:** they already use the native `disabled` attribute (`snapOrderBtn`, the anomaly Reject/Review pair, auth buttons), which screen readers announce. Confirmed during scoping; no change needed.
- **Verification:** `node --check` OK; tag balance (div 0 diff); ARIA present (5 `aria-live`, 3 `role="log"`, toast `role="status"`, dynamic typing `role="status"`, `aria-busy` set/clear). Functional smoke test in Chrome — chat send → typing indicator → product-card response renders correctly (no regression in the typing/response path); toast and disabled-button flows intact. **Live-region announcements are screen-reader behavior — not screenshot-verifiable; a manual SR sweep is still recommended.**
- No `:root` change → drift `--check` green (99 tokens). Guide v1.0.24 updates §09 4.1.2 + the keyboard/ARIA posture note (live regions + busy now shipped; remaining: search-overlay dialog + focus management).
- Remaining Track B: **B2** (search overlay `role="dialog"` + focus trap, suggestion chips, inbox items), **B4** (focus management on screen change + full keyboard/SR pass), plus the deferred 44px hit-areas.

## [1.36.0] — 2026-06-23

Accessibility — Track B step 1 (B1): primary navigation is now keyboard-operable. The clickable `<div>`s that drove navigation became native `<button>`s, so they're focusable and Enter/Space-operable with no new event code. **Visually identical** (verified by render + keyboard test). Phase 1.

### Changed
- **~39 interactive `<div>`s → `<button type="button">`:** sidebar nav-items, the iPad-landscape rail nav-items, home cards, bottom-nav items, and the two chrome icon controls (`home-inbox-btn`, `home-settings-btn`). `back-btn`/`topbar-action` were already buttons. Activation rides the existing delegated `click`/`tap()` handlers — native buttons synthesize click on Enter/Space, so keyboard works with zero new JS.
- **`<nav>` landmarks** around the sidebar nav, the iPad rail nav, and the bottom nav (`aria-label="Primary navigation"` / `"Primary"`).
- **`aria-current="page"`** on the active nav item — set dynamically in `showScreen()` (covers sidebar + rail) and statically on the initial Home item.
- **Button reset** on the converted classes so the tag change is visually inert: `appearance:none`, `font-family:inherit`, plus `background:transparent` + `width:100%` on `.nav-item`/`.bottom-nav-item` (which had no base background and would otherwise show UA grey / shrink to content width) and `width:100%`/`text-align:left` on `.home-card`.
- `APP_VERSION` → `1.36.0`.

### Notes
- **Verification:** render comparison — home screen pixel-identical (nav, cards, bottom-nav unchanged); keyboard test in Chrome — Tab focuses nav buttons with the gold `:focus-visible` ring, Enter activates and navigates (confirmed Voice Ordering). `node --check` OK; tag balance (div 641/641, button 94/94, nav 4/4, svg 117/117); 0 interactive divs remain. No `:root` change → drift `--check` green (99 tokens).
- **Deferred to later B-increments (scoped, not done here):** the 44px `::before` hit-area on `home-settings-btn` (38px) / `topbar-action` (36px); secondary controls (search overlay `role="dialog"` + focus trap, suggestion chips, settings sub-nav already a `nav`, inbox items); toast/loader `aria-live` regions; `aria-busy`/`aria-disabled`; focus management on screen change. These are B2–B4.
- Screen-reader pass not automated — markup follows AA conventions (native buttons, `nav` landmark, `aria-current`); a manual SR sweep is recommended before claiming conformance.
- Guide v1.0.23 updates §09 (2.1.1 Keyboard + 4.1.2 ARIA now "Partially") and the keyboard/ARIA posture note; no component-CSS mirror needed (the guide's nav/card specimens are illustrative divs, unchanged in appearance).

## [1.35.0] — 2026-06-23

Sizing-token pass (Track A step 4, P2-2 + part of P2-1): put the smallest text on rem-based tokens so it responds to text-zoom (WCAG 1.4.4), and added the missing `--space-7`. **Synthetic data only.**

### Added
- **`--text-3xs: 0.625rem` (10px)** — the new type-scale floor for micro-labels, badges, and chart meta. rem-based, so unlike the old hardcoded `px` it scales with browser/OS text-zoom.
- **`--space-7: 28px`** — fills the gap that made the spacing scale jump 6→8.

### Changed
- **~34 `font-size:10px`** (CSS + inline-JS template strings) → `var(--text-3xs)`. **Rendered size unchanged** (0.625rem = 10px); the win is zoom-responsiveness.
- **The four `font-size:9px`** (`.nav-tag`, `.home-card .ai-chip`, `.uso-sugg-tag`, `.anomaly-resolved-stamp`) → `var(--text-2xs)` (11px). The one **visible** change in this pass: 9px is below a reasonable floor, so those micro-labels are now 11px. Render-checked for pill overflow.
- **`--space-7` wired** to its exact-28px spacing consumers: `.status-bar`, `.bottom-nav`, `.auth-inner`, `.lock-inner` paddings (zero visual change).
- `APP_VERSION` → `1.35.0`.

### Notes
- **Deferred (per scope):** snapping the off-scale paddings (`2/3/5/7/13/14/22px`, etc.) onto the `--space-*` scale. The 4px-step scale doesn't fit those micro-paddings, snapping them is a broad visible harmonization with low theming value, so it's bundled into the deliberate harmonization pass (with the button cosmetics). Non-spacing `28px` (frame radius, emoji/icon sizes, decorative insets) and `28px` font-size headings left as-is.
- `:root` grew 97 → 99 tokens. Guide re-synced (drift `--check` green); §09 unaffected (dimensions, not colours). Guide v1.0.22 adds `--text-3xs`/`--space-7` to the §03/§04 scales, migrates its specimen `9/10px` literals, and refreshes the §10 off-scale note.
- **Verification:** 0 `font-size:9px`/`10px` remain; 34 `--text-3xs` + 4 `--space-7` uses; `node --check` OK; tag balance (div 681/681, button 55/55, svg 117/117); render comparison pending on host Chrome (watch the four raised 9px labels).

## [1.34.0] — 2026-06-23

Button consolidation (P1-4, Track A step 3): the eleven independent button classes now sit on two shared base rules — a text-button foundation and a circular-icon-button foundation — with each leaf rule reduced to its visible per-button properties (fill, size, radius, `:active` scale, glow) as the modifier layer. **Implemented as grouped base rules, not new `.btn`/`.icon-btn` classes — zero markup change.** Pixel-identical refactor, verified by a per-selector declaration diff plus render comparison. All Phase 1.

### Changed
- **Text-button base** groups `.uso-cta`, `.snap-order-btn`, `.anomaly-btn`, `.control-btn`, `.inbox-btn`, `.auth-btn`, `.pf-save`; holds `font-family`, `cursor`, `transition`, tap-highlight, touch-action. **Icon-button base** groups `.back-btn`, `.home-inbox-btn`, `.home-settings-btn`, `.topbar-action`; holds the flex centering, `border-radius:50%`, `cursor`, tap-highlight, touch-action. Leaf rules trimmed to their deltas.
- `APP_VERSION` → `1.34.0`.

### Notes
- **Preserve-now, not harmonize.** The visible divergences (the `.96`–`.985` `:active` scales, glow on some primaries only, the `lg`/`xl`/`md` radii, the size permutations, the ghost-text-colour differences) are deliberately **left intact** as per-leaf modifiers. A separate, opt-in harmonization pass remains the place to decide one press scale / one glow policy / fewer radii.
- **The base couldn't be a strict no-op:** the eleven buttons had drifted on the foundation props themselves (only `cursor` was universal). Building a meaningful base required regularizing a few **invisible** props — `.snap-order-btn`/`.anomaly-btn`/`.back-btn` gain `-webkit-tap-highlight-color:transparent` + `touch-action:manipulation` (mobile only: removes the tap flash and the 300ms delay), `.inbox-btn` gains an explicit `font-family` (already inherited), `.pf-save`'s transition becomes `all` (renders identically), and `.home-inbox-btn`'s `border-radius` goes `var(--radius-full)`→`50%` (identical circle). No rendered change.
- No `:root` change — drift `--check` green (97 tokens). Guide v1.0.21 mirrors the base+leaf split for the six buttons it documents and corrects stale v1.33.0 specimen drift (`--vroozi-ink`→`--color-on-primary`) on those lines.
- **Verification:** per-selector effective-declaration diff (every button identical to its pre-refactor rule except the intended invisible props — 0 unexpected); `node --check` OK; tag balance (div 681/681, button 55/55, svg 117/117); render comparison pending on host Chrome.
- Out of scope / follow-ups: `home-settings-btn` (38px) and `topbar-action` (36px) still lack a 44px `::before` hit area (Track B / 508); `chat-send`/`mic-btn` circular gold buttons not folded into the icon base; residual older guide specimen drift (`sso-glyph` literal, `mic-btn` ink, `anomaly.reject` `#fff`) to reconcile in a guide-mirror pass.

## [1.33.1] — 2026-06-23

Debt cleanup on the v1.33.0 token pass. **Refactor only.** All Phase 1.

### Changed
- **`.back-btn:hover`** — the one white overlay left literal in v1.33.0 (`rgba(255,255,255,0.10)`, a desktop-only hover) now uses `var(--state-active-fill)` (.08), giving the icon button a clean rest→hover→press ramp (.06 → .08 → .12) and bringing the last stray overlay into the token layer. Alpha shifts .10 → .08 — sub-perceptual, desktop hover only.
- `APP_VERSION` → `1.33.1`.

### Notes
- No `:root` change — `--state-active-fill` already existed; drift `--check` green (97 tokens). Guide rev v1.0.20 documents the 18 new role tokens (swatches) and refreshes the §02 token-tiering narrative; token pointer stays app v1.33.0 (last `:root` change), synced-through advances to v1.33.1.
- **Verification:** `node --check` (OK); tag balance; drift `--check` green; rendered the affected screens.

## [1.33.0] — 2026-06-23

Token-layer foundation for theming (Track A, steps 1–2 of `THEMING-WORKPLAN.md`): the first `:root` pass that proves a single token layer can re-skin the app later. **Refactor only — intended net visual change is zero** (pending render confirmation); no behavior, seam, auth, or data change. All Phase 1 (single-file, no deps/network). **Synthetic data only.**

### Added
- **`--color-shell` (#0A0C11)** — one deepest structural fill that merges the three former near-blacks (`--vroozi-ink`, `--vroozi-navy`, `--color-surface-pop`, all within 1.02:1 of each other). Body, sidebar, recessed wells, and dark chips now resolve to it. The brand primitives `--vroozi-ink`/`--vroozi-navy` are kept as the underlying values it aliases.
- **Foreground-on-fill role tokens:** `--color-on-primary` (dark ink on the gold primary fill) and `--color-text-on-accent` (white text/glyph on saturated semantic fills). Separated from surfaces so a light/HC theme can flip them independently.
- **Interaction-state fills:** `--state-hover-fill` (.04), `--state-active-fill` (.08), `--state-rest-fill` (.06), `--state-press-fill` (.12) — the white-overlay hover/active/rest/press lightening, tokenized so a theme can supply the inverse.
- **Scrims:** `--scrim` (.7), `--scrim-soft` (.5), `--scrim-strong` (.85) for translucent black media overlays.
- **Gradient role tokens** (exact current stops, named by role not hue): `--grad-stage`, `--grad-screen`, `--grad-screen-fade`, `--grad-card`, `--grad-vframe`, `--grad-viewfinder` (deliberately bluish camera UI), `--grad-avatar`, `--scan-line`, `--sso-glyph`.

### Changed
- **Surface ladder.** The upward ramp was already at ~1.2:1/step (bg→surface 1.21, surface→surface-2 1.20) and is unchanged; only the redundant near-blacks collapsed into `--color-shell`. A recessed well stays border-carried — 1.2:1 below a near-black canvas is unreachable (pure black tops out at 1.16:1).
- **13 hardcoded gradients** migrated onto the `--grad-*`/`--scan-line`/`--sso-glyph` tokens. **~19 white overlays / 5 black scrims** promoted to the state/scrim tokens (white-text tints, the dev-frame insets, and camera-overlay whites intentionally left literal as theme-invariant). **Repeated semantic hex** (`#57D98A`/`#5FA8F5`/`#F4796B`) replaced with `var(--color-success/info/destructive)` in both CSS and the inline-JS template strings. **`color:#fff`** split between `--color-text` (bright chrome text) and `--color-text-on-accent` (text on colored fills).
- `APP_VERSION` → `1.33.0`.

### Notes
- **No `[data-theme]` switch** — this pass only tokenizes; it stays single-theme. Light/HC values are Track C (Phase 2).
- `:root` grew 79 → 97 tokens. Guide re-synced: `node tools/sync-styleguide-tokens.mjs --check` green (97 tokens, 25 swatches, contrast dots match). §09 ratios unchanged (text is measured on bg/surface/surface-2, none of which moved). `STYLEGUIDE-CHANGELOG.md` 1.0.19.
- **Verification:** `node --check` on extracted script (OK); tag balance (div 681/681, button 55/55, svg 117/117); token-graph scan (no self-referential or undefined `var()` refs). **Render comparison at phone + tablet still pending** (needs Chrome on the host).
- Known follow-ups (out of scope): `.back-btn:hover` desktop overlay (.10) left literal — normalizing it to `--state-*` belongs with the P1-4 button pass; full guide swatch documentation for the 18 new role tokens.

## [1.32.1] — 2026-06-22

Expanded the mock `CATALOG` from 16 to **50 synthetic items** across four new categories, from six more provided supplier catalogs. Data-only change — no structural, seam, or UI changes. **Synthetic data only.**

### Added
- **34 new `CATALOG` items** in four new categories: **Medical** (McKesson — masks, N95, exam gloves, face shield, gown, alcohol pads, bandages, thermometer), **Lab & Scientific** (VWR — beakers, pipette tips, lab gloves/coat, centrifuge tubes, pH buffer, slides), **Industrial** (MSC Direct — chipping hammer, cordless drill, bit set, cut-off wheels, hex bolts, wrench, bench vise), **Energy / Oil & Gas** (Balon / MSC Direct — 4" ball valve, gate valve, pressure gauge, pipe flange, wellhead adapter, valve actuator). Plus IT peripherals (mouse/keyboard/headset) and more Office (stapler/whiteboard/file folders). `CATALOG_CATEGORIES` extended to 8 categories; the browse filter chips scroll.
- Cross-item synonyms so common terms surface all variants: "gloves" now returns the Grainger safety + McKesson exam + VWR lab gloves (Grainger first, continuity preserved); "mask" returns the ear-loop + N95.

### Security / compliance
- The six new "demo" files carried production identifiers again — Balon valve part numbers (`4F-F13NL-RF`…), McKesson/Tronex/Microflex medical brands, VWR lab chemicals (incl. Hach reagents, formaldehyde), MSC tool part numbers. **Only product types were used; no real SKU/part number/price/brand-specific value entered the file** (grep-verified: `4F-F13`, `Tronex`, `Microflex`, `ForPro`, `Hach`, `formaldehyde`, etc. all absent). All new SKUs are `ACME-TEST-*`; prices are round/synthetic; emoji, not image URLs. Lab items kept to benign consumables (no hazardous-chemical listings). New supplier names (McKesson, VWR, MSC Direct, Balon) follow the existing seed convention of public distributor brands (CDW/Grainger/Staples) — swap to fictional names if a fully fictional supplier set is preferred.

### Notes
- No `:root` token change and no new component CSS (existing `.catalog-card` handles all categories) — drift `--check` green. Guide gets a no-op review entry + stamp bump to stay in lockstep (`STYLEGUIDE-CHANGELOG.md` 1.0.18).
- `CATALOG-EVAL-GUIDE.md` catalog table updated to 50 items / 8 categories.
- **Verification:** `node --check` + tag balance (div/button/svg balanced); item count 50, IDs unique; leaked-identifier grep clean; rendered in Chrome — Medical browse filter (8 items), and the "gloves" (3) / "mask" (2) / "forklift" (none) omnibox states.

## [1.32.0] — 2026-06-22

Introduced a single **product catalog** the AI functions search against, behind a Phase-1→2 **search seam**. Replaced the scattered, hardcoded product literals (a MacBook in Voice + Snap, gloves in Chat, a refurb + desk card) with one embedded `CATALOG` array rendered through one helper, and wired live catalog search into the omnibox, Snap, Voice, and Chat. Added a Shop **Catalog browse** screen. All Phase 1 (single-file, no deps/network beyond the Google Fonts link). **Synthetic data only.**

### Added
- **`CATALOG`** — one embedded array of 16 synthetic product records (IT / Safety & MRO / Office / Facilities) defined in the seam region (it must exist before the Voice product literals evaluate, and reuses the matcher's `scoreChip`). Canonical record: `{ id, sku, name, mfr, supplier, contractRef, contract, contractTag, tags[], price, priceTag, uom, category, emoji, detail, keys[] }`. Shape mirrors Vroozi's OCI/punchout upload schema (`NEW_ITEM-*`); **every value is fabricated** (ACME-TEST-* SKUs, emoji instead of image URLs). Continuity items keep exact cross-flow numbers (gloves $22.99/box · 200 = $4,598; MacBook $2,499 / refurb $1,799; Uplift desk $590 → ×2 $1,180; Steelcase chair $279).
- **`searchCatalog(query, opts)` — the search seam.** Deterministic token/`keys[]` lookup over `CATALOG` (same `scoreChip`/`MATCH_MIN` brain as the chat chips), returns ranked `CATALOG` records (`opts.topN`, `opts.min`). **Phase 2 reimplements only this body** as semantic/vector search returning the same record shape; callers + renderers don't change.
- **`productCardHTML(item, opts)` — one render path.** Emits the inline `.product-card` (Voice/Chat/omnibox) and the `.snap-product-card` (Snap) variants from one helper; `opts` overrides (`nameSuffix`, `priceLabel`, `contractTag`, `variant`) keep continuity exact where a flow shows a quantity/total (desks ×2 = $1,180) or a different contract tag.
- **Catalog browse screen (`screen-catalog`).** A Shop browse surface: category filter chips (All / IT / Safety & MRO / Office / Facilities) + a product list reading from `CATALOG` (`renderCatalog`/`drawCatFilter`/`drawCatList`). Reachable via a **Browse the full catalog** row in the omnibox Type view and new **Catalog** nav items in the desktop sidebar + iPad-landscape rail (`data-screen="catalog"`).
- **Omnibox catalog tier.** `getUSearchResponse` gains a product-lookup tier between the curated `U_SUGG` intents and `U_MODES`: `searchCatalog` top-4 → `uCatalogResult` renders the hit(s) via `productCardHTML` inside the existing `uso-result` shell (single → "Order in Chat", multiple → "Browse full catalog"). Deliberate no-match still re-surfaces the suggestion catalog.

### Changed
- **Voice / Chat / Snap now render from `CATALOG`.** `MBP_CARD`/`MBP_REFURB` are now `productCardHTML(catGet('CAT-IT-001'/'CAT-IT-002'))`; the Voice desk card and Chat gloves card render from `CAT-FA-001`/`CAT-MR-001`; Snap's identified item resolves from `CATALOG` (`SNAP_ITEM_ID`) into a slot (`#snapProductSlot`) instead of static markup. Scripted branching is unchanged — only the card markup moved to the shared source.
- **Omnibox "order chairs" suggestion** dropped the over-broad `desks` key so product lookups like "standing desk" resolve to the catalog `CAT-FA-001` instead of the chairs insight (curated intents still win for "ergonomic chairs").

### Security / compliance
- The provided "demo" catalog files (`CDW.xlsx`, `CDWLaptops.xlsx`, `Grainger Catalog.xlsx`) carried production-grade identifiers — live `images.vroozi.com` CDN URLs, real manufacturer part numbers, vendor IDs, and internal ObjectIDs. **Only the field shape was used; no real value entered the file.** Verified by grep that none of those identifiers are present. Also neutralized a pre-existing real-ish part number (`117955` / "SAS Raven") in the Typography specimen to `ACME-TEST-MR-001` / "SafeGrip" for a consistent synthetic posture. No network added (emoji, not image URLs).

### Notes
- No `:root` token change (new component CSS `.catalog-*` + markup + logic only, using existing tokens). Drift `--check` green; §09 contrast unaffected. New product/catalog-card specimen added to the guide — see `STYLEGUIDE-CHANGELOG.md` 1.0.17.
- Coupled delivery: app + guide + both changelogs + `APP_VERSION` in this pass.
- **Verification:** `node --check` + tag balance (div/button/svg balanced); rendered in Chrome at phone + iPad-landscape widths across all new search states — single match, multiple results, no-match, browse screen, Snap card, and the Voice/Chat catalog cards; confirmed continuity numbers exact and no real identifiers leaked.

## [1.31.0] — 2026-06-22

Split the account hub into two surfaces: **Profile** (your identity + personal defaults, built out as a detail form) and **Settings** (app behavior, with its own left sub-nav). Settings becomes its own NAV destination plus a gear cog on mobile. All Phase 1, all mock — **no real credentials, storage, sessions, network, or crypto; any input succeeds. Synthetic data only.**

### Added
- **Profile detail form (`screen-profile`).** Rebuilt from a row hub into a form patterned on the production user-profile page: **Contact information** (First/Last name, Contact title, Telephone, Fax, Pin code + Save), **My System Preferences** (Default Language), **Change Password** (Old/New/Confirm + Save), **My Document Defaults** (Company code, Purchasing org, Cost center, Currency, Plant, Shipping address). Account actions (Switch account, Sign out) sit at the bottom. First Name binds to `state.userName`; Save echoes it back (escaped). Every value is synthetic (`ACME-TEST-CO`, `(201) 555-01xx`, a test address, `shaz@acme-test-co.example`) — no real PII.
- **Settings with its own side sub-nav (`screen-settings`).** A left nav column (Notifications · Appearance · Privacy & Security · About) switches panes in place. **Notifications** = the mock toggles; **Appearance** = mock theme segmented control + Compact lists / Reduce motion toggles; **Privacy & Security** = MFA shown **Enabled and non-interactive** (managed by org — never a control to disable MFA), active-session row, "Sign out of all devices" (mock); **About** = version/org/environment (folded in from the old standalone About screen, same `APP_VERSION` injection).
- **Settings is now its own NAV destination + mobile gear cog.** Added to the iPad-landscape rail (Account group) and the desktop sidebar (new Account group with Profile + Settings), and reachable via a **gear cog on the Home header** (next to the bell) and the **Profile header**. `data-screen="settings"` for the nav items; the gears use their own handlers.

### Changed
- **Profile / Settings separation.** Profile no longer contains a "Settings" row; the two are distinct surfaces. `resetProfile` re-paints the form's First Name from the active name; `resetSettings` defaults to the Notifications pane.
- **`.settings-row-main`** now `flex:1` with `min-width:0` on its text block so long titles (e.g. "Multi-factor authentication") wrap instead of overlapping a trailing pill.
- **Gear cog placement (same-session refinement).** The Home-header Settings gear now sits **stacked under the bell** (was beside it) in portrait, and is **hidden in iPad landscape** (Settings lives in the rail there) — mirrors the inbox-bell hide rule. The Settings **side sub-nav narrowed** (112→88px, tighter gap) so the Privacy & Security pane stops overflowing on the phone width; the MFA row stacks its "Enabled" pill under the title (full-width title, clean wrap) and `.settings-row-title` got `overflow-wrap:break-word` as a safety net.

### Removed
- **Standalone `screen-about`** (folded into the Settings → About pane) and the old Profile "Settings" row.

### Security / compliance
- Auth/account surface touched (Profile form incl. Change Password, Settings → Privacy & Security). Still a pure front-end mock — no real credentials, storage, sessions, network, or crypto; any input succeeds. Change Password validates only that the two new fields match, then clears the fields and toasts. **MFA is presented as enabled and is deliberately non-interactive — no mock control weakens or disables authN.** Display name remains an escaped, in-memory, non-persisted echo. **Real authentication, password change, and session management are Phase 2 / compliance-boundary work — recommend security review.**

### Notes
- No `:root` token change (new component CSS + markup + logic only). Styleguide re-synced; drift `--check` green; §09 contrast unaffected. See `STYLEGUIDE-CHANGELOG.md` 1.0.16.
- Coupled delivery: app + guide + both changelogs + `APP_VERSION` in this pass.
- **Verification:** `node --check` + tag balance (div/nav/button/aside balanced); all new id refs resolve; no stale `screen-about`/`settingsAbout` refs; rendered in Chrome at phone width — Home gear, Profile form (all sections), and all four Settings panes; confirmed both gear cogs + rail/sidebar Settings navigate; fixed the MFA-row title overlap on the narrow panel.

## [1.30.0] — 2026-06-22

Account surfaces: a real Profile → Settings → About flow, dynamic account name, more mock auth flows, and a single `APP_VERSION` source of truth. All Phase 1 (single-file, no deps/network beyond the Google Fonts link). **Auth remains a front-end mock — no real credentials, storage, sessions, network, or crypto; any input still succeeds.**

### Added
- **Profile screen (`screen-profile`).** Bottom-nav Profile now opens an account hub (avatar initial, display name, org `ACME-TEST-CO`) with rows for Settings, Switch account, and a danger-styled Sign out — replacing the old "Profile → lock screen" shortcut. Also added a **Profile entry to the iPad-landscape rail** under a new "Account" label — the rail replaces the bottom nav on iPad and had no Profile entry, so Profile was otherwise unreachable in that layout. (`data-screen="profile"`, picked up by `navItems`.) Same fix for **Shop** in the rail's Workspace group (`#railShop` — opens the Universal Search overlay via its own handler, since Shop isn't a screen), so the omnibox is reachable on iPad landscape beyond the home hero bar.
- **Settings screen (`screen-settings`).** Mock preference toggles (Approval alerts, Weekly spend digest, Anomaly alerts — visual only, nothing persisted) plus a General → **About** row showing the version.
- **About screen (`screen-about`).** Canonical home for the version: embedded logo, app name, `vX.Y.Z`, "Internal build · not for distribution", and Version / Organization / Environment rows. Every string is injected from the `APP_VERSION` / `APP_NAME` / `APP_ORG` constants at init.
- **Dynamic account name.** New in-memory `state.userName` (default `"Shaz"`) is the single source for every live identity spot: home greeting, lock name + avatar initial, welcome toast, voice user label + voice PR-card requester, snap PR-card requester, chat & analytics greetings, and the Profile card. Captured from an **optional "Display name" field** on the email sign-in (blank → `Shaz`). It is untrusted, runtime-only (not persisted, not sent anywhere), and **escaped via `uEscape` before every `innerHTML` write** (verified: a hostile name produces zero injected elements). Historical `REQ_DATA` / `PO_DATA` record names stay static — they're prior records, not the active user.
- **More mock auth flows.** Sign out → returning-user lock; Switch account → sign-in (resets the name echo to default); MFA **wrong-code error state** via the reserved code `000000` (any other 6 digits still succeed — preserves "any input works" while exercising the error design); **Forgot password?** link → "reset link sent" toast. All visual only.

### Changed
- **Single `APP_VERSION` source of truth.** `var APP_VERSION`, `APP_NAME`, `APP_ORG` defined once near the top of the script and injected into every display at init. Bumping the build is now editing one constant — the coupled-delivery rule's "bump the three stamps" collapses to "bump `APP_VERSION`."
- **Bottom-nav Profile** routes to `screen-profile` (was `showScreen('authlock')`).
- **Sign-in email block** `max-height` raised (260 → 420px) for the added Display-name field; `#screen-auth .auth-inner` switched from `flex:1; justify-content:center` to `flex:0 0 auto; margin:auto` so the screen **scrolls when the open email block is taller than the frame** (the Continue button was otherwise unreachable — the flexbox center-overflow clip trap). Centering when short is unchanged.

### Removed
- **The three scattered version stamps** (sidebar `.sidebar-meta`, landscape-rail `.sidebar-meta`, inbox `.inbox-version`) and their now-orphaned CSS (`.sidebar-footer`, `.sidebar-meta`, `.inbox-version`). The version lives only in About now (per product decision — it doesn't need to be always-visible).

### Security / compliance
- Auth surface touched (sign-in, MFA, lock, sign-out, switch account, profile). Still a pure front-end mock: no real credentials, storage, sessions, network, or crypto; any input succeeds. The display name is untrusted input — handled as an escaped, in-memory, non-persisted visual echo, never a real identity and never prefilled. **Real authentication (IdP/SSO exchange, server session, enforced MFA, WebAuthn) remains a Phase 2 / compliance-boundary concern — recommend security review before any of this is made real.**

### Notes
- No `:root` token changes (only new component CSS + markup + logic). Styleguide re-synced; drift `--check` green; §09 contrast table unaffected (color unchanged). See `STYLEGUIDE-CHANGELOG.md` 1.0.15.
- Coupled delivery per `PROJECT-NOTES.md` → Deliver: app + guide + both changelogs + `APP_VERSION` in this pass.
- **Verification:** `node --check` + tag balance (div/button/aside balanced); all new id refs resolve; drift `--check`; rendered in Chrome via `localhost:8000` at phone width — Home, Profile, Settings, About, sign-in (email block open, scroll-to-Continue), and the MFA error state; confirmed dynamic-name propagation and HTML-escaping of a hostile name.

## [1.29.0] — 2026-06-22

Typeface change: **Inter** for UI/body, **Roboto Mono** for numbers — replacing DM Sans + JetBrains Mono.

### Changed
- **`--font-ui`** → `'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif`. Inter is built for dense screen UI at the app's 10–11px label sizes; reads modern and neutral so the gold accent still carries identity.
- **`--font-mono`** → `'Roboto Mono', 'SF Mono', ui-monospace, Menlo, Consolas, monospace`. Keeps a true monospace for the data role (prices, PR/PO numbers, MFA digits, chart values, version stamps) — the fixed-width contrast that signals "this is an identifier/amount."
- **Google Fonts `<link>`** swapped to `Inter` (300–700 + italic 400) + `Roboto Mono` (400, 500). Still the one allowed network exception; falls back to the system stack when blocked (Inter → SF/Segoe/Roboto; Roboto Mono → SF Mono/Consolas/Menlo).

### Notes
- `:root` font tokens changed (no color tokens), so the styleguide was re-synced and its §09 contrast table is unaffected (contrast is color, not font). Drift `--check` green. See `STYLEGUIDE-CHANGELOG.md` 1.0.14.
- Coupled delivery per `PROJECT-NOTES.md` → Deliver: app + guide + both changelogs + all stamps in this pass.
- **Verification:** `node --check` + tag balance both files; drift `--check`; render-checked in Chrome at phone + tablet widths (home, chat, analytics) and the guide's Typography section.

## [1.28.2] — 2026-06-22

Dead-code cleanup found during a full-asset audit.

### Removed
- **Orphaned omnibox caret CSS.** `.uso-input .caret` and `@keyframes usCaret` went unused when v1.28.0 turned `#uSoInput` into a real `<input>` (native caret via `caret-color`) — the fake `<span class="caret">` is no longer rendered. Removed both. No visual change (the omnibox still shows a blinking caret, now the browser's).

### Notes
- CSS-only removal; `node --check` + tag balance green; nothing touches tokens, auth, sessions, crypto, validation, or tenant scoping. Render-confirmed the omnibox caret still shows.
- Audit also reconciled docs: PROJECT-NOTES size/line stat refreshed; styleguide synced (see `STYLEGUIDE-CHANGELOG.md` 1.0.13 — omnibox real-input, `inputNudge` keyframe, free-text/voice-send patterns).

## [1.28.1] — 2026-06-22

Completes the voice transcript input from v1.28.0 with an explicit send control.

### Added
- **Voice send button.** The trailing control now swaps mic↔send: it's the mic when the field is empty (speak), and a gold send button when there's text (`#voiceSend`). Avoids crowding three controls into the row or two adjacent gold circles. Tap-send and Enter both submit; the field reverts to the mic after submit and on reset. `voiceEngine.opts.send` is now wired (so the typewriter pulse applies during chip-tap too).

### Notes
- Programmatic `.value` changes don't fire `input`, so `voiceSyncSend()` is called explicitly after submit and on `resetVoiceDemo`. CSS/markup/JS only; no `:root`/token change; nothing touches auth, sessions, crypto, validation, or tenant scoping; single-file intact.
- **Verification:** `node --check` + tag balance (45/45 buttons). Render-checked in Chrome: empty field shows the mic, typing swaps to send, tapping send submits ("order standing desks for boston" → Uplift desk card + branch chip), field clears and reverts to mic.

## [1.28.0] — 2026-06-22

Extended the Phase 1 free-text seam to the last two chip-only surfaces: the Universal Search omnibox and Voice. All four entry points (Chat, Analytics, Voice, omnibox) now accept typed input matched by the same brain. Built on v1.27.0.

### Added
- **Universal Search omnibox is now a real typed front door.** `#uSoInput` was a display-only `<div>` with a fake caret — you could only *tap* a suggestion. It's now a real `<input>` (native caret, `enterkeyhint`, focus-on-open). Free text routes through `getUSearchResponse(text)` → renders the existing `uResult` blended card with its "Continue in [flow]" CTA. The omnibox keeps its own card renderer (it has no chat thread / `runSequence`); only the **matcher is shared** with the ConvoEngine seam (`bestChip`/`scoreChip`/`MATCH_MIN`). That's the part Phase 2 cares about — both surfaces swap to a model call there.
- **Omnibox catalog + modality intents.** The four `U_SUGG` cross-domain asks carry `keys[]`; a small `U_MODES` map routes "camera/photo"→snap, "speak/talk"→speak, "video/walkthrough"→video. No-match (`uNoMatch`) re-surfaces the suggestion catalog with the typed text **escaped** (untrusted input), and empty submit nudges the field.
- **Voice joins the seam.** Added a transcript input row beside the mic (`#voiceInput` + shrunk inline mic) so you can speak *or* type. `voiceEngine` now has a live `input`, `entryChips = VOICE_START_CHIPS`, and `wireLiveInput`. Voice chips carry `keys[]`. Typing **bootstraps the flow before the mic is tapped** (tier-2 over entry asks), and the mic gate now no-ops once a conversation exists (`voiceThread` non-empty) so the two paths don't double-start.

### Changed
- `U_SUGG` entries gained `keys[]`; `VOICE_START_CHIPS` extracted to module scope (mirrors `CHAT_START_CHIPS`/`AN_START_CHIPS`). Voice status copy → "Tap the mic, or type your request". The voice mic shrinks to 52px when inline with the input; `.uso-input` restyled as a native input (placeholder + caret-color, no fake caret span).

### Notes
- CSS/markup/JS only; no `:root`/token change. Nothing touches auth, sessions, crypto, validation, or tenant scoping; no network/deps added (Phase 1 stays single-file).
- **Architecture note:** "fold onto `getResponse`" became "share the matcher, not the renderer." Forcing the omnibox's card UI into the chat-thread `{steps,then}` shape would have been worse; the reusable, Phase-2-relevant core (the matcher) is what's shared. Documented in `PROJECT-NOTES.md` → The seam.
- **Verification:** `node --check` + div/button tag balance (green). Matcher unit tests on both new catalogs (omnibox + voice) pass after adding "spiked/costs" to the IT entry from an observed miss. Render-checked in Chrome: omnibox free-text match ("anything overpriced this quarter" → anomalies card), omnibox no-match (escaped, catalog re-surfaced), voice typed-bootstrap ("I need a laptop for a marketing hire" → full laptop sequence + branch chips, no mic tap), voice input layout clean at phone width.
- **Still deferred:** Voice speech (the mic is still a scripted tap, not real STT) and a send button for voice (Enter-only today). Both Phase 2 / fast-follow.

## [1.27.0] — 2026-06-22

Phase 1 free-text seam — the chip-only flows now accept typed input, matched to the existing scripted responses behind a single `getResponse()` function. This is the Phase 1→2 boundary from `PROJECT-NOTES.md` → Direction. Scope this pass: **Chat + Analytics** (the two engines with a real text input). Voice deferred — it has no text field (`input:null`), so typed voice is net-new UI, not wiring.

### Added
- **`getResponse(userText, context)` — the seam.** Returns the same `{ steps, then, match }` descriptor `runSequence` already consumes, or a no-match. Phase 2 reimplements only this one function (async model call, same shape); `submitText`/`runSequence`/the UI never change. Matching lives entirely here, never in the input handler.
- **`ConvoEngine.prototype.submitText(userText)`.** Mirrors `pick()` but routes through `getResponse` first and skips the typewriter (the user already typed). Guards `busy`; empty text is a no-op with a nudge, not a bot turn.
- **Three-tier, state-scoped matcher (conservative).** (1) Current branch — scores typed text against the currently-offered chips; current chips always win. (2) Broader intent — scoped to *this engine's* entry asks only (`entryChips`), so a mid-branch top-level ask routes without a cross-screen jump. (3) Deliberate no-match. Threshold is strict on purpose (`MATCH_MIN=2`): one keyword hit (weighted ×2) or two overlapping label tokens. No global keyword bag.
- **Per-chip `keys[]`.** Each chip carries match terms (e.g. gloves chip → `['gloves','nitrile','ppe',…]`) so paraphrases like "order gloves" match a full-sentence label. Multi-word keys match as exact phrases; single-word keys and label tokens match with light stemming (`macbooks`→`macbook`, `gloves`→`glove`). Entry asks extracted to module-level `CHAT_START_CHIPS` / `AN_START_CHIPS` so tier-2 can reuse the exact scripted responses (no content duplicated).
- **No-match state (the headline UX).** A short bot turn ("I didn't quite catch that…") that re-surfaces the current branch's chips as suggestions, so the user is never stuck — the state chips made impossible. Built as a reusable `noMatchResponse()` descriptor; Phase 2 reuses the same slot for low-confidence model output and (later) loading/error/timeout.
- **Empty-input state.** Submitting blank focuses the input with a subtle shake (`.nudge`), no bot turn.

### Changed
- **Chat + Analytics inputs are now live.** Removed `readonly` from `#chatInput`/`#analyticsInput`; added `enterkeyhint="send"`, `autocomplete="off"`, `autocapitalize="sentences"`. `wireLiveInput()` binds the send button (tap) and Enter keydown to `submitText`. Chips stay above the input as *suggestions* — tapping still calls `pick`; both converge on `runSequence`.
- `offerChips`/`clearChips` now retain `currentChips` so the matcher (and no-match restore) can see the current branch. Fixed the stale `// chips: [{label, onPick}]` comment (real shape is `{label, keys, responses, then}`).

### Notes
- CSS/markup/JS only; no `:root`/token change (no drift). Nothing touches auth logic, sessions, crypto, validation, or tenant scoping — and no network/deps added, so Phase 1 stays single-file.
- **Scope deferred:** Voice typed input (needs a transcript-input affordance), and unifying the Universal Search omnibox onto `getResponse` (it already does its own scripted type→route) — both fast-follows, not Phase 1.
- **Verification:** `node --check` on the extracted script + div/button tag balance (both green). 18/18 matcher unit tests pass (exact, paraphrased, plural, cross-branch intent, gibberish→no-match, wrong-engine→no-match). Render-checked in Chrome at phone + tablet widths — see below.
- **Render caveat (carried from v1.26.2):** the automated Chrome tab throttles `setTimeout` in the background, so verify *behavior/branching* there but eyeball *timing/feel* in a focused browser.

## [1.26.2] — 2026-06-22

Interaction polish — P2-5 and P2-6 from `DESIGN-BACKLOG.md`. Both were friction I'd watched misbehave in earlier renders.

### Fixed
- **Screen-transition double-exposure (P2-5).** Screens cross-faded opacity on both the outgoing and incoming view, so two screens were briefly visible at once. Moved the transition onto `.screen-view.active` only: the outgoing screen now snaps to hidden (base `transition:none`) while the incoming fades in (240ms) over the opaque canvas — no overlap. Verified mid-transition in Chrome (single screen, no bleed-through).
- **Sluggish chip→input typewriter (P2-6).** `typeInto` typed one char per 16ms with a 260ms tail (~750ms for a long chip label). Now types 3-char chunks at 12ms with a 120ms tail (~250ms) — keeps the typewriter feel but is far snappier for repeat use.

### Notes
- App CSS/JS only; no `:root`/token change (drift `--check` green). Nothing touches auth logic, sessions, crypto, validation, or tenant scoping.
- **Verification caveat:** P2-5 confirmed by rendering mid-transition. P2-6's wall-clock couldn't be measured faithfully — the automated Chrome tab throttles `setTimeout` to ~1s/tick in the background, so timing reads ~10s for what is ~250ms in a focused tab. The change is faster than the prior by construction (fewer, shorter ticks); fill completes with the correct value. Worth an eyeball in a focused browser.

## [1.26.1] — 2026-06-22

Pill unification (P1-7) then snap fixes (P1-8), done as one sequential pass — P1-7 first so the snap badge gets fixed as an instance of the unified pill. Render-verified in Chrome.

### Changed
- **Status pills unified (P1-7).** `.req-pill`, `.pr-badge`, `.product-tag`, and `.snap-result-badge` were four drifted size systems (5px/11px/700, 2px/10px/600, 3px/10px/600, 4px/12px/700). Normalized to one spec: `padding:4px 10px`, `font-size:var(--text-2xs)`, `font-weight:600`, `radius-full`, `inline-flex` + `gap:5px`. Per-class color modifiers and layout extras (snap badge's solid success + centering) preserved. `.nav-badge` (solid count) and `.nav-tag` (squared uppercase category tag) left alone — they're nav chrome, a different role, not status pills.

### Fixed
- **Snap "Item Identified" badge no longer clipped (P1-8).** The badge collided with the "Snap to Order" header (sat 36px above the header's bottom). Bumped `.snap-result` top padding to clear it, with a `body.device-mode` override (status bar hidden → less padding needed). Measured after: badge top 224 ≥ header bottom 217.
- **Snap "Ready to Submit" pill no longer stale.** On submit it now flips to a green "Submitted" (`pr-badge approved`); resets with the flow. Previously stuck on the orange pending pill after submitting.
- The snap success button's "green gradient" was already flat/tokenized (solid `--color-success`, `background-image:none`) from earlier work — confirmed, no change needed.

### Notes
- CSS/markup/JS only; no `:root` change, so token drift `--check` stays green. Nothing touches auth logic, sessions, crypto, validation, or tenant scoping.
- Styleguide pill specimen CSS was also drifted (still on the old sizes) — synced to the unified spec. See `STYLEGUIDE-CHANGELOG.md` 1.0.12.
- **Verification:** `node --check`, tag balance, and live render of the snap result (badge clearance + pill flip) and the requests list (unified status pills).

## [1.26.0] — 2026-06-22

Brand chart palette — P1-1 from `DESIGN-BACKLOG.md`. Render-verified in Chrome on both charts.

### Changed
- **Charts no longer use a Material rainbow.** The supplier bar chart and the Spend-by-Category breakdown both used blue/teal/gold/Material-green/purple/red (`#1565C0/#0097A7/#E8A820/#4CAF50/#7B1FA2/#C62828`) plus grey. Added a 6-color categorical palette derived from the brand/semantic family — `--chart-1` gold, `--chart-2` info-blue, `--chart-3` success-green, `--chart-4` caution-amber, `--chart-5` slate neutral, `--chart-6` bronze (gold-deep) — and mapped both charts onto it. Teal, purple, and Material-green/red are gone; warm tones (gold/amber/bronze) are ordered to non-adjacent positions in the supplier chart.
- **Every `#4CAF50` replaced.** The Material green that clashed with `--color-success` is gone: chart bars use `--chart-3`, and the status-bar battery icon uses `var(--color-success)`.

### Notes
- Added 6 `--chart-*` tokens to `:root`; styleguide re-synced (`tools/sync-styleguide-tokens.mjs`, drift `--check` green). No contrast-table impact (chart fills aren't text). Charts are labeled, so hue is identity-secondary — bar length + label carry identity, color is reinforcement.
- CSS/token only. Nothing touches auth logic, sessions, crypto, validation, or tenant scoping.
- **Verification:** `node --check`, tag balance, drift `--check`, and live render of the spend breakdown and the supplier bar chart in Chrome.

## [1.25.2] — 2026-06-22

Button states — P1-2 from `DESIGN-BACKLOG.md`. (P1-3 hover shipped in v1.24.0; P1-4 shared-`.btn`-base refactor deliberately deferred — see below.)

### Added
- **Disabled button state** — `~45%` opacity, non-interactive, press-scale suppressed, on the gold/anomaly/inbox/control button classes (the snap success button is excluded so its green "Submitted" confirmation isn't dimmed).

### Fixed
- **Destructive/submit actions can no longer double-fire.** `snapOrderBtn` re-fired its toast and re-ran on every tap; now it guards on `disabled`, fires once, and resets with the flow. Anomaly Reject/Review both stayed live after one was chosen (the reset code referenced `.disabled` but nothing ever set it) — `anomalyResolve` now guards re-entry and disables both buttons; reset re-enables. Verified in Chrome: clicking Reject dims both buttons and a second Reject/Review tap is a no-op.

### Notes
- App CSS/JS only; no token change (styleguide drift `--check` green). Nothing touches auth logic, sessions, crypto, validation, or tenant scoping. The anomaly "Reject Invoice" guard is a UX double-submit prevention on a mock action, not a real authorization control.
- **P1-4 deferred (not blocked):** extracting a shared `.btn` base + unifying the scattered press scales (0.9–0.99) is a delicate pixel-adjacent refactor across 6 classes + ~18 `:active` rules whose payoff — single source for button styling — is erased when buttons move into the Phase-2 design-system package. Better done there than paid for twice here.

## [1.25.1] — 2026-06-22

Text-reflow fix (P0-4), the last render-gated P0. Diagnosed by instrumenting the live page (the desktop preview shell absorbs browser zoom, and device-mode can't be triggered in desktop Chrome, so page-zoom isn't a faithful test) — doubled the root font-size and measured per-screen overflow vs. scrollability.

### Fixed
- **Enlarged text no longer clips (WCAG 1.4.4).** At 200% root text, `screen-snap` (+4px) and `screen-auth` (+11px) overflowed the fixed device viewport with no scroller, so the bottom was cut off. Added `overflow-y:auto` to `.screen-view` as a universal scroll safety-net (screens whose inner `*-body` already scrolls are unaffected — they don't overflow), and changed `.auth-inner`/`.lock-inner` from `justify-content:center` to `safe center` so a centered screen aligns to the top (reachable) instead of clipping when content exceeds the viewport. Re-verified by rendering at 200%: snap/auth/authmfa now scroll with both top and bottom reachable; no screen clips.

### Notes
- App CSS only; no token change, so the styleguide drift `--check` stays green. Nothing touches auth logic, sessions, crypto, validation, or tenant scoping.
- **Not addressed here:** the ~35 hardcoded 9–11px font sizes that don't respond to text-only resize (they scale under browser zoom but not OS/Dynamic-Type text scaling). That's a px→rem migration tracked as P2-1/P2-2, a larger separate pass.
- **Owed on-device:** true device-mode 200% (full-bleed + iOS Dynamic Type) can't be rendered in desktop Chrome; worth a real-device confirmation, but the clip path is fixed structurally.

## [1.25.0] — 2026-06-22

Harmony pass from `DESIGN-BACKLOG.md` (P0-2 + P0-3), the visual-judgment work that was unblocked once rendering became available. Each change was render-verified in Chrome (`localhost:8000`) across home, requests, and anomaly at phone width.

### Changed
- **Surface elevation ramp rebuilt (P0-2).** Raised surfaces were stepping only ~1.14:1 and the near-blacks ~1.02–1.06:1 — flat on OLED. Lifted `--color-surface` #1B2230 → **#1F2735** and `--color-surface-2` #232C3C → **#2A3446** (now ~1.2:1 per step over canvas), deepened the recessed well `--color-surface-pop` #0E1218 → **#0C0F16**, and migrated the shared card gradient (`#1E2533/#161C27` → `#242E3D/#1A2330`, 3 instances) onto the new ramp. Verified `--color-text-muted` still clears AA on the lighter surfaces (5.42 / 4.52). Cards and stat tiles now read clearly above the canvas.
- **Gold de-overloaded + distinct caution hue (P0-3).** Added `--color-caution` **#F2994A** (amber-orange, 8.14:1 on canvas), `-bright` #F8B06A, `-light`; un-aliased `--color-warning` from brand gold to the caution token. A primary CTA and a caution are no longer the same color (WCAG 1.4.1). Applied to the anomaly spike-alert (border + ⚡ glyph) and the `pending` pill, each paired with a non-color cue. Fixed a latent mis-mapping: `.inbox-ic.approve` was routed through the warning token — re-pointed to success (green), since "approve" isn't a caution.

### Notes
- CSS/token only. Nothing touches auth logic, sessions, crypto, validation, or tenant scoping.
- `:root` changed, so the styleguide was re-synced (`tools/sync-styleguide-tokens.mjs`, 73 tokens, drift green) and its §09 contrast table recomputed by hand for the new surfaces + a caution row; §10 "primary == warning" marked resolved. See `STYLEGUIDE-CHANGELOG.md` 1.0.8.
- **Verification:** `node --check`, tag balance, drift `--check`, and live render in Chrome (home/requests/anomaly). **Still deferred** (render-ready but not in this pass): P0-4 text reflow to 200%, P1-4 button-base refactor, P1-1 chart palette, the remaining off-token gradient stops, and the fuller gold de-overload (link/Financial-Review status still gold).

## [1.24.0] — 2026-06-22

Accessibility + polish pass from `DESIGN-BACKLOG.md`, validated against Apple HIG (44pt targets) and Material 3 / WCAG 2.2. Scoped to items whose correctness is determinable without rendering — this environment has no browser host (no root to install Chromium's system libs), so visual-harmony and pixel-regression items were deliberately deferred (see "Deferred" below).

### Changed
- **Search-overlay scrim** (P0-1) — `.usearch-overlay` scrim raised `rgba(8,10,14,0.72)` → `0.96` so the overlay stays legible when `backdrop-filter` is unsupported or disabled (iOS Reduce Transparency = a low-vision setting). Blur is now an enhancement, not load-bearing.
- **Reduced-motion** (P2-3) — the `prefers-reduced-motion` block now sets `animation-iteration-count:1` + `animation-fill-mode:both` (and `scroll-behavior:auto`) instead of only zeroing durations, so looping/meaning-bearing motion (processing orb, scan, typing) settles to a static end-state rather than flickering at a near-zero infinite duration (WCAG 2.3.3).
- **Success toasts now green** (P1-5) — added `.toast .dot.success` / `.dot.info` (existing `--color-success` / `--color-info`); routed the genuine successes (PR submitted, standing control enabled, signed in, passkey, welcome back) to `success` and code-resend to `info`. They previously shared the gold "review" dot.

### Added
- **44px hit areas on core controls** (P0-5, partial) — `.back-btn` (36px) and `.chat-send` (42px) get a transparent 44×44 `::before` (Apple HIG 44pt); `.bottom-nav-item` and `.inbox-btn` grow to `min-height:44px`. Visible glyphs unchanged. (The packed controls — `.usearch-mode`, `.suggest-chip`, inbox Open/Snooze adjacency — were deferred: expanding their hit areas risks overlapping neighbors, which can't be verified without rendering.)
- **Desktop hover states** (P1-3) — gated behind `@media (hover:hover) and (pointer:fine)` so touch never shows a stuck hover; touch still shows `:active`. Primary buttons lift toward `--vroozi-gold-bright`; secondary/back/chip/nav get subtle hovers.

### Fixed
- **Residual "SpendTech"** (P0-6) — home hero subtitle "SpendTech® AI Platform" → "AI Procurement Platform"; desktop stage watermark "Vroozi SpendTech®" → "Vroozi AI"; stale `:root` brand comment updated. Contradicted the retired identity and showed on screen one.

### Deferred (a design decision, Phase-2 scope, or simply not in this pass)
- **Visual-harmony, render-required — now UNBLOCKED:** P0-2 surface elevation ramp (OLED low-brightness check), P0-4 text reflow to 200% (zoom testing), P1-4 button-base refactor (pixel-identical regression check), P1-1 chart palette, P1-7 pill unification, P1-8 snap z-index fixes, P2-4 iconography, P2-5 transitions. These were held for lack of a render path; rendering was confirmed available later the same day (Chrome via `localhost:8000`), so they're ready for a dedicated visual pass.
- **Design decision:** P0-3 de-overload gold + caution hue — un-aliasing `--color-warning` to a distinct amber is a brand-language change (single-accent → two-accent); route to the design track. Token plumbing is ready (`--color-warning` already aliases the primitive).
- **Phase 2 / scope:** P1-9 real responsive layout (pushes against the single-file harness), P2-7 font embed.
- **Needs an accessibility/AT pass:** P2-9 — root cause confirmed: home cards and nav items are `div`s with `tap()` handlers and no `tabindex`, so `:focus-visible` never fires on them. Adding focusability is a markup/AX change best done with keyboard + screen-reader testing, not blind.

### Notes
- CSS/markup/token + toast-kind strings only. Nothing touches authentication logic, sessions, crypto, validation, or tenant scoping.
- No `:root` token added or changed, so the styleguide token drift `--check` stays green; shipped *states* (hover, reduced-motion, toast variants, scrim, hit-area pattern) documented in `STYLEGUIDE-NOTES.md` / `vroozi-ai-styleguide.html` (see `STYLEGUIDE-CHANGELOG.md`).
- **Verification:** `node --check`, tag balance, drift `--check`, grep-verified each change. Rendering was then confirmed available (Chrome via `python3 -m http.server 8000` → `localhost:8000`) and used to visually verify P0-6 (hero subtitle "AI Procurement Platform" + "VROOZI AI" watermark) and P0-1 (search-overlay scrim renders as a legible near-opaque surface). Still owed a closer look: tab-through for hover-not-on-touch, a reduced-motion smoke test, and tap reliability on the resized controls.

## [1.23.1] — 2026-06-22

Accessibility + token-coupling fixes from `APP-DESIGN-FIX-PROPOSAL.md` (the ship-now P0/P1 subset; #5B hue change, #7 button-base refactor, #8 tokenization, and #9 font-embed were deliberately deferred).

### Fixed
- **Pinch-zoom restored** (proposal #1) — dropped `maximum-scale=1` from the viewport meta. Was blocking user scaling (WCAG 1.4.4 / 508).
- **`--color-text-muted` now passes AA** (proposal #2) — `#6C7686` → `#939CAB` (3.95:1 → 6.54:1 on canvas; 5.07:1 on the lightest surface it sits on). One token, recolors 49 usages; still reads subordinate to `--color-text-secondary`. No layout change.
- **Visible keyboard focus** (proposal #3) — added a global `:focus-visible` ring (`2px var(--vroozi-gold-bright)`, 2px offset). Uses `:focus-visible`, so it never shows on touch (WCAG 2.4.7). Unified `.chat-input:focus` to the same gold-ring treatment as `.auth-input:focus`.
- **44px hit targets** (proposal #4) — `.uso-close` (30px) and `.home-inbox-btn` (38px) given a 44×44 tappable area via a transparent `::before`; visible glyph sizes unchanged.
- **Cancelled status pill** (proposal #6) — `.req-pill.cancelled` moved from a gold tint to neutral `--color-surface-2` + secondary text so a cancelled order no longer reads like the gold "Financial Review" state.

### Changed
- **Decoupled primary/warning tokens** (proposal #5, Option A) — `--color-primary` and `--color-warning` were two independent `#E8A820` literals; both now alias the `--vroozi-gold` primitive (single source of truth). Zero visual change. Giving warning a distinct caution hue (#5B) is left as a design-track decision, noted inline.

### Notes
- CSS/markup/token only. Nothing touches authentication logic, sessions, crypto, validation, or tenant scoping — the auth-screen items (focus ring, target size) are visual.
- **Verification:** `node --check`, tag balance, contrast recomputed for the changed token. Pixel render not run — no browser host allowlisted; needs a first-load visual check at iPhone 390×844 and iPad 1194×834, plus a tab-through to confirm the focus ring appears for keyboard and not touch.
- Style guide synced: `vroozi-ai-styleguide.html` token + §09 contrast updated for `--color-text-muted` (see `STYLEGUIDE-CHANGELOG.md`).

## [1.23.0] — 2026-06-22

### Added
- **Authentication flow (front-end mock).** Three new screens in the charcoal+gold language:
  - `screen-auth` — sign-in/welcome. SSO as the primary action (neutral glyph, no real provider logo), a passkey option, and an expandable email + password fallback (`authEmailToggle`).
  - `screen-authmfa` — 6-digit MFA via an on-screen numeric keypad (`mfaKeypad`), auto-verifying at six digits (`verifyMfa`), with a resend link.
  - `screen-authlock` — returning-user lock for "Shaz" with a Face ID ring that animates scan → recognized → Home, plus "use a different account".
- New **Authentication** sidebar nav entry; bottom-nav **Profile** now routes to the lock screen.
- Self-contained auth JS module with `resetAuth` / `resetAuthMfa` / `resetAuthLock`, wired into `resetForScreen`. App logo copied from the sidebar at init (`authLogo`), same pattern as the landscape rail.

### Changed
- Bumped all three in-app version stamps to v1.23.0.

### Fixed
- Stale landscape-rail footer stamp "Vroozi SpendTech®" → "Vroozi AI" (missed in the v1.22.0 rename).

### Notes
- Flow paths: SSO → MFA → Home; passkey → Home (passkey is strong two-factor, so MFA is intentionally skipped); email → MFA → Home; lock → Home; sign-out (lock "different account") → welcome.
- **Mock only** — any input succeeds; no credentials stored, no network, no crypto. Auth is **not gated** on load (app still opens on Home). Real authentication (IdP/SSO, server-side session, enforced MFA, WebAuthn) is Phase 2 and crosses the same compliance boundary as model generation.
- **Verification:** `node --check`, structural parse (all JS id references resolve, three screens registered), div/button tag balance — all clean. Pixel render not run (no browser host allowlisted in this environment); needs a first-load visual check at iPhone 390×844 and iPad 1194×834.

## [1.22.1] — 2026-06-22

### Removed
- **The Replay button.** Removed the floating reset FAB entirely: `.reset-fab` CSS (base + device-mode + `@media (hover:none)` rules), the `#resetFab` markup, the `showReset` toggle in `showScreen`, and the `tap($('resetFab'), …)` handler. Cleaned two stale comments ("rep can tap Replay"). `resetForScreen` kept — it still drives per-screen reset on navigation.

### Notes
- Settled the scaffolding keep/cut question (see PROJECT-NOTES → Direction → Scaffolding keep/cut): full-bleed mode reclassified as the product's runtime (kept); desktop preview shell + iPhone/iPad/orientation toggles kept through Phase 1 as a dev harness, retire at Phase 2.
- **Verification:** `node --check` + structural parse + grep for orphaned refs (zero). Pixel render not run — no browser host allowlisted in this environment.

---

## Earlier history

Pre-v1.22.1 entries (initial build through the v1.22.0 "Vroozi AI" rename) live in `PROJECT-NOTES.md` → Changelog. Not duplicated here to avoid forking the record.
