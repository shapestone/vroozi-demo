# Vroozi AI — Design Guide Notes

Living notes for `vroozi-ai-styleguide.html`. This file is the authoritative spec for the **design guide asset**; the app's spec lives in `PROJECT-NOTES.md` and the guide's change history in `STYLEGUIDE-CHANGELOG.md`. Keep all three alongside the HTML.

---

## What it is

`vroozi-ai-styleguide.html` is a separate, self-contained reference asset that documents the design language already in `vroozi-ai.html` — tokens, type, spacing/radius/shadow/motion, the full component catalog (live specimens using the app's real classes), touch/device rules, measured accessibility contrast, and a known-inconsistencies section. It opens the same way as the app and renders in the same charcoal+gold aesthetic. It is a reference only; it does **not** change the app.

- Derived from `vroozi-ai.html` v1.23.0; **tokens synced through app v1.35.0 (99 tokens — the surface-ramp/role-token foundation in v1.33.0 and `--text-3xs`/`--space-7` in v1.35.0 were the last `:root` changes); component specimens documented through app v1.40.0 (Track B accessibility); guide rev v1.0.28, 2026-06-23.** (Was: tokens through v1.29.0 / 79 tokens, specimens through v1.32.0.)
- Single-file, offline, no build step. The only external resource is the same Google Fonts link the app uses (DM Sans + JetBrains Mono).
- The Vroozi logo is the same base64 PNG copied out of the app.

### Sections (11)

Brand & identity · color system · typography · spacing/radius/shadow/easing · motion & keyframes · component catalog (live specimens) · interaction patterns · touch & device rules · accessibility (measured contrast) · known inconsistencies · single source of truth.

---

## Single source of truth (sync policy)

The app and the guide are two separate single files, by Phase 1 design. Token values in the guide are **mirrored, not shared** — copied from the app's `:root`, not imported, so they can drift.

- **Coupled delivery (one-directional).** Every change to `vroozi-ai.html` reconciles this guide **and both changelogs** in the same pass — the full rule is authoritative in `PROJECT-NOTES.md` → Working discipline → Deliver. App change ⇒ guide reconcile; pure guide-only edits touch only the guide docs. A `STYLEGUIDE-CHANGELOG.md` entry is added on **every** app change, even when nothing in the guide changes (record "app vX reviewed; drift `--check` green; no guide-facing change"), so the two changelogs never fall out of step and silent drift is impossible.
- **The guide's in-HTML stamp must always equal the top of `STYLEGUIDE-CHANGELOG.md`.** Four places: sidebar `.toc-meta`, header `.sg-badge`, the §11 footer note, the §15 footer note — plus the "tokens from / synced through app vX" pointer. The stamp silently froze at `v1.0.6` while the changelog reached `1.0.13`; bump all four every rev. (Historical "fix landed in app vX" references in the body are facts, not stamps — leave them.)
- **The app's `:root` is canonical.** If a value disagrees, the app wins and the guide is wrong.
- **Regenerate, don't hand-edit tokens.** When the app's `:root` changes, run the token generator (below) rather than copying values by hand — treat the guide as a build output of the app.
- **Cross-check on every update.** The generator's `--check` mode is the gate (all 79 tokens match exactly as of app v1.29.0 — drift `--check` green). The asset's value is zero if it drifts.
- **Phase 2 retires the split.** Once the app leaves the single-file constraint (repo + server), tokens should move to one shared stylesheet both files import — "mirrored" becomes "shared" and this risk disappears.

### Token generator + drift check

`tools/sync-styleguide-tokens.mjs` (Node, zero dependencies) keeps the guide's tokens in lockstep with the app. It runs at dev time only and adds no runtime dependency; both files stay self-contained single files. (Neither is strictly offline — type loads from the app's Google Fonts link; see `archive/APP-DESIGN-FIX-PROPOSAL.md` #9.)

```
node tools/sync-styleguide-tokens.mjs          # sync guide from app, then verify
node tools/sync-styleguide-tokens.mjs --check  # verify only; exit 1 on drift (CI / pre-commit)
```

- The app's `:root` is canonical. Sync rewrites the guide's `:root` verbatim and corrects the color-swatch chips + `.hex` labels. The invariant is token name → value parity (comments/whitespace don't count as drift).
- **A green `--check` does NOT certify the §09 contrast table.** The check only confirms each contrast *dot color* still matches its token; it never validates the ratio number or the PASS/FAIL label. When a color token changes, the §09 ratios and labels must be recomputed by hand. The check *fails* on a stale dot so the recompute can't be silently skipped — but once the dot color is corrected the gate goes green whether or not the ratios were actually redone. That last step is the human's responsibility. (Use the WCAG luminance formula; a small Python snippet is quickest.)
- **The `--check` gate makes same-pass reconciliation cheap and safe.** Under coupled delivery (above) the app change re-syncs tokens and runs `--check` in the same pass — not deferred to a separate guide session; the gate catches any token drift so it never relies on manual memory. (This updates the earlier "regenerate carefully by hand" guidance.) The one carve-out is the contrast table above: token *color* changes still need a human to recompute §09, because the gate doesn't cover ratios.
- **Out of scope:** the component CSS copied into the guide is a second mirror the generator doesn't touch — keep it aligned by periodic manual diff in Phase 1, or by shared import in Phase 2.
- Run `--check` before publishing (and ideally in CI / a pre-commit hook). After any sync, finish the guide's normal verification: `node --check` the script, confirm tag balance, first-load render.

---

## Working discipline (for editing the guide)

1. **Single-file, offline** through Phase 1 — no deps, no build, no network beyond the app's existing font link.
2. **Read before editing** — the file embeds a ~45 KB base64 logo and a verbatim copy of app component CSS.
3. **Validate JS:** extract the `<script>`, run `node --check`, confirm tag balance.
4. **Cross-check tokens against the app** — drift defeats the asset's purpose.
5. **Verify by rendering:** rendering is available — `python3 -m http.server 8000` in the project dir, then drive Chrome (Claude-in-Chrome) to `http://localhost:8000/vroozi-ai-styleguide.html` and screenshot at desktop width plus a mobile spot-check. (The agent's own sandbox can't render and can't reach the Mac's localhost; rendering runs through the user's Chrome.) `node --check` + structural parse stays the fast path for non-visual changes.
6. **Synthetic only:** sample content stays obviously synthetic ("Shaz", "ACME-TEST-CO"). No real names, emails, vendor or spend data.
7. **Deliver:** save the updated guide; **bump its in-HTML version stamp (all four places) to match the new `STYLEGUIDE-CHANGELOG.md` top**; update `STYLEGUIDE-CHANGELOG.md` in the same pass. Most guide updates are triggered by an app change — follow the coupled-delivery rule in `PROJECT-NOTES.md` (and Single source of truth above): an app change always lands a `STYLEGUIDE-CHANGELOG` entry here, even a no-op "reviewed, no guide-facing change."

---

## Design-system inconsistencies (surfaced building the guide, 2026-06-22 — status updated for app v1.23.1)

Found while documenting `vroozi-ai.html`. **These are app-side fixes**, catalogued here (and in the guide's §10) rather than in `PROJECT-NOTES.md`. The v1.23.1 pass (per `archive/APP-DESIGN-FIX-PROPOSAL.md`) shipped the cheap accessibility + coupling fixes; the heavier refactors were deferred. Status tags below; don't silently re-document different values. `PROJECT-NOTES.md` open items points here.

> **STATUS (2026-06-23, app v1.40.0): the deferred heavy refactors below have shipped.** Proposal #7 "No shared button base" → done v1.34.0 (two grouped bases); #8 "Off-scale sizing" → `--space-7` + `--text-3xs` added and 9px killed v1.35.0 (off-scale *paddings* still deferred to the cosmetic-harmonization pass); the v1.31.0 profile-form duplication folds into the same button/input consolidation; the gold over-load and the broader token work shipped across v1.33.0–v1.40.0. The guide's §10 table reflects this; full detail in `CHANGELOG.md` and `PROJECT-NOTES.md` → "Design-system & accessibility state." The tags on individual rows below are left as written for history.

- **[Partly fixed v1.23.1] `--color-primary` and `--color-warning` were both `#E8A820`.** Now both alias the `--vroozi-gold` primitive (duplicated-literal coupling removed). Warning still resolves to brand gold, so a gold CTA and a gold caution remain visually identical — giving warning a distinct hue (#5B) is a pending design decision; pair with a non-color signal for 1.4.1.
- **[Fixed v1.23.1] `--color-text-muted` AA failure.** Was `#6C7686` (3.95:1 on canvas, failing for 10–11px text); lightened to `#939CAB` (6.54:1 on canvas, 5.07 on the lightest surface) — passes AA, still subordinate to `--color-text-secondary`.
- **[Deferred — proposal #7] No shared button base.** `.auth-btn`, `.uso-cta`, `.anomaly-btn`, `.control-btn`, `.snap-order-btn`, `.inbox-btn` each re-declare the primary-gold pattern independently. Left for the Phase-2 design-system package rather than a risky pixel-identical refactor of the single file.
- **[Fixed v1.23.1] Two input focus treatments.** `.chat-input:focus` now matches `.auth-input:focus` (gold ring); a global `:focus-visible` ring was also added (keyboard/AT only).
- **[Partly fixed v1.23.1] Pill tint collisions.** `Cancelled` moved to a neutral surface-2 + secondary-text treatment, so it no longer reads like the gold `Financial Review`. Still true: `--color-text-link` equals `--vroozi-gold-bright`.
- **[Deferred — proposal #8] Off-scale sizing.** Many text sizes (10/9/11px) and paddings (e.g. `13px 14px`) are hard-coded rather than from `--text-*`/`--space-*`; there is no `--space-7`. Opportunistic cleanup; partly superseded by the Phase-2 token package.
- **[Fixed v1.23.1] Sub-44px touch targets.** `.home-inbox-btn` (38px) and `.uso-close` (30px) given a 44×44 hit area via a transparent `::before`; visible glyph sizes unchanged.
- **[Fixed v1.23.1] Missing `:focus-visible` outlines.** Global `:focus-visible` ring added (keyboard/AT only, never on touch).
- **[Deferred — proposal #10] Stale cosmetic:** `:root` still opens with a "Vroozi SpendTech brand" comment despite the v1.22.0 rename; `reset*Demo` names linger. Zero functional impact; fix opportunistically.
- **[Deferred — added v1.31.0, extends proposal #7] Profile-form components duplicate existing patterns.** The v1.31.0 Profile detail form added one-off styles that overlap what already exists: `.pf-input` is a third near-identical text-input treatment (alongside `.auth-input` and `.chat-input` — same surface-2 fill + gold focus ring), and `.pf-save` is another independent primary-gold button instance (joins the `.auth-btn`/`.uso-cta`/… list under "No shared button base"). The new circular icon buttons `.home-settings-btn` and `.topbar-action` likewise re-declare the `.back-btn`/`.home-inbox-btn` circular-icon-button pattern. None is a bug — they match the existing language visually — but they widen the same consolidation gap. Fold `.pf-input` into a shared input base and `.pf-save` + the icon buttons into shared button bases in the Phase-2 design-system package; not worth a pixel-risk refactor of the single file now.

---

## Related files

- `vroozi-ai-styleguide.html` — the guide itself.
- `tools/sync-styleguide-tokens.mjs` — token generator + drift check (app → guide).
- `tokens.json` — DTCG-format parallel token source (documentation-only; app `:root` is canonical, not yet wired to a build).
- `STYLEGUIDE-CHANGELOG.md` — change history for the guide.
- `archive/STYLEGUIDE-VISUAL-REVIEW.md` — first-load visual QA checklist (rerun each rev; the render check the automated gate can't do).
- `PROJECT-NOTES.md` — authoritative spec for the **app** (`vroozi-ai.html`).
- `CHANGELOG.md` — change history for the **app**.
