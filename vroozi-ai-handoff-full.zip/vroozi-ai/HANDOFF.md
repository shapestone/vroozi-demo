# Handoff — Vroozi AI (Cowork)

Paste at the start of a session, or keep as `HANDOFF.md`. This is intentionally thin. For a colleague picking up the work, **start with `ROADMAP.md`** (front door: current state, what to send, what's next, asset map), then this file, then **`PROJECT-NOTES.md` (authoritative)** — the direction, phases, architecture, conventions, and discipline all live there.

---

## What this is

`vroozi-ai.html` is a single self-contained HTML file (v1.40.0 — Inter UI / Roboto Mono numbers) — an internal build of an AI-assisted procure-to-pay experience for Vroozi (B2B procure-to-pay), in active development, iterated with design and shown to internal stakeholders.

**Recent arc (v1.33.0–v1.40.0):** a token-and-accessibility pass on top of v1.32.1 — a role-named token layer (surface ramp, state/scrim/gradient, on-fill), one shared button base, sizing tokens (`--text-3xs`/`--space-7`), and Track B accessibility (native buttons + `nav` landmarks + `aria-current`, live regions, a focus-trapped search dialog, focus-on-screen-change). Theming-ready and keyboard-operable; **not yet screen-reader-certified** — a manual NVDA/VoiceOver pass is the open 508/AA gate. The light/high-contrast themes are Phase 2 (Track C). See `PROJECT-NOTES.md` → "Design-system & accessibility state" and `CHANGELOG.md` for detail.

Two tracks, two sets of docs — **coupled on every app change** (see PROJECT-NOTES → Working discipline → Deliver):
- **App** — `vroozi-ai.html` ← `PROJECT-NOTES.md` (authoritative spec) + `CHANGELOG.md` (log).
- **Design guide** — `vroozi-ai-styleguide.html` ← `STYLEGUIDE-NOTES.md` (authoritative spec) + `STYLEGUIDE-CHANGELOG.md` (log). Reference asset only; mirrors the app's `:root`, never changes the app.

A change to `vroozi-ai.html` is not done until the guide and **both** changelogs are reconciled in the same pass (one-directional: app change ⇒ guide reconcile; guide-only edits touch only guide docs). Skipping it is how the omnibox specimen and the guide's own version stamp went stale for several revs.

## Where it's going

Two phases, detailed in `PROJECT-NOTES.md` → Direction:
- **Phase 1:** free-text input matched to existing scripted responses. Stays single-file.
- **Phase 2:** real model generation. Ends single-file; becomes a repo with a server-side key.

The Phase 1→2 boundary is one function, `getResponse(userText, context)`, returning the step-array shape `runSequence` already renders. Build behind that seam or Phase 1's work is thrown away at Phase 2. Match state-scoped (current chips first). Design the no-match state deliberately — free text reintroduces "I don't understand," which chips made impossible.

## Recently shipped

- **v1.32.1** — Expanded the mock `CATALOG` from 16 to **50 synthetic items** across 8 categories (added Medical / Lab & Scientific / Industrial / Energy from six more supplier files). Data-only; no structural/seam/UI change. Provided files again carried production identifiers — shape only was used (grep-verified). See `CHANGELOG.md` 1.32.1.
- **v1.32.0** — A single embedded **product catalog** (`CATALOG`, 16 synthetic items) behind a **search seam**: `searchCatalog(query, opts)` returns ranked records; `productCardHTML` is the one render path; Phase 2 swaps only `searchCatalog`'s body for real semantic search. Folded the scattered product literals (Voice/Snap MacBook, Chat gloves, refurb, desk) into `CATALOG`; wired live catalog search into the omnibox + Snap; added a Shop **Catalog browse** screen. Kickoff brief: `archive/PRODUCT-CATALOG-HANDOFF.md`. Continuity numbers held; all values synthetic (provided "demo" files carried production identifiers — shape only was used).
- **v1.31.0** — Split the account hub: **Profile** is now a detail form (contact info, system preferences, change password, document defaults — all synthetic), and **Settings** is its own destination with a left sub-nav (Notifications, Appearance, Privacy & Security, About — the old standalone About screen folded in here). Settings is reachable as a NAV item (rail + desktop sidebar Account group) and via gear cogs on the Home + Profile headers. All mock; MFA shown enabled and non-interactive.
- **v1.30.0** — Account surfaces, dynamic account name (`state.userName`, escaped echo), more mock auth flows, single `APP_VERSION` constant driving the version display. Kickoff brief: `archive/AUTH-PROFILE-HANDOFF.md`. Auth stays a front-end mock — real auth, password change, and sessions are Phase 2.

## Start every session here

1. Read `PROJECT-NOTES.md` in full, then the region of `vroozi-ai.html` you're about to change. The file is large and cross-referenced.
2. Confirm the current version and which phase you're in.
3. State what you'll change and why before changing it. Confirm anything non-trivial.

## Working discipline (full version in PROJECT-NOTES.md)

- Phase 1 stays single-file: no deps, no build, no network.
- Route matching through `getResponse`, never into the UI directly.
- Validate JS: extract `<script>`, run `node --check`.
- Verify by rendering, don't assume. Rendering is available: `python3 -m http.server 8000` in the project dir, then drive Chrome (Claude-in-Chrome tools) to `http://localhost:8000/vroozi-ai.html` and screenshot at phone and tablet widths. The agent sandbox itself can't render (no X libs/root) and can't reach the Mac's localhost — it goes through the user's Chrome. `node --check` + structural parse is fine for label-only changes; screenshot anything visual.
- Test the new states: no-match, empty, and (Phase 2) loading/error/timeout.
- Scale-aware: `getBoundingClientRect()` offsets divide by `window.__appScale || 1`.
- Phase 2: no keys in client code; real spend data to an external model is a compliance decision, not just engineering.

## Don't reintroduce

The retired sales framing (on-rails-as-value, CFO-lens-as-constraint, verbal close, the no-feedback-cards rule, companion cheat-sheet/run-sheet) and "demo"/"prototype" as the product's identity — it's just Vroozi AI. See PROJECT-NOTES.md → Retired / Kept.

## Scaffolding decision (settled 2026-06-22)

Resolved — see `PROJECT-NOTES.md` → Direction → Scaffolding keep/cut. Replay button **cut** (v1.22.1). Full-bleed mode **kept** (reclassified as the product's runtime, not scaffolding). Desktop preview shell + iPhone/iPad/orientation toggles **kept through Phase 1** as a dev harness, retire at Phase 2. Only open thread: cut the shell sooner if review never happens on a laptop.

## Deliver

A `vroozi-ai.html` change, in one pass: save the updated HTML; bump the single `APP_VERSION` constant (drives the About screen — the old three stamps are gone as of v1.30.0); update `PROJECT-NOTES.md` + `CHANGELOG.md`; **and reconcile the guide** — run `node tools/sync-styleguide-tokens.mjs --check`, update any guide specimen the change touches, add a `STYLEGUIDE-CHANGELOG.md` entry (even a no-op "reviewed, no guide-facing change"), and bump the guide's in-HTML stamp (4 places) to match. Both changelogs always advance together. Pure guide-only work updates only the guide docs. Full rule: `PROJECT-NOTES.md` → Working discipline → Deliver. Move to a repo at Phase 2.
