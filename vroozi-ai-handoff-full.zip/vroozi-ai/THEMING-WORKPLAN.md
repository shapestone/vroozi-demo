# Theming Work Plan — Light / Dark / High-Contrast

Sequenced plan to reach three themes, with verified current state and the styleguide reconcile each step triggers. Companion to `THEMING-FEASIBILITY.md`. Analysis only; no app/guide changes made here.

Verified against `vroozi-ai.html` **v1.32.1** (APP_VERSION constant) and `CHANGELOG.md`, 2026-06-23.

> **STATUS (2026-06-23, now app v1.40.0): Track A and Track B have shipped.** This plan is now a historical record of the sequencing, not an open to-do. Track A — P0-2 surface ramp + state/scrim/gradient tokens (v1.33.0), P1-4 shared button base (v1.34.0), P2-1/P2-2 sizing tokens (v1.35.0) — and Track B 508 semantics (v1.36.0–v1.40.0) are done; see `CHANGELOG.md` and `PROJECT-NOTES.md` → "Design-system & accessibility state." **Track C (the actual light/high-contrast theme values) remains Phase 2.** The cosmetic button harmonization and off-scale padding snapping are deferred; a manual screen-reader pass is the open 508/AA gate.

## What's already done (don't re-scope it)

Checking the live file corrected three assumptions. These prerequisites already shipped:

| Item | Backlog ID | Verified in v1.32.1 |
|---|---|---|
| Brand-derived chart palette | P1-1 | **Done.** `#4CAF50` is gone (0 hits); `--chart-1..6` defined and used (11 `var(--chart-*)` references). |
| Caution/warning hue split (1.4.1) | proposal #5B | **Done.** `--color-caution: #F2994A` exists; `--color-warning` aliases it, so primary gold no longer equals warning. (Shipped ~v1.25.0.) |
| Reduced-motion substitute | P2-3 | **Done.** `animation-iteration-count:1 !important` in the `prefers-reduced-motion` block (not just zeroed durations). |

The docs are in sync at this version (confirmed 2026-06-23): app `APP_VERSION = 1.32.1`, `CHANGELOG.md` top `[1.32.1]`, `STYLEGUIDE-CHANGELOG.md` top `[1.0.18]` reviewed against app v1.32.1, and the styleguide HTML stamped `guide v1.0.18 · app v1.32.1`. The guide runs its own `1.0.x` line plus an "app vX" pointer; both currently point at v1.32.1. One small content nit (not a version drift): the §09 "1.4.1 Use of color" cell still reads "primary still equals warning #E8A820 until proposal 5B," which is outdated — 5B shipped (~v1.25.0) and §10 already marks it resolved. The "Partially" rating itself still holds, because gold remains primary + link + Financial-Review status. Tidy that clause whenever §09 is next touched.

## What's still open (the real prerequisite list)

All verified present in v1.32.1:

| Item | Backlog ID | Evidence | Effort |
|---|---|---|---|
| Surface elevation ramp + tokenize gradient stops | P0-2 | 13 `linear-gradient(...#hex...)` literals; near-black surfaces ~1.04–1.06:1 apart | M |
| Shared `.btn` base | P1-4 (supersedes #7) | 9 independent gold-button classes (`auth-btn`, `uso-cta`, `anomaly-btn`, `control-btn`, `snap-order-btn`, `inbox-btn`, `pf-save`, `home-settings-btn`, `topbar-action`); no `.btn` base | M |
| Tokenize off-scale sizes; add `--space-7` | P2-1 | no `--space-7`; off-scale paddings/sizes | M |
| Kill 9px text; map 10px → `--text-2xs` | P2-2 | 13 `9px` font-sizes | S |
| **State-fill + scrim tokens (net-new, theming-specific)** | — | 19 `rgba(255,255,255,.04–.12)` overlays, 5 `rgba(0,0,0,…)` scrims, 13 `color:#fff`, 14 repeated semantic hex | M |

Total color literals outside `:root` in component CSS: **169** (66 hex, 103 rgba) — unchanged from the feasibility count. The last row isn't an existing backlog ID; it's the work that only a second theme forces, because white-on-translucent-white hover fills are invisible on a light base and have to become theme-varying tokens.

## Sequencing

Three tracks. The first two run inside Phase 1 and are worth doing on their own merits; the third is the Phase-2 payload.

### Track A — Token hygiene (Phase 1, no theme yet)

Order chosen so the heaviest `:root` pass lands once and everything regenerates through the guide together.

1. **P0-2 surface ramp + gradient tokenization.** Rebuild the surface ladder to ~1.2:1+ per step, demote near-blacks to one scrim/shell value, move the 13 gradient stops onto tokens. This is the foundation a light/HC theme overrides.
2. **State-fill + scrim tokens (net-new).** Promote the 19 white overlays to a `--state-hover-fill` / `--state-active-fill` pair, the 5 black scrims to a `--scrim` token, and the 14 repeated semantic hex to their `var(--color-*)`. After this, a theme override actually reaches every surface. Do it adjacent to P0-2 since both touch the same rules.
3. **P1-4 shared `.btn` base.** Collapse the 9 button classes into one base + modifiers, one `:active` scale. Pixel-identical refactor, so gate it with a visual-regression check.
4. **P2-1 / P2-2 sizing tokens.** Add `--space-7: 28px`, migrate off-scale sizes, kill 9px text. Lower priority for theming specifically (sizing isn't color), but it closes the px-driven zoom gap (1.4.4) and finishes the token surface.

Each step here is a `:root` or component-CSS change, so each triggers the full app→guide reconcile (below).

### Track B — 508 semantics (parallel, color-independent)

This is the heavier accessibility lift and it gates the *meaning* of an "ADA version." Doesn't depend on Track A and shouldn't wait for it. From the styleguide's own gap list: make clickable `<div>`s (home cards, nav items, MFA keypad, `.uso-pill`) real buttons/links with keyboard handlers; add `role`/`aria-current="page"`/`nav` landmark; add `role="status"`/`aria-live` to toasts and `aria-live="polite"` to loaders; add `aria-disabled`/`aria-busy`; verify `:focus-visible` lands on every interactive element (P2-9). Track this as its own workstream with a keyboard + screen-reader pass.

### Track C — The theme layer (Phase 2)

Lands when the single-file constraint ends and tokens move from mirrored to shared (one stylesheet both app and guide import — `STYLEGUIDE-NOTES.md` "Phase 2 retires the split"). Only possible cleanly after Track A.

> **The high-contrast ("ADA") theme — the cheap, high-value first Track C deliverable — now has a concrete, implementable spec in `THEMING-HC-SPEC.md`** (token overrides for visible control borders / nav separators / stronger focus + AAA-leaning contrast, the `[data-theme]` mechanism, and the build sequence). Captured 2026-06-23 against app v1.40.1. Light remains the harder, separate job (re-tuned palette + gold-as-fill-only).

1. **Define value-sets** under `[data-theme="dark|light|hc"]` overriding the shared token set. Dark = current values.
2. **Re-tune for light.** New darker semantic palette (success/info/destructive/caution), gold demoted to fill-only (it fails ≥3:1 on white as foreground), parallel gradient/overlay/shadow values keyed off the Track-A tokens.
3. **Re-measure all contrast** for light and HC; rebuild §09 with one table per theme.
4. **Theme switch + persistence.** Attribute swap is pure CSS; persisting the choice needs the Phase-2 session/storage.

## The reconcile each Track-A step triggers

Every app change in Track A is a coupled delivery. Same pass, no deferral (`PROJECT-NOTES.md` → Working discipline → Deliver; `STYLEGUIDE-NOTES.md` → Single source of truth):

1. Edit `vroozi-ai.html`; bump the `APP_VERSION` constant (drives the About screen — the three scattered stamps were removed in v1.30.0).
2. Re-sync guide tokens: `node tools/sync-styleguide-tokens.mjs`, then `--check` (exit 1 on drift). This rewrites the guide `:root` and the swatch chips/`.hex` labels.
3. **Recompute §09 contrast by hand** for any changed color token (WCAG luminance; a small Python snippet is quickest). The `--check` gate confirms swatch parity, *not* ratios — it goes green on a corrected dot whether or not the ratio was redone, so this step is on the human.
4. Update component CSS mirrored into the guide where a step changed it (the generator doesn't touch component CSS — manual diff in Phase 1).
5. Advance the guide's own `1.0.x` version and bump the dual stamp (`guide v1.0.X · app v1.Y.Z`) in all four places — sidebar `.toc-meta`, header `.sg-badge`, §11 footer, §15 footer — plus the "tokens from / synced through app vX" pointer, matching the new `STYLEGUIDE-CHANGELOG.md` top.
6. Add entries to **both** changelogs in the same pass — `CHANGELOG.md` for the app, `STYLEGUIDE-CHANGELOG.md` for the guide (even a no-op "app vX reviewed, no guide-facing change" so the two never fall out of step).
7. Verify: extract `<script>`, `node --check`, tag-balance/structural parse; then render through Chrome at phone (~390–430) and tablet widths (the sandbox can't reach localhost). Cover the new states, not just the happy path.

The docs are in sync today, so there's no backlog of guide drift to clear first — each Track-A step just runs the coupled-delivery reconcile above. The one freebie to fold in: tidy the outdated clause in the §09 1.4.1 cell the next time that section is edited.

## Recommendation

Run Track A now, inside Phase 1 — it's net-positive for the styleguide and surface harmony regardless of theming, and it's the gating prerequisite. Start Track B in parallel; it's the real cost of "accessible" and it's orthogonal to color. Hold Track C for Phase 2, when shared tokens make three palettes maintainable instead of a triple-mirror drift problem. Smallest first step that de-risks everything: P0-2 plus the state-fill/scrim tokens as one `:root` pass, since that's what proves whether a single token override can actually re-skin the whole app.
