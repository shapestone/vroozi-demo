# Vroozi AI — Unified Design/UX Backlog

One prioritized punch list consolidating `archive/DESIGN-UX-REVIEW.md` (color, type, responsive, components), `archive/DESIGN-UX-REVIEW-ADDENDUM-2.md` (live interactive pass), and the still-open items from `archive/APP-DESIGN-FIX-PROPOSAL.md`. Against the running file `vroozi-ai.html` **v1.23.1**. Analysis only — nothing here is implemented yet.

> **STATUS (2026-06-23, now app v1.40.0): the P0/P1/P2 token & accessibility items below have largely shipped** (v1.33.0–v1.40.0 — surface ramp + role tokens, shared button base, sizing tokens, 44px targets, keyboard/ARIA/focus management). This list is now historical; the "nothing here is implemented yet" line above no longer holds. Current state is in `CHANGELOG.md` and `PROJECT-NOTES.md` → "Design-system & accessibility state." Remaining: cosmetic button harmonization, off-scale padding snapping, the light/high-contrast themes (Phase 2 / Track C), and a manual screen-reader conformance pass.

Priority key: **P0** correctness / accessibility / the harmony headline (ship first) · **P1** structural consistency · **P2** debt and polish. Effort/risk are rough. "Source" points back to the originating review so detail isn't re-litigated here.

Every P0 is CSS / token / markup only — none touch authentication logic, sessions, crypto, input validation, or tenant scoping. The auth-screen items are visual. After any color-token change: recompute the styleguide §09 contrast table by hand (the drift `--check` confirms swatch parity, not ratios), regenerate guide swatches, bump the three version stamps (sidebar, rail, inbox) and add a `CHANGELOG.md` entry in the same pass.

---

## P0 — ship first

| ID | Item | Why | Effort | Risk | Touches | Source |
|---|---|---|---|---|---|---|
| P0-1 | Search-overlay scrim legibility | Overlay unreadable when backdrop-blur is absent (transformed-ancestor harness; iOS Reduce Transparency = low-vision a11y). Raise scrim to ~0.92+ or give the panel a solid `--color-surface`; treat blur as enhancement. Re-check the other 4 blur consumers under Reduce Transparency. | S | low | `.usearch-overlay` (+ audit `.status-bar`,`.bottom-nav`,`.chat-input-area`,`.snap-result`) | Add-2 |
| P0-2 | Surface elevation ramp | Adjacent surfaces step ~1.14:1 (pop/navy ~1.04–1.06:1); flat on OLED at low brightness — primary use case. Rebuild lighter ramp (~1.2:1+/step), demote near-blacks to one scrim/shell value, migrate ~11 off-token gradient stops onto tokens. | M | medium | `:root` surfaces + gradient literals | Review 1A |
| P0-3 | De-overload gold + distinct caution hue | Gold carries 5 meanings (primary, Financial-Review status, caution, current-step, link) — color stops disambiguating. Decide the 2–3 jobs gold keeps; add a caution amber (e.g. `#F5A623`), un-alias `--color-warning`; pair caution with a non-color cue. WCAG 1.4.1. | M | medium | `:root` + `.req-pill.financial`, spike-alert, timeline-current, link color | Review 1B + Add-2 |
| P0-4 | Text scaling / reflow to 200% | Fixed `100dvh` + `overflow:hidden` clips enlarged text; ~35 hardcoded 9–11px sizes ignore user settings. Let scroll bodies use `min-height` so text reflows; verify nothing lost at 200% browser zoom. WCAG 1.4.4. | M | medium | scroll-container CSS, body | Review 1D |
| P0-5 | 44px touch targets on core controls | Back button (36px), bottom-nav (~38–40), inbox Approve/Reject (~30), chat send (42) miss 44pt. Apply the proven transparent-`::before` hit-area trick already used on `.uso-close`/`.home-inbox-btn`. | S | low | `.back-btn`,`.bottom-nav-item`,`.inbox-btn`,`.chat-send`,`.usearch-mode`,`.suggest-chip` | Review 1E |
| P0-6 | Residual "SpendTech" cleanup | Rename missed the home hero subtitle ("SpendTech® AI Platform") and the desktop stage watermark ("VROOZI SPENDTECH®"); rail/footer are correct. Contradicts the retired identity; stakeholder sees it on screen one. Trivial. | XS | none | home hero markup, stage watermark | Review live-verify |

P0-1 and P0-6 are independent quick wins. P0-2/P0-3 are the harmony core and should land together as one `:root` pass (they share the token block and both regenerate through the styleguide sync). P0-4 is the heaviest P0 — needs a real device/zoom check, so timebox it separately if it threatens the others.

---

## P1 — structural consistency

| ID | Item | Why | Effort | Risk | Source |
|---|---|---|---|---|---|
| P1-1 | Brand-derived chart palette | Spend/supplier charts use a Material rainbow (blue/teal/gold/green/purple/red) + a 2nd green that clashes with the success token. Derive 6 categories from the semantic family; drop teal/purple/Material tones; replace every `#4CAF50` with `var(--color-success)`. | M | low | Review 1C |
| P1-2 | Disabled / busy button state | No button class defines disabled; async/destructive actions (snap submit, anomaly reject, inbox approve) can be re-fired. Define disabled (Material 38%/12%), wire into async flows; generalize the auth `busyBtn` pattern. | M | low | Review 2B + Add-2 |
| P1-3 | Hover state for buttons | Desktop target — every button is hover-dead. Add subtle hover (toward `--vroozi-gold-bright`) gated behind `@media (hover:hover) and (pointer:fine)`. | S | low | Review 2B + Add-2 |
| P1-4 | Shared `.btn` base + one `:active` scale | Six button classes re-declare gold-fill independently; 3 radii, 3 font-sizes, 4 press scales (0.96/0.97/0.98/0.985). Extract `.btn` + modifiers; unify to one press scale. Pixel-identical refactor — worth a visual-regression check. (Supersedes proposal #7.) | M | medium | Review 2A; Proposal #7 |
| P1-5 | Toast success/error/info variants | Success and "review" both render the gold dot (seen on snap submit). Add variants using existing `--color-success/destructive/info`. | S | low | Add-2 |
| P1-6 | Empty / no-match / error / loading components | Only bare list-empty + auth spinner exist; the Phase-1 `getResponse` seam is unbuilt and chat input is `readonly`. Build shared empty (icon+headline+CTA), inline error+retry, loading/skeleton; add field-error to text inputs. | M | low | Review 3E + Add-2 |
| P1-7 | Pill/badge unification | 5+ size systems (`.req-pill`,`.pr-badge`,`.nav-badge`,`.nav-tag`,`.product-tag`,`.snap-result-badge`). One `.pill` base + color modifiers. | M | low | Review 2C |
| P1-8 | Snap-flow fixes | "Identified" badge clipped by header (z-index/position); success button is a green gradient one-off (make it flat/tokenized); "Ready to Submit" pill stays stale after submit. | S | low | Add-2 |
| P1-9 | Real responsive layout | No content breakpoints; desktop = scaled 390px phone frame; iPad rail is JS-class-gated, not width-gated. Add Material window-size breakpoints, trigger the rail at `min-width:840px`, give desktop a max-width column or two-pane Expanded layout. | L | medium | Review 2D |

P1-2/P1-3/P1-4 are one button-system pass. P1-9 is the largest single item and is arguably a Phase-2 concern (it questions the single-file harness) — flag for a scope decision before starting.

---

## P2 — debt and polish

| ID | Item | Why | Source |
|---|---|---|---|
| P2-1 | Tokenize off-scale sizes; add `--space-7: 28px` | 9/10/11px sizes and `13px`/`7px` paddings bypass tokens; scale jumps 24→32. Migrate opportunistically. (Proposal #8.) | Review 3A/3B; Proposal #8 |
| P2-2 | Kill 9px text; map 10px → `--text-2xs` | 9px is sub-legible on a phone (under Apple's ~11pt floor); `--text-2xs` exists for this and is unused in screens. | Review 3A |
| P2-3 | Reduced-motion: substitute, don't delete | Global block zeroes durations but strips meaning-bearing motion (processing orb, scan, typing) with no static substitute; set `animation-iteration-count:1`. Route off-token motion (4 easings, hardcoded 350/800ms, `transition:all`) through `--transition-*`/`--ease-out`. | Review 3C |
| P2-4 | Iconography consistency | Unify stroke-width to 2 across the UI set; replace status-glyph emoji (✓/⚠) with the existing stroke SVGs; document product/scan emoji as a separate illustration tier. | Review 3D |
| P2-5 | Screen-transition polish | Cross-fade briefly double-exposes two content screens; prefer a slide or cover-with-opaque-surface. | Add-2 |
| P2-6 | Chip-to-input speed | Typewriter animation on chip select is sluggish for repeat use; make fill near-instant. | Add-2 |
| P2-7 | Self-host / embed fonts | DM Sans + JetBrains Mono load from Google Fonts; air-gapped/residency-restricted gov tenants render fallback. Embed or self-host. (Proposal #9.) | Proposal #9 |
| P2-8 | Cosmetic + doc drift | Stale `/* Vroozi SpendTech brand */` `:root` comment; `reset*Demo` identifiers; `PROJECT-NOTES.md` header still says v1.23.0 (file is v1.23.1). (Proposal #10.) | Proposal #10 |
| P2-9 | Verify focus-visible coverage | The shipped 2px gold ring wasn't visibly landing on home elements in a quick tab test — confirm tab order surfaces it on every interactive element. | Add-2 |

---

## Styleguide work (parallel track, not app edits)

Defined in Add-2 and carried into `vroozi-ai-styleguide.html`: the element × state matrix (default / hover / pressed / focus-visible / selected / disabled / loading / empty / error) and per-state platform labels — hover gated to `@media (hover:hover)`, `:focus-visible` keyboard-only, one shared `:active`, disabled defined and wired. Document hover and pressed as separate states even though touch only shows pressed, so the desktop build isn't dead and the touch build doesn't show stuck hover. This is styleguide-doc work (`STYLEGUIDE-NOTES.md` + `STYLEGUIDE-CHANGELOG.md`), kept off the app track except where a state needs a new app token.

---

## Suggested order

1. P0-1 and P0-6 first — isolated, cheap, one visibly broken and one visibly wrong.
2. P0-2 + P0-3 as a single `:root` harmony pass (surfaces + gold), then P1-1 chart palette rides the same token work. Recompute §09 contrast, regenerate guide swatches.
3. P0-4 + P0-5 as an accessibility pass (text reflow + hit areas) — what a Section 508 / WCAG audit catches.
4. P1-2/3/4 button system, then P1-5/6/7 component definitions, then P1-8.
5. P1-9 only after a scope decision (it pushes against the single-file constraint — likely Phase 2).
6. P2 opportunistically while touching the relevant regions.
