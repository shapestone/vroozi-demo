# Theming Feasibility — Light / Dark / ADA

Analysis of `vroozi-ai.html` (v1.32.1, the master) and `vroozi-ai-styleguide.html` (guide v1.0.18 · app v1.32.1), 2026-06-23. Scope: feasibility only. No app or guide changes made; no version stamps touched.

> **STATUS (2026-06-23, now app v1.40.0): the prerequisite refactor this doc analyzes has shipped.** The ~169 hardcoded literals were promoted to role tokens (v1.33.0) and the 508 semantics work landed (v1.36.0–v1.40.0); see `CHANGELOG.md` / `PROJECT-NOTES.md`. This remains the reference for *why* a light theme isn't a token flip (gold can't be a foreground accent on white — 2.09:1) and what **Track C** still requires in Phase 2 (a re-tuned semantic palette, gold demoted to fill-only, parallel gradient/overlay/shadow sets, per-theme §09). Dark is shipped; light + high-contrast are Phase 2.

## Verdict

A dark theme already exists and is the product. A **high-contrast "ADA" theme is genuinely feasible** and is the cheapest of the three to add. A **light theme is feasible but is not a token flip** — it's a second hand-tuned palette plus a structural refactor, and it forces a real design decision about the gold accent. Don't build three parallel themes by duplicating CSS. Build one token-driven theming layer and define three value-sets against it. That work is mostly the Phase-2 design-system refactor the backlog already names (proposal #7/#8, P2-1/P2-2), pulled forward.

Two things have to be true before any second theme is cheap, and neither is true today:

1. The component CSS must reference only semantic tokens. It doesn't — there are ~169 hardcoded color literals outside `:root` (66 hex, 103 rgba). Flipping a token won't reach them.
2. The semantic palette must be theme-independent. It isn't — it's tuned for dark surfaces and collapses on light (evidence below).

## Why light is not a flip — the evidence

Contrast ratios, recomputed (WCAG relative luminance) for the current tokens against a white-ish canvas:

| Token | on #FFFFFF | on #F7F8FA | AA normal (4.5) | AA large/UI (3.0) |
|---|---|---|---|---|
| `--vroozi-gold` #E8A820 | 2.09 | 1.97 | FAIL | FAIL |
| `--vroozi-gold-bright` #F6BE3A | 1.70 | 1.60 | FAIL | FAIL |
| `--vroozi-gold-deep` #C8881A | 3.00 | 2.83 | FAIL | PASS (barely) |
| `--color-success` #57D98A | 1.80 | 1.69 | FAIL | FAIL |
| `--color-destructive` #F4796B | 2.69 | 2.54 | FAIL | FAIL |
| `--color-info` #5FA8F5 | 2.50 | 2.35 | FAIL | FAIL |
| `--color-caution` #F2994A | 2.23 | 2.10 | FAIL | FAIL |
| `--color-text-secondary` #AFB8C6 | 2.00 | 1.88 | FAIL | FAIL |
| `--color-text-muted` #939CAB | 2.77 | 2.61 | FAIL | FAIL |

Every accent and text token fails on white. The same colors score 5–10:1 on the dark canvas (styleguide §09) because they were chosen to be bright on charcoal. Bright-on-charcoal is the same thing as washed-out-on-white. A light theme needs a re-tuned, darker palette across the board, then a full re-measure.

The sharpest consequence is the brand accent. Gold on white is 2.09:1 and gold-deep only scrapes the 3:1 UI floor, so in a light theme **gold cannot be text, an icon, a link, a border, or a focus ring** — every place the dark theme currently uses it as a foreground accent. Gold survives only as a *fill* with dark text on it (ink-on-gold holds at 9.36:1). The dark theme leans on gold as a foreground accent constantly (active nav border, links, focus ring, chip text, caret). A light theme has to relocate the accent's entire job. That's a design call, not a value swap, and it's the single biggest reason "just add a light mode" is misleading.

## What the codebase makes hard

There is no theming layer at all today: no `[data-theme]`, no `.light`/`.dark` class, no `prefers-color-scheme` block, one `:root`. Token discipline at the *semantic* level is decent (826 `var()` references), but the component CSS leaks raw color in three patterns that each break on a light base:

- **19× `rgba(255,255,255, .04–.12)` overlays.** Every nav hover, active fill, and device-button state is "lighten with translucent white." On a light surface that's white-on-white — invisible. Light mode needs the inverse (translucent black), which means these can't be one shared rule; they have to become tokens.
- **24× hardcoded gradients** with baked charcoal stops (`#242E3D→#1A2330` cards, `#0A0C11→#11151D` screen backdrops, the phone-frame). These are hand-tuned dark ramps. Light needs a parallel set, not an inversion.
- **5× `rgba(0,0,0,…)` scrims + the shadow tokens.** Dark-on-dark shadows read as depth; on light they're too heavy and the camera/snap scrims invert in meaning.

Plus repeated semantic *literals* (`#57D98A`, `#5FA8F5`, `#F4796B`, `#fff`) used instead of `var(--color-success)` etc. Cheap to fix, but until fixed they bypass the token layer, so a theme override never touches them.

## The three themes, costed honestly

**Dark** — shipped. No work.

**ADA / high-contrast** — *low–moderate, do this first.* The dark theme already passes AA for all text tokens, has `:focus-visible`, honors `prefers-reduced-motion`, and meets 44px targets (§09). An "ADA theme" in the visual sense is a darker-canvas / brighter-text / thicker-border variant pushing text toward AAA (7:1) and giving non-text UI a hard 3:1 border. Because it stays on a dark base, the white-overlay and gradient problems mostly survive. The expensive part isn't the palette — see the next paragraph.

**Light** — *moderate–high, and gated on the refactor.* Net new work beyond the shared refactor: a re-tuned semantic palette (darker success/info/destructive/caution), a relocated accent strategy (gold as fill-only), a parallel gradient/overlay/shadow set, and a full contrast re-measure. Then mirror all of it in the styleguide, including a second §09 table, because the guide is a build output of the app and the drift gate only checks swatch parity, not ratios.

## What "ADA version" actually means — pin this down

The word is doing two jobs and they have very different costs:

- **A high-contrast theme** (a visual variant). That's the palette/token exercise above. Feasible.
- **Section 508 / WCAG 2.2 AA conformance of the app itself.** That is *not* a theme. The styleguide is candid about the open gaps: clickable `<div>`s for nav and home cards that aren't keyboard-reachable and carry no `role`/`aria-current`; toasts with no `role="status"`/`aria-live`; the MFA keypad not keyboard-operable; no `aria-disabled`/`aria-busy`; and ~35 hardcoded px sizes that don't respond to text-only zoom (P2-1/P2-2). Those are markup and ARIA fixes in the app, independent of color, and they're the heavier lift. A high-contrast skin over an app that isn't keyboard-operable would look accessible and fail an audit. Given the stated target (508 + AA for federal/SLED buyers), I'd treat the semantics work as the priority and the high-contrast theme as the easier companion.

## Recommended approach

1. **Don't fork CSS three ways.** One theming layer: keep component CSS referencing semantic tokens only, then override the value-set per theme via `[data-theme="dark|light|ada"]` on the root element. Pure CSS, no JS data calls, no new dependency — it stays inside the Phase-1 single-file constraint. (A toggle is an attribute swap; the auth mock and "no network" rules are untouched.)
2. **First, eliminate the ~169 literals** by promoting them to tokens — especially the white-overlay pattern (becomes a `--state-hover-fill` style token that differs per theme), the gradients, and the shadow/scrim set. This is proposal #7/#8 work; a second theme is the forcing function that makes it worth doing now rather than at Phase 2.
3. **Re-tune, don't invert, for light.** New darker semantic values; gold demoted to fill-only; re-measure every pair.
4. **Sequence:** literal→token refactor → ADA/high-contrast theme (cheap, dark-based, high buyer value) → light theme (after the accent decision) → mirror both into the styleguide with their own §09 tables and re-sync the token generator.
5. **Separately, schedule the 508 semantics pass** (keyboard reachability, roles, `aria-current`/`aria-live`, px→rem). It's the real accessibility cost and it's orthogonal to color.

## Bottom line

Feasible, yes. "Three versions of the same palette," no. The honest framing for stakeholders: one is done (dark), one is cheap and high-value for government buyers (high-contrast, if we also fund the keyboard/ARIA semantics it implies), and one is a genuine design-and-refactor project (light, because the brand accent doesn't survive a white background). The prerequisite for all of it is collapsing the 169 hardcoded colors into the token layer — which the project already wants for Phase 2.
