#!/usr/bin/env node
/*
 * sync-styleguide-tokens.mjs
 * One-way token sync: vroozi-ai.html (canonical) -> vroozi-ai-styleguide.html.
 *
 * Phase-1 dev tool. Zero dependencies, pure Node ESM. It does NOT run at app
 * runtime and adds no runtime dependency — it reads/writes the two single-file
 * HTML artifacts, which stay self-contained and offline. Think of it as the
 * "build" that keeps the guide a faithful mirror of the app's :root.
 *
 * Usage:
 *   node tools/sync-styleguide-tokens.mjs          Sync the guide from the app, then verify.
 *   node tools/sync-styleguide-tokens.mjs --check  Verify only. Exit 1 on drift. (CI / pre-commit)
 *   node tools/sync-styleguide-tokens.mjs --help
 *
 * What it covers:
 *   - The guide's :root block            (rewritten verbatim from the app's :root)
 *   - The color-swatch chips + .hex labels in the guide   (auto-corrected)
 *   - The §09 contrast-table swatch dots  (checked, NOT auto-fixed — see note)
 *
 * The authoritative invariant is token name -> value parity. Comments and
 * whitespace in :root don't count as drift; sync copies the block verbatim so
 * comments stay aligned as a bonus.
 *
 * Out of scope (by design):
 *   - Component CSS copied into the guide (a separate mirror; keep in sync by
 *     periodic manual diff in Phase 1, or shared import in Phase 2).
 *   - Contrast RATIOS in §09. If a color token changes, the ratios must be
 *     recomputed by hand (a tool can't know the new PASS/FAIL labels). The
 *     check FAILS on a stale contrast dot precisely so a human recomputes them.
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, basename } from 'node:path';

const ROOT = join(dirname(fileURLToPath(import.meta.url)), '..');
const APP = join(ROOT, 'vroozi-ai.html');
const GUIDE = join(ROOT, 'vroozi-ai-styleguide.html');

const args = process.argv.slice(2);
if (args.includes('--help') || args.includes('-h')) {
  console.log('sync-styleguide-tokens.mjs — one-way token sync (app -> guide)\n' +
    '  node tools/sync-styleguide-tokens.mjs          sync, then verify\n' +
    '  node tools/sync-styleguide-tokens.mjs --check  verify only; exit 1 on drift');
  process.exit(0);
}
const checkOnly = args.includes('--check');

const C = { red: s => `\x1b[31m${s}\x1b[0m`, grn: s => `\x1b[32m${s}\x1b[0m`, ylw: s => `\x1b[33m${s}\x1b[0m`, dim: s => `\x1b[2m${s}\x1b[0m` };

const NAME_RE = /<div class="name">(--[A-Za-z0-9-]+)<\/div>/;
const HEX_RE = /<div class="hex">([^<]+)<\/div>/;
const DOT_RE = /class="swatch-inline" style="background:(#[0-9A-Fa-f]{3,8})"><\/span>(--[A-Za-z0-9-]+)/;

// :root has no nested braces, so the first } after it closes the block.
function rootRange(html) {
  const open = html.indexOf(':root {');
  if (open < 0) throw new Error('No :root block found');
  const innerStart = open + ':root {'.length;
  const close = html.indexOf('}', innerStart);
  if (close < 0) throw new Error(':root block not closed');
  return { innerStart, close };
}
const rootInner = html => { const r = rootRange(html); return html.slice(r.innerStart, r.close); };
function parseTokens(inner) {
  const map = new Map();
  const re = /(--[A-Za-z0-9-]+)\s*:\s*([^;]+);/g;
  let m; while ((m = re.exec(inner)) !== null) map.set(m[1], m[2].trim());
  return map;
}

// ---- load canonical tokens ----
const appHtml = readFileSync(APP, 'utf8');
const appInner = rootInner(appHtml);
const tokens = parseTokens(appInner);

// ---- analyze a guide string against the canonical tokens ----
function analyze(html) {
  const gTokens = parseTokens(rootInner(html));
  const tokenDrift = [];
  for (const [n, v] of tokens) {
    if (!gTokens.has(n)) tokenDrift.push(`:root token ${n} missing from the guide (app = ${v}).`);
    else if (gTokens.get(n) !== v) tokenDrift.push(`:root token ${n}: guide = ${gTokens.get(n)}, app = ${v}.`);
  }
  for (const n of gTokens.keys()) if (!tokens.has(n)) tokenDrift.push(`:root token ${n} is in the guide but not the app.`);

  const swatchDrift = [], swatchUnknown = []; let swatchCount = 0;
  for (const line of html.split('\n')) {
    if (!line.includes('class="swatch"')) continue;
    const nm = line.match(NAME_RE), hx = line.match(HEX_RE);
    if (!nm || !hx) continue;
    swatchCount++;
    const name = nm[1], shown = hx[1].trim();
    if (!tokens.has(name)) { swatchUnknown.push(`swatch references unknown token ${name}.`); continue; }
    if (shown !== tokens.get(name)) swatchDrift.push(`swatch ${name}: guide shows ${shown}, app token is ${tokens.get(name)}.`);
  }

  const contrast = [];
  for (const line of html.split('\n')) {
    const m = line.match(DOT_RE);
    if (!m) continue;
    const [, color, name] = m;
    if (!tokens.has(name)) { contrast.push(`§09 dot references unknown token ${name}.`); continue; }
    if (color.toUpperCase() !== tokens.get(name).toUpperCase())
      contrast.push(`${name}: §09 dot shows ${color}, token is ${tokens.get(name)} — recompute the ratio + PASS/FAIL by hand.`);
  }
  return { tokenDrift, swatchDrift, swatchUnknown, contrast, swatchCount };
}

// ---- apply fixes (sync mode) ----
function applyFixes(html) {
  const changes = [];
  if (appInner !== rootInner(html)) {
    const r = rootRange(html);
    html = html.slice(0, r.innerStart) + appInner + html.slice(r.close);
    changes.push(':root block rewritten verbatim from the app (canonical).');
  }
  const lines = html.split('\n');
  let fixed = 0;
  for (let i = 0; i < lines.length; i++) {
    if (!lines[i].includes('class="swatch"')) continue;
    const nm = lines[i].match(NAME_RE), hx = lines[i].match(HEX_RE);
    if (!nm || !hx) continue;
    const name = nm[1], shown = hx[1].trim();
    if (!tokens.has(name) || shown === tokens.get(name)) continue;
    // The shown value also appears in the chip's inline color, so a literal,
    // line-scoped replace updates both the chip and the .hex label at once.
    lines[i] = lines[i].split(shown).join(tokens.get(name));
    fixed++;
  }
  if (fixed) changes.push(`${fixed} color swatch value(s) corrected.`);
  return { html: lines.join('\n'), changes };
}

// ---- run ----
const stamp = `${basename(APP)} → ${basename(GUIDE)}`;
console.log(C.dim(`token sync · ${stamp} · ${tokens.size} tokens`));
let guideHtml = readFileSync(GUIDE, 'utf8');

if (checkOnly) {
  const a = analyze(guideHtml);
  const hard = [...a.tokenDrift, ...a.swatchDrift, ...a.swatchUnknown];
  if (!hard.length && !a.contrast.length) {
    console.log(C.grn(`✓ in sync — :root matches, ${a.swatchCount} swatches match, contrast dots match`));
    process.exit(0);
  }
  if (hard.length) { console.log(C.red(`\n✗ ${hard.length} drift problem(s):`)); hard.forEach(p => console.log('  - ' + p)); }
  if (a.contrast.length) { console.log(C.red(`\n✗ §09 contrast table out of date:`)); a.contrast.forEach(w => console.log('  - ' + w)); }
  console.log(C.dim('\nrun without --check to auto-sync :root + swatches (contrast ratios stay manual)'));
  process.exit(1);
}

// sync mode
const { html: out, changes } = applyFixes(guideHtml);
if (changes.length) { writeFileSync(GUIDE, out); console.log(C.grn(`\n✓ guide updated:`)); changes.forEach(c => console.log('  - ' + c)); }
else console.log(C.grn(`\n✓ already in sync — nothing to write`));

// re-analyze the written result so the residual report is accurate
const after = analyze(out);
const residual = [...after.tokenDrift, ...after.swatchDrift, ...after.swatchUnknown];
if (residual.length) { console.log(C.red(`\n✗ unresolved (can't auto-fix):`)); residual.forEach(p => console.log('  - ' + p)); }
if (after.contrast.length) {
  console.log(C.ylw(`\n⚠ §09 contrast table needs a manual recompute (not auto-fixed):`));
  after.contrast.forEach(w => console.log('  - ' + w));
}
console.log(C.dim('\nverify next: extract <script>, node --check; confirm tag balance; first-load render.'));
process.exit(residual.length || after.contrast.length ? 1 : 0);
