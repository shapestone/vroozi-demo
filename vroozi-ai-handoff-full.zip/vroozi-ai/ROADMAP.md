# Vroozi AI — Roadmap & Status (start here)

Single front door for picking up this work: where it is, what to read, and what's next. **App `vroozi-ai.html` v1.40.1 · Design guide `vroozi-ai-styleguide.html` v1.0.29 · 2026-06-23.**

Read order for a new contributor: **this file → `HANDOFF.md` (thin orientation) → `PROJECT-NOTES.md` (authoritative spec).**

---

## At a glance

An internal, single-file build of an AI-assisted procure-to-pay experience for Vroozi (voice/chat/snap ordering, spend analytics, anomaly detection, PR/PO tracking, a mock auth flow). **Phase 1** today: a working free-text input matched to scripted responses behind a `getResponse`/`searchCatalog` seam; stays one self-contained HTML file, no JS/data network calls (the Google Fonts link is the one exception). It is now **token-driven and keyboard-operable**; it is **not yet screen-reader-certified** and is **single-theme (dark)** — light/high-contrast are Phase 2.

---

## What to send your colleague

**Recommend: send the whole `Vroozi AI` folder.** It's self-contained and the docs cross-reference each other; cherry-picking risks broken pointers. The map below is reading priority, not a subset to send.

| Tier | Files | What it is |
|---|---|---|
| **Run the product** | `vroozi-ai.html` | The app (open in a browser, or serve the folder). |
| | `vroozi-ai-styleguide.html` | The design-guide reference asset (mirrors the app's tokens; never changes the app). |
| **Authoritative specs** | `PROJECT-NOTES.md` | **The** spec — direction, phases, the seam, architecture, conventions, working discipline, and the v1.33–v1.40 design-system/accessibility state. |
| | `STYLEGUIDE-NOTES.md` | Spec for the guide asset + the token sync/drift policy. |
| **History** | `CHANGELOG.md` / `STYLEGUIDE-CHANGELOG.md` | Per-version detail for app / guide (Keep-a-Changelog). |
| **Tokens** | `tokens.json` | DTCG token source (99 tokens, regenerated from `:root` at v1.40.0). Documentation-only; the app `:root` is canonical. |
| | `tools/sync-styleguide-tokens.mjs` | The drift gate. `node tools/sync-styleguide-tokens.mjs --check` must exit 0. |
| **Orientation** | `HANDOFF.md` | Intentionally thin; points to PROJECT-NOTES. |
| **Index** | `ASSET-INDEX.md` | Manifest of every asset with descriptions + the rules an AI assistant must follow — the file for a colleague's Claude to read first when setting up a new project. |
| **Forward-looking** | `THEMING-WORKPLAN.md` | Track A/B/C sequencing (A+B shipped; status-bannered). |
| | `THEMING-FEASIBILITY.md` | Why light isn't a token flip; what each theme costs. |
| | `THEMING-HC-SPEC.md` | **Concrete, implementable high-contrast theme spec — the next Track C deliverable.** |
| | `DESIGN-BACKLOG.md` | Original P0/P1/P2 punch list (mostly shipped; status-bannered). |
| **Archival context** | `archive/` (13 docs — see `archive/README.md`) | Superseded reviews & handoffs, moved out of the working set 2026-06-23. Provenance only; **not part of the minimal working set.** |
| **Cowork config** | `project-instructions.md` | Only relevant if they continue in Cowork. |

**The minimal working set = the clean top level** (the two HTML files, `PROJECT-NOTES`/`STYLEGUIDE-NOTES`, both changelogs, `ROADMAP`/`HANDOFF`, `tokens.json`, `tools/`, and the four `THEMING-*`/`DESIGN-BACKLOG` planning docs) — i.e. everything except `archive/` and `project-instructions.md`. Housekeeping: the 13 archival docs moved to `archive/` on 2026-06-23; one stray 12-byte `caution` file (accidental artifact) should be deleted — it's excluded from the minimal set regardless.

---

## Where we are (shipped)

Detail in `CHANGELOG.md`; this is the arc:

- **Phase-1 seam (v1.27.0–v1.32.0):** free-text → scripted-response dispatch (`getResponse`), the catalog search seam (`searchCatalog`), auth mock, the embedded `CATALOG`.
- **Token foundation (v1.33.0–v1.33.1):** role-named token layer — surface ramp consolidated to `--color-shell`, gradients/overlays/scrims/semantic-hex/on-fill all tokenized. `:root` 79 → 97. Zero visual change; theme-ready.
- **Button bases (v1.34.0):** 11 button classes → 2 shared bases (text + icon). Pixel-identical.
- **Sizing tokens (v1.35.0):** `--text-3xs` (10px, zoom-safe) + `--space-7`; 9px killed. `:root` → 99.
- **Accessibility / Track B (v1.36.0–v1.40.0):** native buttons + `nav` landmarks + `aria-current` (B1); live regions + `aria-busy` (B3); focus-trapped `role="dialog"` search overlay + remaining controls→buttons + 44px hit-areas (B2); focus-on-screen-change (B4). **v1.40.1:** fixed a native button-bevel leak (flat look restored).

---

## What's next (prioritized)

1. **Manual screen-reader pass (NVDA / VoiceOver) — the 508/AA gate.** Everything is built to AA conventions and keyboard-verified, but SR output isn't certified by the automated checks. **Do not represent the app as 508/AA conformant until this is run.** Highest priority for the stated federal/SLED goal.
2. **Cosmetic harmonization pass (Phase 1, deferred):** one `:active` press scale, a single glow policy for primary buttons, fewer radii, and snapping off-scale paddings onto `--space-*`. Visible-by-design; render-gated. (Deliberately split off from the pixel-identical button refactor.)
3. **Track C — high-contrast ("ADA") theme (Phase 2):** spec is ready in `THEMING-HC-SPEC.md`. Cheapest, highest buyer value; the token layer makes it a value-flip. Needs a per-theme §09 contrast re-measure + styleguide mirror.
4. **Track C — light theme (Phase 2, harder):** re-tuned semantic palette + gold demoted to fill-only (gold fails as a foreground accent on white) + parallel gradient/overlay/shadow sets. See `THEMING-FEASIBILITY.md`.
5. **Phase 2 — real generation:** reimplement `getResponse` / `getUSearchResponse` / `searchCatalog` bodies as live model/semantic calls (same return shapes; callers/UI unchanged). Ends the single-file constraint — needs repo + server-side key + a compliance path. The big program gate, not just engineering.
6. **Smaller:** fold `chat-send`/`mic-btn` into the icon base; RTL via logical properties (only if localization comes into scope).

---

## How to work here (discipline)

- **Phase 1 = single self-contained file, no deps/build, no JS/data network calls** (Google Fonts link excepted). No `[data-theme]` switch yet — themes are Phase 2 (Track C).
- **Coupled delivery:** any change to `vroozi-ai.html` reconciles, in the same pass — bump `APP_VERSION`; run `node tools/sync-styleguide-tokens.mjs` then `--check` (exit 0); recompute §09 contrast by hand for any changed color token; mirror changed component CSS into the guide; bump the guide's four stamps + `STYLEGUIDE-CHANGELOG.md`; update `CHANGELOG.md` and `PROJECT-NOTES.md`. The two changelogs never fall out of step. Full rule: `PROJECT-NOTES.md` → Working discipline → Deliver.
- **Verify, don't assume:** extract the `<script>` and `node --check`; tag-balance/structural parse; then render through Chrome against `python3 -m http.server 8000` and screenshot at phone (~390–430) + tablet widths. The sandbox can't reach localhost — rendering runs through a real browser. Cover the new states, not just the happy path; behavioral a11y needs keyboard + (manually) screen-reader testing.

This `ROADMAP.md` is the current front door. `THEMING-WORKPLAN.md` / `DESIGN-BACKLOG.md` / `THEMING-FEASIBILITY.md` are the underlying detail (status-bannered as mostly shipped); `THEMING-HC-SPEC.md` is the live next-deliverable.
